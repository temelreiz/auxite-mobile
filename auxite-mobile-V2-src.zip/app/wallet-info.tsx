// app/wallet-info.tsx
// Cüzdan Bilgileri Sayfası

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

const colors = {
  background: '#0F172A',
  surface: '#1E293B',
  primary: '#10B981',
  text: '#FFFFFF',
  textSecondary: '#94A3B8',
  error: '#EF4444',
  border: '#334155',
};

export default function WalletInfoScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadWalletInfo();
  }, []);

  const loadWalletInfo = async () => {
    const address = await AsyncStorage.getItem('auxite_wallet_address');
    setWalletAddress(address);
  };

  const handleCopyAddress = async () => {
    if (walletAddress) {
      await Clipboard.setStringAsync(walletAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleResetWallet = () => {
    Alert.alert(
      'Cüzdanı Sıfırla',
      'Bu işlem cüzdanınızı silecek. Seed phrase\'inizi kaydettiğinizden emin olun!',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Sıfırla',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.multiRemove([
              'auxite_has_wallet',
              'auxite_password_hash',
              'auxite_encrypted_seed',
              'auxite_wallet_address',
            ]);
            router.replace('/wallet-onboarding');
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Cüzdan Bilgileri</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Wallet Card */}
      <View style={styles.walletCard}>
        <View style={styles.walletIcon}>
          <Ionicons name="wallet-outline" size={32} color={colors.primary} />
        </View>
        <Text style={styles.walletLabel}>Cüzdan Adresi</Text>
        <Text style={styles.walletAddress} numberOfLines={1}>
          {walletAddress ? `${walletAddress.slice(0, 10)}...${walletAddress.slice(-8)}` : '-'}
        </Text>
        <TouchableOpacity style={styles.copyButton} onPress={handleCopyAddress}>
          <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={18} color={colors.primary} />
          <Text style={styles.copyButtonText}>{copied ? 'Kopyalandı' : 'Adresi Kopyala'}</Text>
        </TouchableOpacity>
      </View>

      {/* Actions */}
      <View style={styles.actionsContainer}>
        <TouchableOpacity style={styles.actionItem}>
          <View style={styles.actionIcon}>
            <Ionicons name="key-outline" size={22} color={colors.primary} />
          </View>
          <View style={styles.actionContent}>
            <Text style={styles.actionTitle}>Seed Phrase Göster</Text>
            <Text style={styles.actionSubtitle}>Kurtarma kelimelerinizi görüntüleyin</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionItem}>
          <View style={styles.actionIcon}>
            <Ionicons name="download-outline" size={22} color={colors.primary} />
          </View>
          <View style={styles.actionContent}>
            <Text style={styles.actionTitle}>Yedekle</Text>
            <Text style={styles.actionSubtitle}>Cüzdanı güvenli bir yere yedekleyin</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity style={[styles.actionItem, styles.dangerAction]} onPress={handleResetWallet}>
          <View style={[styles.actionIcon, styles.dangerIcon]}>
            <Ionicons name="trash-outline" size={22} color={colors.error} />
          </View>
          <View style={styles.actionContent}>
            <Text style={[styles.actionTitle, styles.dangerText]}>Cüzdanı Sıfırla</Text>
            <Text style={styles.actionSubtitle}>Tüm verileri sil ve yeniden başla</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  headerTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '600',
  },
  walletCard: {
    backgroundColor: colors.surface,
    margin: 16,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  walletIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  walletLabel: {
    color: colors.textSecondary,
    fontSize: 14,
    marginBottom: 8,
  },
  walletAddress: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 16,
  },
  copyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderRadius: 8,
  },
  copyButtonText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  actionsContainer: {
    paddingHorizontal: 16,
  },
  actionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  actionIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  actionContent: {
    flex: 1,
  },
  actionTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 2,
  },
  actionSubtitle: {
    color: colors.textSecondary,
    fontSize: 13,
  },
  dangerAction: {
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  dangerIcon: {
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
  },
  dangerText: {
    color: colors.error,
  },
});
