import { StyleSheet, View, Text, useColorScheme, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useStore } from '@/stores/useStore';

export default function SupportScreen() {
  const colorScheme = useColorScheme();
  const systemIsDark = colorScheme === 'dark';
  const { theme } = useStore();
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: isDark ? '#0f172a' : '#fff', borderBottomColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={isDark ? '#fff' : '#0f172a'} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Support</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* AI Support Coming Soon */}
        <View style={[styles.comingSoonCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <View style={styles.aiIconContainer}>
            <Ionicons name="chatbubbles" size={48} color="#10b981" />
          </View>
          <Text style={[styles.comingSoonTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
            AI Support Coming Soon
          </Text>
          <Text style={[styles.comingSoonDesc, { color: isDark ? '#94a3b8' : '#64748b' }]}>
            We're building an intelligent AI assistant to help you with all your questions 24/7.
          </Text>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
            Frequently Asked Questions
          </Text>
          
          <TouchableOpacity style={[styles.faqItem, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.faqQuestion, { color: isDark ? '#fff' : '#0f172a' }]}>
              How do I buy gold?
            </Text>
            <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
          </TouchableOpacity>
          
          <TouchableOpacity style={[styles.faqItem, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.faqQuestion, { color: isDark ? '#fff' : '#0f172a' }]}>
              What is staking and how does it work?
            </Text>
            <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
          </TouchableOpacity>
          
          <TouchableOpacity style={[styles.faqItem, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.faqQuestion, { color: isDark ? '#fff' : '#0f172a' }]}>
              How do I withdraw my funds?
            </Text>
            <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
          </TouchableOpacity>
          
          <TouchableOpacity style={[styles.faqItem, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.faqQuestion, { color: isDark ? '#fff' : '#0f172a' }]}>
              Is my investment safe?
            </Text>
            <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
          </TouchableOpacity>
        </View>

        {/* Contact Options */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
            Contact Us
          </Text>
          
          <View style={styles.contactGrid}>
            <TouchableOpacity style={[styles.contactCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
              <Ionicons name="mail-outline" size={28} color="#10b981" />
              <Text style={[styles.contactLabel, { color: isDark ? '#fff' : '#0f172a' }]}>Email</Text>
              <Text style={[styles.contactValue, { color: isDark ? '#64748b' : '#94a3b8' }]}>support@auxite.io</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.contactCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
              <Ionicons name="logo-twitter" size={28} color="#1DA1F2" />
              <Text style={[styles.contactLabel, { color: isDark ? '#fff' : '#0f172a' }]}>Twitter</Text>
              <Text style={[styles.contactValue, { color: isDark ? '#64748b' : '#94a3b8' }]}>@AuxiteIO</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.contactCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
              <Ionicons name="logo-discord" size={28} color="#5865F2" />
              <Text style={[styles.contactLabel, { color: isDark ? '#fff' : '#0f172a' }]}>Discord</Text>
              <Text style={[styles.contactValue, { color: isDark ? '#64748b' : '#94a3b8' }]}>Join Server</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.contactCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
              <Ionicons name="logo-telegram" size={28} color="#0088cc" />
              <Text style={[styles.contactLabel, { color: isDark ? '#fff' : '#0f172a' }]}>Telegram</Text>
              <Text style={[styles.contactValue, { color: isDark ? '#64748b' : '#94a3b8' }]}>@AuxiteIO</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  backButton: { padding: 4 },
  headerTitle: { fontSize: 18, fontWeight: 'bold' },
  content: { flex: 1 },
  
  comingSoonCard: {
    margin: 16,
    padding: 32,
    borderRadius: 16,
    alignItems: 'center',
  },
  aiIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#10b98120',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  comingSoonTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  comingSoonDesc: { fontSize: 14, textAlign: 'center', lineHeight: 22 },
  
  section: { paddingHorizontal: 16, marginBottom: 24 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  
  faqItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  faqQuestion: { fontSize: 14, flex: 1, marginRight: 8 },
  
  contactGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  contactCard: {
    width: '47%',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  contactLabel: { fontSize: 14, fontWeight: '600' },
  contactValue: { fontSize: 12 },
});
