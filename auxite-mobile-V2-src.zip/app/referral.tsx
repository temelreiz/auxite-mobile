// app/(tabs)/referral.tsx
// Referral System - Referans Kodu Paylaş, Komisyon Kazan

import { StyleSheet, View, Text, useColorScheme, TouchableOpacity, ScrollView, RefreshControl, Modal, TextInput, Alert, ActivityIndicator, Share, Clipboard } from 'react-native';
import { useState, useEffect, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useStore } from '@/stores/useStore';
import { useWallet } from '@/hooks/useWallet';
import { 
  getReferralInfo,
  applyReferralCode,
  withdrawReferralEarnings,
  type ReferralInfo,
} from '@/services/api';

// Tier colors
const TIER_COLORS: Record<string, string> = {
  bronze: '#CD7F32',
  silver: '#C0C0C0',
  gold: '#FFD700',
  platinum: '#E5E4E2',
};

const TIER_ICONS: Record<string, string> = {
  bronze: 'medal-outline',
  silver: 'medal',
  gold: 'trophy-outline',
  platinum: 'trophy',
};

export default function ReferralScreen() {
  const colorScheme = useColorScheme();
  const systemIsDark = colorScheme === 'dark';
  const { theme } = useStore();
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const insets = useSafeAreaInsets();

  const { address, isConnected } = useWallet();

  // State
  const [refreshing, setRefreshing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [referralInfo, setReferralInfo] = useState<ReferralInfo | null>(null);
  const [applyModalVisible, setApplyModalVisible] = useState(false);
  const [codeInput, setCodeInput] = useState('');
  const [isApplying, setIsApplying] = useState(false);
  const [isWithdrawing, setIsWithdrawing] = useState(false);

  // Fetch referral info
  const fetchReferralInfo = useCallback(async () => {
    if (!address) return;
    setIsLoading(true);
    try {
      const data = await getReferralInfo(address);
      setReferralInfo(data);
    } catch (error) {
      console.error('Failed to fetch referral info:', error);
    } finally {
      setIsLoading(false);
    }
  }, [address]);

  useEffect(() => {
    if (address) {
      fetchReferralInfo();
    }
  }, [address, fetchReferralInfo]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchReferralInfo();
    setRefreshing(false);
  }, [fetchReferralInfo]);

  // Copy code to clipboard
  const handleCopyCode = () => {
    if (referralInfo?.stats.code) {
      Clipboard.setString(referralInfo.stats.code);
      Alert.alert('Kopyalandı', 'Referans kodunuz panoya kopyalandı');
    }
  };

  // Share code
  const handleShareCode = async () => {
    if (!referralInfo?.stats.code) return;
    
    try {
      await Share.share({
        message: `Auxite'a katıl ve $${referralInfo.bonusAmount} bonus kazan! Referans kodum: ${referralInfo.stats.code}\n\nhttps://auxite.app/ref/${referralInfo.stats.code}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  // Apply referral code
  const handleApplyCode = async () => {
    if (!address || !codeInput.trim()) {
      Alert.alert('Hata', 'Lütfen bir referans kodu girin');
      return;
    }

    setIsApplying(true);
    try {
      const result = await applyReferralCode(address, codeInput.trim().toUpperCase());
      
      if (result.success) {
        Alert.alert('Başarılı', result.message || 'Referans kodu uygulandı', [
          { text: 'Tamam', onPress: () => {
            setApplyModalVisible(false);
            setCodeInput('');
            fetchReferralInfo();
          }}
        ]);
      } else {
        Alert.alert('Hata', result.error || 'Kod uygulanamadı');
      }
    } catch (error: any) {
      Alert.alert('Hata', error.message);
    } finally {
      setIsApplying(false);
    }
  };

  // Withdraw earnings
  const handleWithdraw = async () => {
    if (!address) return;
    
    const pendingAmount = referralInfo?.stats.pendingEarnings || 0;
    if (pendingAmount === 0) {
      Alert.alert('Bilgi', 'Çekilecek kazanç bulunmuyor');
      return;
    }

    Alert.alert(
      'Kazançları Çek',
      `$${pendingAmount.toFixed(2)} AUXM bakiyenize aktarılacak. Onaylıyor musunuz?`,
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Çek', onPress: async () => {
          setIsWithdrawing(true);
          try {
            const result = await withdrawReferralEarnings(address);
            if (result.success) {
              Alert.alert('Başarılı', `$${result.paidAmount?.toFixed(2)} AUXM bakiyenize eklendi`);
              fetchReferralInfo();
            } else {
              Alert.alert('Hata', result.error || 'Çekim başarısız');
            }
          } catch (error: any) {
            Alert.alert('Hata', error.message);
          } finally {
            setIsWithdrawing(false);
          }
        }},
      ]
    );
  };

  // Get next tier info
  const getNextTierInfo = () => {
    if (!referralInfo) return null;
    
    const { tier, qualifiedReferrals } = referralInfo.stats;
    const tiers = referralInfo.tiers;
    
    if (tier === 'platinum') return null;
    
    const nextTier = tier === 'bronze' ? 'silver' : tier === 'silver' ? 'gold' : 'platinum';
    const nextMin = tiers[nextTier].minReferrals;
    const remaining = nextMin - qualifiedReferrals;
    
    return { nextTier, remaining, nextRate: tiers[nextTier].rate };
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════════════

  if (!isConnected) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', paddingTop: insets.top }]}>
        <Ionicons name="gift" size={64} color={isDark ? '#334155' : '#cbd5e1'} />
        <Text style={[styles.emptyText, { color: isDark ? '#64748b' : '#94a3b8' }]}>
          Referans programına katılmak için cüzdanınızı bağlayın
        </Text>
      </View>
    );
  }

  if (isLoading && !referralInfo) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color="#a855f7" />
      </View>
    );
  }

  const nextTier = getNextTierInfo();

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', paddingTop: insets.top }]}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#a855f7" />}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: isDark ? '#fff' : '#0f172a' }]}>Referans Programı</Text>
          <Text style={[styles.subtitle, { color: isDark ? '#64748b' : '#94a3b8' }]}>
            Arkadaşlarını davet et, birlikte kazan
          </Text>
        </View>

        {/* My Code Card */}
        <View style={[styles.codeCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <View style={styles.codeHeader}>
            <View style={[styles.tierBadge, { backgroundColor: TIER_COLORS[referralInfo?.stats.tier || 'bronze'] + '30' }]}>
              <Ionicons 
                name={TIER_ICONS[referralInfo?.stats.tier || 'bronze'] as any} 
                size={20} 
                color={TIER_COLORS[referralInfo?.stats.tier || 'bronze']} 
              />
              <Text style={[styles.tierText, { color: TIER_COLORS[referralInfo?.stats.tier || 'bronze'] }]}>
                {(referralInfo?.stats.tier || 'bronze').toUpperCase()}
              </Text>
            </View>
            <Text style={[styles.commissionRate, { color: '#10b981' }]}>
              %{((referralInfo?.stats.commissionRate || 0.1) * 100).toFixed(0)} Komisyon
            </Text>
          </View>

          <Text style={[styles.codeLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Referans Kodunuz</Text>
          <View style={styles.codeRow}>
            <Text style={[styles.code, { color: isDark ? '#fff' : '#0f172a' }]}>
              {referralInfo?.stats.code || '------'}
            </Text>
            <TouchableOpacity style={styles.copyBtn} onPress={handleCopyCode}>
              <Ionicons name="copy-outline" size={20} color="#a855f7" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={[styles.shareBtn, { backgroundColor: '#a855f7' }]} onPress={handleShareCode}>
            <Ionicons name="share-social" size={18} color="#fff" />
            <Text style={styles.shareBtnText}>Kodu Paylaş</Text>
          </TouchableOpacity>

          {/* Next Tier Progress */}
          {nextTier && (
            <View style={styles.nextTierBox}>
              <Text style={[styles.nextTierText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                <Text style={{ color: TIER_COLORS[nextTier.nextTier], fontWeight: '600' }}>
                  {nextTier.nextTier.toUpperCase()}
                </Text>
                {' '}seviyesine {nextTier.remaining} referans kaldı (%{(nextTier.nextRate * 100).toFixed(0)} komisyon)
              </Text>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill, 
                    { 
                      width: `${Math.min(100, ((referralInfo?.stats.qualifiedReferrals || 0) / (referralInfo?.tiers[nextTier.nextTier]?.minReferrals || 1)) * 100)}%`,
                      backgroundColor: TIER_COLORS[nextTier.nextTier] 
                    }
                  ]} 
                />
              </View>
            </View>
          )}
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={[styles.statBox, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.statValue, { color: '#a855f7' }]}>{referralInfo?.stats.totalReferrals || 0}</Text>
            <Text style={[styles.statLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Toplam Referans</Text>
          </View>
          <View style={[styles.statBox, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.statValue, { color: '#10b981' }]}>{referralInfo?.stats.qualifiedReferrals || 0}</Text>
            <Text style={[styles.statLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Onaylanan</Text>
          </View>
          <View style={[styles.statBox, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Text style={[styles.statValue, { color: '#f59e0b' }]}>{referralInfo?.stats.pendingReferrals || 0}</Text>
            <Text style={[styles.statLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Bekleyen</Text>
          </View>
        </View>

        {/* Earnings Card */}
        <View style={[styles.earningsCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <View style={styles.earningsRow}>
            <View>
              <Text style={[styles.earningsLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Toplam Kazanç</Text>
              <Text style={[styles.earningsValue, { color: isDark ? '#fff' : '#0f172a' }]}>
                ${(referralInfo?.stats.totalEarnings || 0).toFixed(2)}
              </Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={[styles.earningsLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Çekilebilir</Text>
              <Text style={[styles.earningsValue, { color: '#10b981' }]}>
                ${(referralInfo?.stats.pendingEarnings || 0).toFixed(2)}
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={[
              styles.withdrawBtn, 
              { 
                backgroundColor: (referralInfo?.stats.pendingEarnings || 0) > 0 ? '#10b981' : '#334155',
                opacity: isWithdrawing ? 0.7 : 1
              }
            ]}
            onPress={handleWithdraw}
            disabled={isWithdrawing || (referralInfo?.stats.pendingEarnings || 0) === 0}
          >
            <Ionicons name="wallet-outline" size={18} color="#fff" />
            <Text style={styles.withdrawBtnText}>
              {isWithdrawing ? 'İşleniyor...' : 'Kazançları Çek'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Apply Code Section */}
        {!referralInfo?.referredBy && (
          <TouchableOpacity
            style={[styles.applyCodeBtn, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
            onPress={() => setApplyModalVisible(true)}
          >
            <Ionicons name="ticket-outline" size={20} color="#a855f7" />
            <Text style={[styles.applyCodeText, { color: isDark ? '#fff' : '#0f172a' }]}>
              Referans Kodu Kullan
            </Text>
            <Ionicons name="chevron-forward" size={18} color={isDark ? '#64748b' : '#94a3b8'} />
          </TouchableOpacity>
        )}

        {referralInfo?.referredBy && (
          <View style={[styles.referredByBox, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <Ionicons name="checkmark-circle" size={20} color="#10b981" />
            <Text style={[styles.referredByText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              Referans kodu kullandınız: <Text style={{ fontWeight: '600' }}>{referralInfo.referredBy}</Text>
            </Text>
          </View>
        )}

        {/* How it Works */}
        <View style={[styles.howItWorks, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Nasıl Çalışır?</Text>
          
          {[
            { icon: 'share-outline', title: 'Kodunu Paylaş', desc: 'Arkadaşlarına referans kodunu gönder' },
            { icon: 'person-add-outline', title: 'Kaydolsunlar', desc: 'Kodunla kayıt olsunlar' },
            { icon: 'cart-outline', title: 'İlk İşlem', desc: `$${referralInfo?.minTradeAmount || 50}+ ilk işlemlerini yapsınlar` },
            { icon: 'gift-outline', title: 'Kazan', desc: `Sen %${((referralInfo?.stats.commissionRate || 0.1) * 100).toFixed(0)} komisyon, onlar $${referralInfo?.bonusAmount || 10} bonus kazansın` },
          ].map((step, index) => (
            <View key={index} style={styles.stepRow}>
              <View style={[styles.stepIcon, { backgroundColor: '#a855f720' }]}>
                <Ionicons name={step.icon as any} size={18} color="#a855f7" />
              </View>
              <View style={styles.stepContent}>
                <Text style={[styles.stepTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{step.title}</Text>
                <Text style={[styles.stepDesc, { color: isDark ? '#64748b' : '#94a3b8' }]}>{step.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Tier Info */}
        <View style={[styles.tierInfo, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Komisyon Seviyeleri</Text>
          
          {referralInfo?.tiers && Object.entries(referralInfo.tiers).map(([tier, info]) => (
            <View key={tier} style={styles.tierRow}>
              <View style={styles.tierLeft}>
                <View style={[styles.tierIcon, { backgroundColor: TIER_COLORS[tier] + '30' }]}>
                  <Ionicons name={TIER_ICONS[tier] as any} size={16} color={TIER_COLORS[tier]} />
                </View>
                <Text style={[styles.tierName, { color: TIER_COLORS[tier] }]}>{tier.toUpperCase()}</Text>
              </View>
              <View style={styles.tierRight}>
                <Text style={[styles.tierReq, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                  {info.minReferrals}+ referans
                </Text>
                <Text style={[styles.tierRate, { color: '#10b981' }]}>%{(info.rate * 100).toFixed(0)}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Apply Code Modal */}
      <Modal
        visible={applyModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setApplyModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Referans Kodu Kullan</Text>
              <TouchableOpacity onPress={() => setApplyModalVisible(false)}>
                <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.inputLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Referans Kodu</Text>
            <TextInput
              style={[styles.input, { 
                backgroundColor: isDark ? '#0f172a' : '#f1f5f9',
                color: isDark ? '#fff' : '#0f172a',
                borderColor: isDark ? '#334155' : '#e2e8f0'
              }]}
              placeholder="ABCD1234"
              placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
              value={codeInput}
              onChangeText={(text) => setCodeInput(text.toUpperCase())}
              autoCapitalize="characters"
              maxLength={10}
            />

            <View style={[styles.bonusInfo, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
              <Ionicons name="gift" size={20} color="#a855f7" />
              <Text style={[styles.bonusText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                Geçerli bir kod kullanarak ${referralInfo?.bonusAmount || 10} AUXM bonus kazanın!
                ${referralInfo?.minTradeAmount || 50}+ ilk işleminizden sonra hesabınıza yüklenecek.
              </Text>
            </View>

            <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: '#a855f7', opacity: isApplying ? 0.7 : 1 }]}
              onPress={handleApplyCode}
              disabled={isApplying}
            >
              <Text style={styles.modalButtonText}>
                {isApplying ? 'Uygulanıyor...' : 'Kodu Uygula'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },

  header: { paddingHorizontal: 16, paddingTop: 16 },
  title: { fontSize: 24, fontWeight: 'bold' },
  subtitle: { fontSize: 13, marginTop: 4 },
  emptyText: { fontSize: 13, textAlign: 'center', marginTop: 12, paddingHorizontal: 40 },

  // Code Card
  codeCard: { marginHorizontal: 16, marginTop: 16, padding: 20, borderRadius: 16 },
  codeHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  tierBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 6, paddingHorizontal: 12, borderRadius: 20 },
  tierText: { fontSize: 12, fontWeight: '700' },
  commissionRate: { fontSize: 13, fontWeight: '600' },

  codeLabel: { fontSize: 11, marginBottom: 8 },
  codeRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  code: { fontSize: 28, fontWeight: 'bold', letterSpacing: 2 },
  copyBtn: { padding: 8 },

  shareBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, borderRadius: 10, marginTop: 16 },
  shareBtnText: { color: '#fff', fontSize: 14, fontWeight: '600' },

  nextTierBox: { marginTop: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: '#334155' },
  nextTierText: { fontSize: 12, marginBottom: 8 },
  progressBar: { height: 6, backgroundColor: '#334155', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },

  // Stats
  statsGrid: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, marginTop: 16 },
  statBox: { flex: 1, padding: 16, borderRadius: 12, alignItems: 'center' },
  statValue: { fontSize: 24, fontWeight: 'bold' },
  statLabel: { fontSize: 11, marginTop: 4 },

  // Earnings
  earningsCard: { marginHorizontal: 16, marginTop: 16, padding: 16, borderRadius: 12 },
  earningsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  earningsLabel: { fontSize: 11 },
  earningsValue: { fontSize: 20, fontWeight: 'bold', marginTop: 4 },
  withdrawBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, borderRadius: 10, marginTop: 16 },
  withdrawBtnText: { color: '#fff', fontSize: 14, fontWeight: '600' },

  // Apply Code
  applyCodeBtn: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 16, marginTop: 16, padding: 16, borderRadius: 12 },
  applyCodeText: { flex: 1, fontSize: 14, fontWeight: '500' },

  referredByBox: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 16, marginTop: 16, padding: 14, borderRadius: 10 },
  referredByText: { fontSize: 12, flex: 1 },

  // How it Works
  howItWorks: { marginHorizontal: 16, marginTop: 16, padding: 16, borderRadius: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '600', marginBottom: 16 },
  stepRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 16 },
  stepIcon: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  stepContent: { flex: 1 },
  stepTitle: { fontSize: 13, fontWeight: '600' },
  stepDesc: { fontSize: 11, marginTop: 2 },

  // Tier Info
  tierInfo: { marginHorizontal: 16, marginTop: 16, padding: 16, borderRadius: 12 },
  tierRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10 },
  tierLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  tierIcon: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  tierName: { fontSize: 13, fontWeight: '700' },
  tierRight: { alignItems: 'flex-end' },
  tierReq: { fontSize: 10 },
  tierRate: { fontSize: 16, fontWeight: 'bold', marginTop: 2 },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 40 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600' },

  inputLabel: { fontSize: 12, marginBottom: 8 },
  input: { fontSize: 20, paddingHorizontal: 16, paddingVertical: 14, borderRadius: 10, borderWidth: 1, textAlign: 'center', letterSpacing: 3, fontWeight: '600' },

  bonusInfo: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 14, borderRadius: 10, marginTop: 16 },
  bonusText: { fontSize: 12, flex: 1, lineHeight: 18 },

  modalButton: { paddingVertical: 14, borderRadius: 10, alignItems: 'center', marginTop: 20 },
  modalButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
