import { StyleSheet, View, Text, useColorScheme, TouchableOpacity, ScrollView, Image, Modal, Dimensions, TextInput, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useStore } from '@/stores/useStore';
import { useBalanceStore } from '@/stores/useBalanceStore';
import { WebView } from 'react-native-webview';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { getTradePreview, type TradePreview } from '@/services/api';

const TROY_OZ_TO_GRAM = 31.1035;
const { width: SCREEN_WIDTH } = Dimensions.get('window');

const metalIcons: Record<string, any> = {
  AUXG: require('@/assets/images/metals/gold.png'),
  AUXS: require('@/assets/images/metals/silver.png'),
  AUXPT: require('@/assets/images/metals/platinum.png'),
  AUXPD: require('@/assets/images/metals/palladium.png'),
  // AUXM ve USDT için aşağıdaki dosyaları oluştur veya fallback kullanılır
  // AUXM: require('@/assets/images/tokens/auxm.png'),
  // USDT: require('@/assets/images/tokens/usdt.png'),
};

interface Metal {
  symbol: string;
  name: string;
  price: number;
  priceOz: number;
  buyPrice: number;
  sellPrice: number;
  change24h: number;
  color: string;
}

interface TrendData {
  symbol: string;
  buyVolume: number;
  sellVolume: number;
  trend: 'buy' | 'sell' | 'neutral';
  isCrypto?: boolean;
  icon?: string;
  color?: string;
}

export default function TradeScreen() {
  const colorScheme = useColorScheme();
  const systemIsDark = colorScheme === 'dark';
  const { theme } = useStore();
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const insets = useSafeAreaInsets();
  
  const [selectedMetal, setSelectedMetal] = useState<Metal | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [allocationModalVisible, setAllocationModalVisible] = useState(false);
  const [tradeModalVisible, setTradeModalVisible] = useState(false);
  const [tradeMode, setTradeMode] = useState<'buy' | 'sell'>('buy');
  const [spread, setSpread] = useState({ buy: 1.5, sell: 1.5 });
  
  // Trade Modal State
  const [tradeAmount, setTradeAmount] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState('AUXM');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [limitPrice, setLimitPrice] = useState('');
  const [tradePreview, setTradePreview] = useState<TradePreview | null>(null);
  
  // Modal Tab State
  const [modalTab, setModalTab] = useState<'price' | 'info' | 'data'>('price');
  
  // Orders State (mock data)
  const [completedOrders] = useState([
    { id: '1', type: 'buy' as const, amount: 0.5, price: 138.50, total: 69.25, date: '17.12 14:30' },
    { id: '2', type: 'sell' as const, amount: 0.25, price: 139.20, total: 34.80, date: '17.12 12:15' },
    { id: '3', type: 'buy' as const, amount: 1.0, price: 137.80, total: 137.80, date: '16.12 18:45' },
  ]);
  
  const [pendingOrders, setPendingOrders] = useState([
    { id: '4', type: 'buy' as const, amount: 0.5, price: 135.00, total: 67.50, date: '17.12 15:00' },
    { id: '5', type: 'sell' as const, amount: 1.0, price: 145.00, total: 145.00, date: '17.12 15:30' },
  ]);
  
  // Balance store - gerçek API'den
  const { 
    balance, 
    address, 
    isTrading, 
    fetchBalance, 
    executeBuy, 
    executeSell, 
    createOrder 
  } = useBalanceStore();

  // Computed balances for UI
  const balances = {
    auxm: balance?.auxm || 0,
    bonusAuxm: balance?.bonusAuxm || 0,
    eth: balance?.eth || 0,
    usdt: balance?.usdt || 0,
    btc: balance?.btc || 0,
    xrp: balance?.xrp || 0,
    sol: balance?.sol || 0,
  };

  // Trending assets state - metals + crypto based on activity
  const [trendingAssets, setTrendingAssets] = useState<TrendData[]>([
    { symbol: 'AUXG', buyVolume: 65, sellVolume: 35, trend: 'buy', isCrypto: false, color: '#EAB308' },
    { symbol: 'AUXS', buyVolume: 45, sellVolume: 55, trend: 'sell', isCrypto: false, color: '#94A3B8' },
    { symbol: 'BTC', buyVolume: 72, sellVolume: 28, trend: 'buy', isCrypto: true, icon: '₿', color: '#F7931A' },
  ]);

  const [metals, setMetals] = useState<Metal[]>([
    { symbol: 'AUXG', name: 'Gold', price: 0, priceOz: 0, buyPrice: 0, sellPrice: 0, change24h: 0, color: '#EAB308' },
    { symbol: 'AUXS', name: 'Silver', price: 0, priceOz: 0, buyPrice: 0, sellPrice: 0, change24h: 0, color: '#94A3B8' },
    { symbol: 'AUXPT', name: 'Platinum', price: 0, priceOz: 0, buyPrice: 0, sellPrice: 0, change24h: 0, color: '#E2E8F0' },
    { symbol: 'AUXPD', name: 'Palladium', price: 0, priceOz: 0, buyPrice: 0, sellPrice: 0, change24h: 0, color: '#64748B' },
    { symbol: 'AUXM', name: 'Auxite Para', price: 1.00, priceOz: 31.1035, buyPrice: 1.00, sellPrice: 1.00, change24h: 0, color: '#A855F7' },
  ]);

  // Crypto Assets
  const [cryptos, setCryptos] = useState([
    { symbol: 'BTC', name: 'Bitcoin', price: 0, change24h: 0, color: '#F7931A', icon: '₿' },
    { symbol: 'ETH', name: 'Ethereum', price: 0, change24h: 0, color: '#627EEA', icon: 'Ξ' },
    { symbol: 'XRP', name: 'Ripple', price: 0, change24h: 0, color: '#00A3E0', icon: '✕' },
    { symbol: 'SOL', name: 'Solana', price: 0, change24h: 0, color: '#9945FF', icon: '◎' },
    { symbol: 'USDT', name: 'Tether', price: 1.00, change24h: 0, color: '#26A17B', icon: '₮' },
  ]);

  const fetchPrices = async () => {
    try {
      const priceRes = await fetch('https://api.auxite.io/api/prices?chain=84532');
      const priceData = await priceRes.json();

      if (priceData.ok && priceData.data) {
        let currentSpread = { buy: 1.5, sell: 1.5 };
        try {
          const spreadRes = await fetch('https://auxite-wallet.vercel.app/api/admin/spread');
          const spreadData = await spreadRes.json();
          if (spreadData.buy !== undefined) {
            currentSpread = { buy: spreadData.buy, sell: spreadData.sell };
            setSpread(currentSpread);
          }
        } catch (e) {}

        let changes: Record<string, number> = {};
        try {
          const metalsRes = await fetch('https://auxite-wallet.vercel.app/api/metals');
          const metalsData = await metalsRes.json();
          if (metalsData.ok && metalsData.changes) {
            changes = metalsData.changes;
          }
        } catch (e) {}

        setMetals(prev => prev.map(m => {
          const info = priceData.data.find((d: any) => d.symbol === m.symbol);
          if (info && info.price) {
            const priceOz = info.price;
            const priceGram = priceOz / TROY_OZ_TO_GRAM;
            const buyPrice = priceGram * (1 + currentSpread.buy / 100);
            const sellPrice = priceGram * (1 - currentSpread.sell / 100);
            
            return { 
              ...m, 
              priceOz: priceOz,
              price: priceGram,
              buyPrice: buyPrice,
              sellPrice: sellPrice,
              change24h: changes[m.symbol] || 0 
            };
          }
          // AUXM için özel işlem - API'de yoksa sabit kal
          if (m.symbol === 'AUXM') {
            return { ...m, change24h: changes[m.symbol] || 0 };
          }
          return m;
        }));
      }

      // Fetch crypto prices
      try {
        const cryptoRes = await fetch('https://auxite-wallet.vercel.app/api/crypto');
        const cryptoData = await cryptoRes.json();
        const cryptoMap: Record<string, string> = { BTC: 'bitcoin', ETH: 'ethereum', XRP: 'ripple', SOL: 'solana' };
        
        setCryptos(prev => prev.map(c => {
          const apiKey = cryptoMap[c.symbol];
          if (apiKey && cryptoData[apiKey]) {
            return { 
              ...c, 
              price: cryptoData[apiKey].usd, 
              change24h: cryptoData[apiKey].usd_24h_change || 0 
            };
          }
          return c;
        }));
      } catch (e) {
        console.error('Crypto fetch error:', e);
      }
    } catch (error) {
      console.error('Price fetch error:', error);
    }
  };

  // Fetch trending data
  const fetchTrends = async () => {
    try {
      const res = await fetch('https://auxite-wallet.vercel.app/api/trends');
      const data = await res.json();
      if (data.ok && data.trends) {
        // Metal trends'i al ve crypto ekle
        const metalTrends = data.trends.slice(0, 2).map((t: any) => ({
          ...t,
          isCrypto: false,
          color: metals.find(m => m.symbol === t.symbol)?.color || '#EAB308'
        }));
        
        // BTC trend'i API'den veya varsayılan
        const btcTrend = data.cryptoTrends?.find((t: any) => t.symbol === 'BTC') || {
          symbol: 'BTC',
          buyVolume: 72,
          sellVolume: 28,
          trend: 'buy'
        };
        
        setTrendingAssets([
          ...metalTrends,
          { ...btcTrend, isCrypto: true, icon: '₿', color: '#F7931A' }
        ]);
      }
    } catch (e) {
      // Keep default trending data
    }
  };

  useEffect(() => {
    fetchPrices();
    fetchTrends();
    
    // Fetch balance if address exists
    if (address) {
      fetchBalance();
    }
    
    const priceInterval = setInterval(fetchPrices, 5000);  // 5 saniye - trade için kritik
    const trendInterval = setInterval(fetchTrends, 60000); // 60 saniye
    return () => {
      clearInterval(priceInterval);
      clearInterval(trendInterval);
    };
  }, [address]);

  const formatPrice = (price: number) => {
    if (price >= 1000) return '$' + price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (price >= 1) return '$' + price.toFixed(2);
    if (price > 0) return '$' + price.toFixed(4);
    return '$0.00';
  };

  const formatChange = (change: number) => {
    const prefix = change >= 0 ? '+' : '';
    return prefix + change.toFixed(2) + '%';
  };

  const getPriceColor = (change: number) => {
    if (change > 0) return '#10b981';
    if (change < 0) return '#ef4444';
    return isDark ? '#fff' : '#0f172a';
  };

  const openTradeModal = (metal: Metal) => {
    setSelectedMetal(metal);
    setModalTab('price');
    setModalVisible(true);
  };

  // currentSelectedMetal'i metals array'inden güncel tut
  const currentSelectedMetal = selectedMetal 
    ? metals.find(m => m.symbol === selectedMetal.symbol) || selectedMetal
    : null;

  const getMetalBySymbol = (symbol: string) => metals.find(m => m.symbol === symbol);

  const getAdvancedChartHtml = (metal: Metal) => {
    const bgColor = isDark ? '#0f172a' : '#ffffff';
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    const borderColor = isDark ? '#1e293b' : '#e2e8f0';
    const upColor = '#10b981';
    const downColor = '#ef4444';
    
    const currentPrice = metal.price > 0 ? metal.price : 1;
    
    return `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <script src="https://unpkg.com/lightweight-charts@4.1.0/dist/lightweight-charts.standalone.production.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100%; height: 100%; overflow: hidden; background: ${bgColor}; font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
    .container { display: flex; flex-direction: column; height: 100%; }
    .controls { display: flex; gap: 4px; padding: 8px; background: ${bgColor}; border-bottom: 1px solid ${borderColor}; }
    .tf-btn { padding: 6px 10px; border: none; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer; }
    .tf-btn.active { background: ${upColor}; color: white; }
    .tf-btn:not(.active) { background: ${isDark ? '#1e293b' : '#f1f5f9'}; color: ${textColor}; }
    .chart-container { flex: 1; min-height: 200px; }
    .panel-container { height: 80px; border-top: 1px solid ${borderColor}; }
    .panel-header { display: flex; justify-content: space-between; align-items: center; padding: 4px 8px; background: ${bgColor}; }
    .panel-label { font-size: 10px; color: ${textColor}; }
    .indicators { display: flex; gap: 4px; padding: 6px 8px; background: ${bgColor}; border-top: 1px solid ${borderColor}; flex-wrap: wrap; }
    .ind-group { display: flex; gap: 4px; align-items: center; }
    .ind-label { font-size: 9px; color: ${textColor}; margin-right: 4px; }
    .ind-btn { padding: 4px 8px; border: none; border-radius: 4px; font-size: 10px; font-weight: 500; cursor: pointer; }
    .ind-btn.overlay.active { background: #3b82f6; color: white; }
    .ind-btn.panel.active { background: ${upColor}; color: white; }
    .ind-btn:not(.active) { background: ${isDark ? '#1e293b' : '#f1f5f9'}; color: ${textColor}; }
  </style>
</head>
<body>
  <div class="container">
    <div class="controls" id="timeframeControls">
      <button class="tf-btn" data-tf="15">15m</button>
      <button class="tf-btn active" data-tf="60">1H</button>
      <button class="tf-btn" data-tf="240">4H</button>
      <button class="tf-btn" data-tf="1440">1D</button>
      <button class="tf-btn" data-tf="10080">1W</button>
    </div>
    <div id="mainChart" class="chart-container"></div>
    <div class="panel-header">
      <span class="panel-label" id="panelLabel">Volume</span>
    </div>
    <div id="panelChart" class="panel-container"></div>
    <div class="indicators">
      <div class="ind-group">
        <span class="ind-label">Overlay:</span>
        <button class="ind-btn overlay" data-ind="MA">MA</button>
        <button class="ind-btn overlay" data-ind="EMA">EMA</button>
        <button class="ind-btn overlay" data-ind="BOLL">BOLL</button>
      </div>
      <div class="ind-group">
        <span class="ind-label">Panel:</span>
        <button class="ind-btn panel active" data-ind="VOL">VOL</button>
        <button class="ind-btn panel" data-ind="RSI">RSI</button>
        <button class="ind-btn panel" data-ind="MACD">MACD</button>
      </div>
    </div>
  </div>
  <script>
    const bgColor = '${bgColor}';
    const textColor = '${textColor}';
    const gridColor = '${gridColor}';
    const borderColor = '${borderColor}';
    const upColor = '${upColor}';
    const downColor = '${downColor}';
    const currentPrice = ${currentPrice};

    function hashString(str) {
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash = hash & hash;
      }
      return Math.abs(hash);
    }

    function seededRandom(seed) {
      return function() {
        let t = seed += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
      };
    }

    function generateData(tf, price) {
      const seed = hashString('${metal.symbol}-' + tf + '-v3');
      const random = seededRandom(seed);
      const now = Math.floor(Date.now() / 1000);
      const intervals = { 15: 900, 60: 3600, 240: 14400, 1440: 86400, 10080: 604800 };
      const interval = intervals[tf] || 3600;
      const count = 100;
      const decimals = price >= 10 ? 2 : 4;
      
      const rawData = [];
      let p = 100;
      for (let i = count; i >= 0; i--) {
        const vol = 0.015;
        const change = (random() - 0.48) * vol;
        const open = p;
        const close = open * (1 + change);
        const high = Math.max(open, close) * (1 + random() * vol * 0.5);
        const low = Math.min(open, close) * (1 - random() * vol * 0.5);
        rawData.push({ open, high, low, close });
        p = close;
      }
      
      const lastClose = rawData[rawData.length - 1].close;
      const scale = price / lastClose;
      
      const data = [];
      for (let i = 0; i <= count; i++) {
        const time = now - (count - i) * interval;
        const r = rawData[i];
        data.push({
          time,
          open: parseFloat((r.open * scale).toFixed(decimals)),
          high: parseFloat((r.high * scale).toFixed(decimals)),
          low: parseFloat((r.low * scale).toFixed(decimals)),
          close: parseFloat((r.close * scale).toFixed(decimals)),
          volume: random() * 1000000
        });
      }
      
      if (data.length > 0) {
        const last = data[data.length - 1];
        last.close = parseFloat(price.toFixed(decimals));
        last.high = Math.max(last.high, last.close);
        last.low = Math.min(last.low, last.close);
      }
      
      return data;
    }

    let mainChart, panelChart, candleSeries, volumeSeries;
    let overlays = new Map();
    let panelSeries = new Map();
    let currentTf = 60;
    let activeOverlays = [];
    let activePanel = 'VOL';
    let chartData = [];

    function createCharts() {
      const mainContainer = document.getElementById('mainChart');
      const panelContainer = document.getElementById('panelChart');
      
      mainChart = LightweightCharts.createChart(mainContainer, {
        width: mainContainer.clientWidth,
        height: mainContainer.clientHeight,
        layout: { background: { type: 'solid', color: bgColor }, textColor: textColor, attributionLogo: false },
        grid: { vertLines: { color: gridColor }, horzLines: { color: gridColor } },
        crosshair: { mode: 0 },
        rightPriceScale: { borderColor: borderColor },
        timeScale: { borderColor: borderColor, timeVisible: true }
      });

      candleSeries = mainChart.addCandlestickSeries({
        upColor: upColor, downColor: downColor,
        borderUpColor: upColor, borderDownColor: downColor,
        wickUpColor: upColor, wickDownColor: downColor
      });

      volumeSeries = mainChart.addHistogramSeries({
        priceFormat: { type: 'volume' },
        priceScaleId: 'volume'
      });
      mainChart.priceScale('volume').applyOptions({ scaleMargins: { top: 0.8, bottom: 0 } });

      panelChart = LightweightCharts.createChart(panelContainer, {
        width: panelContainer.clientWidth,
        height: panelContainer.clientHeight,
        layout: { background: { type: 'solid', color: bgColor }, textColor: textColor, attributionLogo: false },
        grid: { vertLines: { color: gridColor }, horzLines: { color: gridColor } },
        rightPriceScale: { borderColor: borderColor },
        timeScale: { visible: false }
      });

      mainChart.timeScale().subscribeVisibleLogicalRangeChange(range => {
        if (range) panelChart.timeScale().setVisibleLogicalRange(range);
      });

      updateData();
    }

    function updateData() {
      chartData = generateData(currentTf, currentPrice);
      candleSeries.setData(chartData);
      volumeSeries.setData(chartData.map(d => ({
        time: d.time,
        value: d.volume,
        color: d.close >= d.open ? upColor + '50' : downColor + '50'
      })));
      mainChart.timeScale().fitContent();
      updateOverlays();
      updatePanel();
    }

    function calculateMA(data, period) {
      const result = [];
      for (let i = period - 1; i < data.length; i++) {
        let sum = 0;
        for (let j = 0; j < period; j++) sum += data[i - j].close;
        result.push({ time: data[i].time, value: sum / period });
      }
      return result;
    }

    function calculateEMA(data, period) {
      const result = [];
      const k = 2 / (period + 1);
      let ema = data[0].close;
      for (let i = 0; i < data.length; i++) {
        ema = data[i].close * k + ema * (1 - k);
        result.push({ time: data[i].time, value: ema });
      }
      return result;
    }

    function calculateBollinger(data, period = 20) {
      const ma = calculateMA(data, period);
      const upper = [], lower = [];
      for (let i = period - 1; i < data.length; i++) {
        const slice = data.slice(i - period + 1, i + 1);
        const mean = ma[i - period + 1]?.value || data[i].close;
        const variance = slice.reduce((acc, c) => acc + Math.pow(c.close - mean, 2), 0) / period;
        const std = Math.sqrt(variance);
        upper.push({ time: data[i].time, value: mean + 2 * std });
        lower.push({ time: data[i].time, value: mean - 2 * std });
      }
      return { upper, middle: ma, lower };
    }

    function calculateRSI(data, period = 14) {
      const result = [];
      for (let i = 0; i < data.length; i++) {
        if (i < period) { result.push({ time: data[i].time, value: 50 }); continue; }
        let gains = 0, losses = 0;
        for (let j = i - period; j < i; j++) {
          const change = data[j + 1].close - data[j].close;
          if (change > 0) gains += change; else losses -= change;
        }
        const rs = (gains / period) / ((losses / period) || 0.001);
        result.push({ time: data[i].time, value: 100 - (100 / (1 + rs)) });
      }
      return result;
    }

    function calculateMACD(data) {
      let ema12 = data[0].close, ema26 = data[0].close;
      const macd = [], signal = [], histogram = [];
      const macdVals = [];
      for (let i = 0; i < data.length; i++) {
        ema12 = (data[i].close * 2) / 13 + ema12 * 11 / 13;
        ema26 = (data[i].close * 2) / 27 + ema26 * 25 / 27;
        const m = ema12 - ema26;
        macdVals.push(m);
        macd.push({ time: data[i].time, value: m });
      }
      let sigEma = macdVals[0];
      for (let i = 0; i < macdVals.length; i++) {
        sigEma = (macdVals[i] * 2) / 10 + sigEma * 8 / 10;
        signal.push({ time: chartData[i].time, value: sigEma });
        const h = macdVals[i] - sigEma;
        histogram.push({ time: chartData[i].time, value: h, color: h >= 0 ? upColor + '99' : downColor + '99' });
      }
      return { macd, signal, histogram };
    }

    function updateOverlays() {
      overlays.forEach(s => { try { mainChart.removeSeries(s); } catch(e) {} });
      overlays.clear();

      if (activeOverlays.includes('MA')) {
        const ma7 = calculateMA(chartData, 7);
        const ma25 = calculateMA(chartData, 25);
        const s7 = mainChart.addLineSeries({ color: '#f59e0b', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        s7.setData(ma7);
        overlays.set('ma7', s7);
        const s25 = mainChart.addLineSeries({ color: '#3b82f6', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        s25.setData(ma25);
        overlays.set('ma25', s25);
      }

      if (activeOverlays.includes('EMA')) {
        const ema12 = calculateEMA(chartData, 12);
        const ema26 = calculateEMA(chartData, 26);
        const s12 = mainChart.addLineSeries({ color: '#06b6d4', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        s12.setData(ema12);
        overlays.set('ema12', s12);
        const s26 = mainChart.addLineSeries({ color: '#a855f7', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        s26.setData(ema26);
        overlays.set('ema26', s26);
      }

      if (activeOverlays.includes('BOLL')) {
        const boll = calculateBollinger(chartData);
        const su = mainChart.addLineSeries({ color: upColor + '80', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        su.setData(boll.upper);
        overlays.set('bollU', su);
        const sm = mainChart.addLineSeries({ color: '#9ca3af80', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        sm.setData(boll.middle);
        overlays.set('bollM', sm);
        const sl = mainChart.addLineSeries({ color: downColor + '80', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        sl.setData(boll.lower);
        overlays.set('bollL', sl);
      }
    }

    function updatePanel() {
      panelSeries.forEach(s => { try { panelChart.removeSeries(s); } catch(e) {} });
      panelSeries.clear();
      document.getElementById('panelLabel').textContent = activePanel === 'VOL' ? 'Volume' : activePanel === 'RSI' ? 'RSI (14)' : 'MACD';

      if (activePanel === 'VOL') {
        const vs = panelChart.addHistogramSeries({ priceFormat: { type: 'volume' } });
        vs.setData(chartData.map(d => ({ time: d.time, value: d.volume, color: d.close >= d.open ? upColor + '99' : downColor + '99' })));
        panelSeries.set('vol', vs);
      } else if (activePanel === 'RSI') {
        const rsi = calculateRSI(chartData);
        const rs = panelChart.addLineSeries({ color: '#a855f7', lineWidth: 2, priceLineVisible: false });
        rs.setData(rsi);
        panelSeries.set('rsi', rs);
      } else if (activePanel === 'MACD') {
        const macd = calculateMACD(chartData);
        const hs = panelChart.addHistogramSeries({ priceFormat: { type: 'price' } });
        hs.setData(macd.histogram);
        panelSeries.set('macdH', hs);
        const ms = panelChart.addLineSeries({ color: '#3b82f6', lineWidth: 1, priceLineVisible: false });
        ms.setData(macd.macd);
        panelSeries.set('macdL', ms);
        const ss = panelChart.addLineSeries({ color: '#f59e0b', lineWidth: 1, priceLineVisible: false });
        ss.setData(macd.signal);
        panelSeries.set('macdS', ss);
      }
      panelChart.timeScale().fitContent();
    }

    document.getElementById('timeframeControls').addEventListener('click', e => {
      if (e.target.classList.contains('tf-btn')) {
        document.querySelectorAll('.tf-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        currentTf = parseInt(e.target.dataset.tf);
        updateData();
      }
    });

    document.querySelector('.indicators').addEventListener('click', e => {
      if (e.target.classList.contains('ind-btn')) {
        const ind = e.target.dataset.ind;
        if (e.target.classList.contains('overlay')) {
          e.target.classList.toggle('active');
          if (activeOverlays.includes(ind)) {
            activeOverlays = activeOverlays.filter(i => i !== ind);
          } else {
            activeOverlays.push(ind);
          }
          updateOverlays();
        } else if (e.target.classList.contains('panel')) {
          document.querySelectorAll('.ind-btn.panel').forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          activePanel = ind;
          updatePanel();
        }
      }
    });

    window.addEventListener('resize', () => {
      const mc = document.getElementById('mainChart');
      const pc = document.getElementById('panelChart');
      mainChart.applyOptions({ width: mc.clientWidth, height: mc.clientHeight });
      panelChart.applyOptions({ width: pc.clientWidth, height: pc.clientHeight });
    });

    createCharts();
  </script>
</body>
</html>`;
  };

  // Banner Component
  const Banner = () => (
    <TouchableOpacity activeOpacity={0.9} style={styles.bannerContainer}>
      <LinearGradient
        colors={isDark ? ['#1e293b', '#334155'] : ['#f1f5f9', '#e2e8f0']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.banner}
      >
        <View style={styles.bannerContent}>
          <View style={styles.bannerTextContainer}>
            <Text style={[styles.bannerTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
              🎉 Welcome to Auxite
            </Text>
            <Text style={[styles.bannerSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              Trade precious metals with ease
            </Text>
          </View>
          <View style={[styles.bannerBadge, { backgroundColor: '#10b981' }]}>
            <Text style={styles.bannerBadgeText}>NEW</Text>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  // Trending Card Component - Metal & Crypto
  const TrendingCard = ({ trend }: { trend: TrendData }) => {
    const isCrypto = trend.isCrypto || false;
    
    // Metal veya crypto bilgilerini al
    const metal = !isCrypto ? getMetalBySymbol(trend.symbol) : null;
    const crypto = isCrypto ? cryptos.find(c => c.symbol === trend.symbol) : null;
    
    if (!metal && !crypto) return null;

    const isBuyTrend = trend.trend === 'buy';
    const trendColor = isBuyTrend ? '#10b981' : '#ef4444';
    const trendIcon = isBuyTrend ? 'trending-up' : 'trending-down';
    const trendLabel = isBuyTrend ? 'Buying' : 'Selling';
    
    const assetColor = trend.color || (metal?.color || crypto?.color || '#10b981');
    const assetName = metal?.name || crypto?.name || '';
    const assetPrice = metal?.price || crypto?.price || 0;
    const assetChange = metal?.change24h || crypto?.change24h || 0;

    const handlePress = () => {
      if (isCrypto) {
        router.push({ pathname: '/(tabs)/convert', params: { from: trend.symbol } } as any);
      } else if (metal) {
        openTradeModal(metal);
      }
    };

    return (
      <TouchableOpacity 
        style={[styles.trendingCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
        activeOpacity={0.7}
        onPress={handlePress}
      >
        <View style={styles.trendingHeader}>
          <View style={[styles.trendingIcon, { backgroundColor: assetColor + '20' }]}>
            {!isCrypto && metalIcons[trend.symbol] ? (
              <Image source={metalIcons[trend.symbol]} style={styles.trendingIconImage} resizeMode="contain" />
            ) : (
              <Text style={[styles.trendingCryptoIcon, { color: assetColor }]}>{trend.icon || trend.symbol[0]}</Text>
            )}
          </View>
          <View style={[styles.trendBadge, { backgroundColor: trendColor + '20' }]}>
            <Ionicons name={trendIcon} size={10} color={trendColor} />
            <Text style={[styles.trendBadgeText, { color: trendColor }]}>{trendLabel}</Text>
          </View>
        </View>
        
        <Text style={[styles.trendingSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{trend.symbol}</Text>
        
        <View style={styles.trendingPriceRow}>
          <Text style={[styles.trendingPrice, { color: getPriceColor(assetChange) }]}>
            {formatPrice(assetPrice)}
          </Text>
          <Text style={[styles.trendingChange, { color: getPriceColor(assetChange) }]}>
            {formatChange(assetChange)}
          </Text>
        </View>

        <View style={styles.trendingBar}>
          <View 
            style={[
              styles.trendingBarFill, 
              { 
                width: `${trend.buyVolume}%`, 
                backgroundColor: '#10b981' 
              }
            ]} 
          />
          <View 
            style={[
              styles.trendingBarFill, 
              { 
                width: `${trend.sellVolume}%`, 
                backgroundColor: '#ef4444' 
              }
            ]} 
          />
        </View>
        <View style={styles.trendingBarLabels}>
          <Text style={[styles.trendingBarLabel, { color: '#10b981' }]}>{trend.buyVolume}% Buy</Text>
          <Text style={[styles.trendingBarLabel, { color: '#ef4444' }]}>{trend.sellVolume}% Sell</Text>
        </View>
      </TouchableOpacity>
    );
  };

  const TableHeader = ({ title }: { title: string }) => (
    <View style={styles.tableHeader}>
      <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{title}</Text>
      <Text style={[styles.headerLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Price</Text>
      <Text style={[styles.headerLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>24h Change</Text>
    </View>
  );

  const MetalRow = ({ item }: { item: Metal }) => (
    <TouchableOpacity 
      style={[styles.metalRow, { borderBottomColor: isDark ? '#1e293b' : '#f1f5f9' }]} 
      activeOpacity={0.7}
      onPress={() => openTradeModal(item)}
    >
      <View style={styles.metalLeft}>
        <View style={[styles.metalIcon, { backgroundColor: item.color + '20' }]}>
          {metalIcons[item.symbol] ? (
            <Image source={metalIcons[item.symbol]} style={styles.metalImage} resizeMode="contain" />
          ) : item.symbol === 'AUXM' ? (
            <View style={[styles.auxmIconFallback, { backgroundColor: '#A855F7' }]}>
              <Text style={styles.auxmIconText}>◇</Text>
            </View>
          ) : (
            <Image source={require('@/assets/images/logos/auxite-logo.png')} style={styles.metalImage} resizeMode="contain" />
          )}
        </View>
        <View>
          <Text style={[styles.metalSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.symbol}</Text>
          <Text style={[styles.metalName, { color: isDark ? '#64748b' : '#94a3b8' }]}>{item.name}</Text>
        </View>
      </View>
      <Text style={[styles.metalPrice, { color: getPriceColor(item.change24h) }]}>{formatPrice(item.price)}</Text>
      <Text style={[styles.changeValue, { color: getPriceColor(item.change24h) }]}>{formatChange(item.change24h)}</Text>
    </TouchableOpacity>
  );

  // Crypto Row - Convert sayfasına yönlendirir
  const CryptoRow = ({ item }: { item: typeof cryptos[0] }) => (
    <TouchableOpacity 
      style={[styles.metalRow, { borderBottomColor: isDark ? '#1e293b' : '#f1f5f9' }]} 
      activeOpacity={0.7}
      onPress={() => router.push({ pathname: '/(tabs)/convert', params: { from: item.symbol } } as any)}
    >
      <View style={styles.metalLeft}>
        <View style={[styles.metalIcon, { backgroundColor: item.color + '20' }]}>
          <Text style={[styles.cryptoIconText, { color: item.color }]}>{item.icon}</Text>
        </View>
        <View>
          <Text style={[styles.metalSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.symbol}</Text>
          <Text style={[styles.metalName, { color: isDark ? '#64748b' : '#94a3b8' }]}>{item.name}</Text>
        </View>
      </View>
      <Text style={[styles.metalPrice, { color: getPriceColor(item.change24h) }]}>
        {formatPrice(item.price)}
      </Text>
      <Text style={[styles.changeValue, { color: getPriceColor(item.change24h) }]}>{formatChange(item.change24h)}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', paddingTop: insets.top }]}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Banner */}
        <Banner />

        {/* Trending Section */}
        <View style={styles.trendingSection}>
          <View style={styles.sectionHeader}>
            <Ionicons name="flame" size={18} color="#f59e0b" />
            <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Trending</Text>
          </View>
          <View style={styles.trendingCards}>
            {trendingAssets.map((trend) => (
              <TrendingCard key={trend.symbol} trend={trend} />
            ))}
          </View>
        </View>

        {/* Metals List */}
        <View style={[styles.listSection, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <TableHeader title="Auxite" />
          {metals.map((item) => <MetalRow key={item.symbol} item={item} />)}
        </View>

        {/* Crypto List */}
        <View style={[styles.listSection, { backgroundColor: isDark ? '#1e293b' : '#fff', marginTop: 16 }]}>
          <TableHeader title="Crypto" />
          {cryptos.map((item) => <CryptoRow key={item.symbol} item={item} />)}
        </View>

        {/* Physical Assets Info Box */}
        <View style={[styles.infoBox, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <View style={styles.infoIconContainer}>
            <Ionicons name="shield-checkmark" size={28} color="#10b981" />
          </View>
          <Text style={[styles.infoText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
            Auxite ekosistemindeki tüm tokenlar, temsil ettikleri metal türüne karşılık gelen fiziksel değer üzerine yapılandırılmıştır; ilgili varlıklar, dünya genelindeki yetkili ve denetimli depolama tesisleri üzerinden muhafaza edilir.
          </Text>
          <TouchableOpacity 
            style={styles.findAssetsBtn}
            activeOpacity={0.8}
            onPress={() => setAllocationModalVisible(true)}
          >
            <Ionicons name="location" size={18} color="#fff" />
            <Text style={styles.findAssetsBtnText}>Varlıklarımı Bul</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Allocation Finder Modal */}
      <Modal
        visible={allocationModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setAllocationModalVisible(false)}
      >
        <View style={[styles.allocationModal, { backgroundColor: isDark ? '#0f172a' : '#fff' }]}>
          <View style={[styles.allocationHeader, { borderBottomColor: isDark ? '#1e293b' : '#e2e8f0' }]}>
            <Text style={[styles.allocationTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Varlıklarımı Bul</Text>
            <TouchableOpacity onPress={() => setAllocationModalVisible(false)} style={styles.closeBtn}>
              <Ionicons name="close-circle" size={32} color={isDark ? '#64748b' : '#94a3b8'} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.allocationContent} showsVerticalScrollIndicator={false}>
            {/* Vault Locations */}
            {[
              { city: 'Zürich', country: 'İsviçre', flag: '🇨🇭', metals: ['AUXG', 'AUXPT'], capacity: '2.4T', security: 'AAA' },
              { city: 'Londra', country: 'İngiltere', flag: '🇬🇧', metals: ['AUXG', 'AUXS'], capacity: '5.1T', security: 'AAA' },
              { city: 'New York', country: 'ABD', flag: '🇺🇸', metals: ['AUXG', 'AUXS', 'AUXPD'], capacity: '3.8T', security: 'AAA' },
              { city: 'Singapur', country: 'Singapur', flag: '🇸🇬', metals: ['AUXG', 'AUXPT', 'AUXPD'], capacity: '1.9T', security: 'AA+' },
              { city: 'Dubai', country: 'BAE', flag: '🇦🇪', metals: ['AUXG'], capacity: '1.2T', security: 'AA+' },
            ].map((vault, index) => (
              <View key={index} style={[styles.vaultCard, { backgroundColor: isDark ? '#1e293b' : '#f8fafc' }]}>
                <View style={styles.vaultHeader}>
                  <Text style={styles.vaultFlag}>{vault.flag}</Text>
                  <View style={styles.vaultInfo}>
                    <Text style={[styles.vaultCity, { color: isDark ? '#fff' : '#0f172a' }]}>{vault.city}</Text>
                    <Text style={[styles.vaultCountry, { color: isDark ? '#64748b' : '#94a3b8' }]}>{vault.country}</Text>
                  </View>
                  <View style={[styles.securityBadge, { backgroundColor: '#10b98120' }]}>
                    <Text style={styles.securityText}>{vault.security}</Text>
                  </View>
                </View>
                <View style={styles.vaultDetails}>
                  <View style={styles.vaultMetals}>
                    {vault.metals.map((metal) => (
                      <View key={metal} style={[styles.metalTag, { backgroundColor: isDark ? '#0f172a' : '#e2e8f0' }]}>
                        {metalIcons[metal] && (
                          <Image source={metalIcons[metal]} style={styles.metalTagIcon} resizeMode="contain" />
                        )}
                        <Text style={[styles.metalTagText, { color: isDark ? '#fff' : '#0f172a' }]}>{metal}</Text>
                      </View>
                    ))}
                  </View>
                  <Text style={[styles.vaultCapacity, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    Kapasite: {vault.capacity}
                  </Text>
                </View>
              </View>
            ))}

            {/* Info Footer */}
            <View style={[styles.infoFooter, { backgroundColor: isDark ? '#1e293b50' : '#f1f5f9' }]}>
              <Ionicons name="information-circle" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              <Text style={[styles.infoFooterText, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                Tüm tesisler Brinks, Loomis ve Malca-Amit gibi uluslararası güvenlik şirketleri tarafından işletilmektedir.
              </Text>
            </View>
          </ScrollView>
        </View>
      </Modal>

      <Modal
        visible={modalVisible}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: isDark ? '#0f172a' : '#fff' }]}>
          <View style={[styles.modalHeader, { paddingTop: insets.top + 8 }]}>
            <View style={styles.modalTitleRow}>
              {currentSelectedMetal && metalIcons[currentSelectedMetal.symbol] ? (
                <Image source={metalIcons[currentSelectedMetal.symbol]} style={styles.modalIcon} resizeMode="contain" />
              ) : (
                <Image source={require('@/assets/images/logos/auxite-logo.png')} style={styles.modalIcon} resizeMode="contain" />
              )}
              <View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
                    {currentSelectedMetal?.symbol}/USDT
                  </Text>
                  <View style={[styles.changeBadge, { backgroundColor: (currentSelectedMetal?.change24h || 0) >= 0 ? '#10b98120' : '#ef444420' }]}>
                    <Text style={{ color: getPriceColor(currentSelectedMetal?.change24h || 0), fontSize: 11, fontWeight: '600' }}>
                      {(currentSelectedMetal?.change24h || 0) >= 0 ? '↑' : '↓'} {formatChange(currentSelectedMetal?.change24h || 0)}
                    </Text>
                  </View>
                </View>
                <Text style={[styles.modalSubtitle, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                  {currentSelectedMetal?.name === 'Gold' ? 'Auxite Altın' : 
                   currentSelectedMetal?.name === 'Silver' ? 'Auxite Gümüş' :
                   currentSelectedMetal?.name === 'Platinum' ? 'Auxite Platin' :
                   currentSelectedMetal?.name === 'Palladium' ? 'Auxite Paladyum' :
                   currentSelectedMetal?.name}
                </Text>
              </View>
            </View>
            <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeBtn}>
              <Ionicons name="close" size={28} color={isDark ? '#64748b' : '#94a3b8'} />
            </TouchableOpacity>
          </View>

          {/* Tab Bar */}
          <View style={[styles.modalTabBar, { borderBottomColor: isDark ? '#1e293b' : '#e2e8f0' }]}>
            {(['price', 'info', 'data'] as const).map((tab) => (
              <TouchableOpacity
                key={tab}
                style={[styles.modalTabBtn, modalTab === tab && styles.modalTabBtnActive]}
                onPress={() => setModalTab(tab)}
              >
                <Text style={[
                  styles.modalTabText, 
                  { color: modalTab === tab ? '#10b981' : (isDark ? '#64748b' : '#94a3b8') }
                ]}>
                  {tab === 'price' ? 'Fiyat' : tab === 'info' ? 'Bilgiler' : 'İşlem Verileri'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Tab Content */}
          {modalTab === 'price' && (
            <>
              {/* Price Header */}
              <View style={styles.priceHeaderRow}>
                <View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={[styles.modalPrice, { color: getPriceColor(currentSelectedMetal?.change24h || 0) }]}>
                      {formatPrice(currentSelectedMetal?.price || 0)}
                    </Text>
                    <View style={styles.liveBadge}>
                      <View style={styles.liveDot} />
                      <Text style={styles.liveText}>LIVE</Text>
                    </View>
                  </View>
                </View>
                <View style={styles.priceStats}>
                  <Text style={[styles.priceStat, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    24s Yüksek <Text style={{ color: '#10b981' }}>${((currentSelectedMetal?.price || 0) * 1.015).toFixed(2)}</Text>
                  </Text>
                  <Text style={[styles.priceStat, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    24s Düşük <Text style={{ color: '#ef4444' }}>${((currentSelectedMetal?.price || 0) * 0.985).toFixed(2)}</Text>
                  </Text>
                  <Text style={[styles.priceStat, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    24s Hacim <Text style={{ color: isDark ? '#fff' : '#0f172a' }}>11.87M</Text>
                  </Text>
                </View>
              </View>

              {/* Chart */}
              <View style={styles.chartContainer}>
                {currentSelectedMetal && currentSelectedMetal.price > 0 ? (
                  <WebView
                    key={`${currentSelectedMetal.symbol}-${isDark}`}
                    source={{ html: getAdvancedChartHtml(currentSelectedMetal) }}
                    style={styles.chart}
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    scrollEnabled={false}
                    startInLoadingState={true}
                    originWhitelist={['*']}
                    renderLoading={() => (
                      <View style={[styles.loadingContainer, { backgroundColor: isDark ? '#0f172a' : '#fff' }]}>
                        <Text style={{ color: isDark ? '#64748b' : '#94a3b8', fontSize: 14 }}>Loading chart...</Text>
                      </View>
                    )}
                  />
                ) : (
                  <View style={[styles.loadingContainer, { backgroundColor: isDark ? '#0f172a' : '#fff' }]}>
                    <Text style={{ color: isDark ? '#64748b' : '#94a3b8', fontSize: 14 }}>Loading price data...</Text>
                  </View>
                )}
              </View>
            </>
          )}

          {modalTab === 'info' && (
            <ScrollView style={styles.tabContentScroll} showsVerticalScrollIndicator={false}>
              <View style={[styles.infoCard, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
                <Text style={[styles.infoCardTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Genel Bilgiler</Text>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Sembol</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>{currentSelectedMetal?.symbol}/USDT</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Blockchain</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>Base Sepolia</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Kontrat</Text><Text style={[styles.infoValue, { color: '#3b82f6' }]}>0x1234...5678</Text></View>
              </View>
              <View style={[styles.infoCard, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
                <Text style={[styles.infoCardTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Teminat</Text>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Teminat Oranı</Text><Text style={[styles.infoValue, { color: '#10b981' }]}>100%</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Saklama</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>Brinks</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Denetçi</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>Bureau Veritas</Text></View>
              </View>
            </ScrollView>
          )}

          {modalTab === 'data' && (
            <ScrollView style={styles.tabContentScroll} showsVerticalScrollIndicator={false}>
              <View style={[styles.infoCard, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
                <Text style={[styles.infoCardTitle, { color: isDark ? '#fff' : '#0f172a' }]}>İşlem Verileri</Text>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>24s İşlem</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>1,234</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>24s Hacim</Text><Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>$11.87M</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Alış Spread</Text><Text style={[styles.infoValue, { color: '#10b981' }]}>{spread.buy}%</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Satış Spread</Text><Text style={[styles.infoValue, { color: '#ef4444' }]}>{spread.sell}%</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Alış Fiyatı</Text><Text style={[styles.infoValue, { color: '#10b981' }]}>${(currentSelectedMetal?.buyPrice || 0).toFixed(2)}/g</Text></View>
                <View style={styles.infoRow}><Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>Satış Fiyatı</Text><Text style={[styles.infoValue, { color: '#ef4444' }]}>${(currentSelectedMetal?.sellPrice || 0).toFixed(2)}/g</Text></View>
              </View>
            </ScrollView>
          )}

          {/* Minimal Action Buttons */}
          <View style={[styles.minimalActions, { borderTopColor: isDark ? '#1e293b' : '#e2e8f0' }]}>
            <TouchableOpacity 
              style={[styles.minimalBtn, { backgroundColor: '#10b981' }]} 
              activeOpacity={0.8}
              onPress={() => {
                setTradeMode('buy');
                setTradeAmount('');
                setOrderType('market');
                setLimitPrice('');
                setTradeModalVisible(true);
              }}
            >
              <Text style={styles.minimalBtnText}>Al</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.minimalBtn, { backgroundColor: '#ef4444' }]} 
              activeOpacity={0.8}
              onPress={() => {
                setTradeMode('sell');
                setTradeAmount('');
                setOrderType('market');
                setLimitPrice('');
                setTradeModalVisible(true);
              }}
            >
              <Text style={styles.minimalBtnText}>Sat</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.minimalBtn, { backgroundColor: '#f59e0b' }]} 
              activeOpacity={0.8}
              onPress={() => Alert.alert('DCA', 'DCA özelliği yakında aktif olacak')}
            >
              <Text style={styles.minimalBtnText}>DCA</Text>
            </TouchableOpacity>
          </View>

          {/* Orders Section */}
          <View style={[styles.ordersSection, { backgroundColor: isDark ? '#1e293b' : '#f8fafc', paddingBottom: insets.bottom + 8 }]}>
            <View style={styles.ordersColumns}>
              {/* Gerçekleşen Emirler */}
              <View style={styles.ordersColumn}>
                <Text style={[styles.ordersColumnTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Gerçekleşen</Text>
                {completedOrders.slice(0, 3).map((order) => (
                  <View key={order.id} style={[styles.orderItem, { borderBottomColor: isDark ? '#334155' : '#e2e8f0' }]}>
                    <View style={styles.orderItemLeft}>
                      <View style={[styles.orderTypeDot, { backgroundColor: order.type === 'buy' ? '#10b981' : '#ef4444' }]} />
                      <Text style={[styles.orderAmount, { color: isDark ? '#fff' : '#0f172a' }]}>{order.amount}</Text>
                    </View>
                    <Text style={[styles.orderPrice, { color: isDark ? '#94a3b8' : '#64748b' }]}>${order.price.toFixed(2)}</Text>
                    <Text style={[styles.orderDate, { color: isDark ? '#64748b' : '#94a3b8' }]}>{order.date}</Text>
                  </View>
                ))}
              </View>
              {/* Bekleyen Emirler */}
              <View style={styles.ordersColumn}>
                <Text style={[styles.ordersColumnTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Bekleyen</Text>
                {pendingOrders.slice(0, 3).map((order) => (
                  <View key={order.id} style={[styles.orderItem, { borderBottomColor: isDark ? '#334155' : '#e2e8f0' }]}>
                    <View style={styles.orderItemLeft}>
                      <View style={[styles.orderTypeDot, { backgroundColor: order.type === 'buy' ? '#10b981' : '#ef4444' }]} />
                      <Text style={[styles.orderAmount, { color: isDark ? '#fff' : '#0f172a' }]}>{order.amount}</Text>
                    </View>
                    <Text style={[styles.orderPrice, { color: isDark ? '#94a3b8' : '#64748b' }]}>${order.price.toFixed(2)}</Text>
                    <TouchableOpacity onPress={() => setPendingOrders(prev => prev.filter(o => o.id !== order.id))}>
                      <Ionicons name="close-circle" size={16} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                ))}
                {pendingOrders.length === 0 && (
                  <Text style={[styles.noOrders, { color: isDark ? '#64748b' : '#94a3b8' }]}>Emir yok</Text>
                )}
              </View>
            </View>
          </View>
        </View>
      </Modal>

      {/* Trade Modal (Buy/Sell) */}
      <Modal
        visible={tradeModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setTradeModalVisible(false)}
      >
        <View style={[styles.tradeModalContainer, { backgroundColor: isDark ? '#0f172a' : '#fff' }]}>
          {/* Header with Metal Icon */}
          <View style={[styles.tradeModalHeader, { borderBottomColor: isDark ? '#1e293b' : '#e2e8f0' }]}>
            <View style={styles.tradeModalHeaderLeft}>
              <View style={[styles.tradeModalIcon, { backgroundColor: (currentSelectedMetal?.color || '#EAB308') + '20' }]}>
                {currentSelectedMetal && metalIcons[currentSelectedMetal.symbol] && (
                  <Image source={metalIcons[currentSelectedMetal.symbol]} style={styles.tradeModalIconImage} resizeMode="contain" />
                )}
              </View>
              <Text style={[styles.tradeModalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
                {tradeMode === 'buy' ? 'Buy' : 'Sell'} {currentSelectedMetal?.symbol}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setTradeModalVisible(false)} style={styles.closeBtn}>
              <Ionicons name="close" size={24} color={isDark ? '#64748b' : '#94a3b8'} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.tradeModalContent} showsVerticalScrollIndicator={false}>
            {/* AUXM Bonus Banner - Convert'e link */}
            <TouchableOpacity 
              style={styles.bonusBanner}
              activeOpacity={0.7}
              onPress={() => {
                setTradeModalVisible(false);
                setModalVisible(false);
                // Navigate to Convert tab
                router.push('/(tabs)/convert');
              }}
            >
              <Text style={{ fontSize: 14 }}>🎁</Text>
              <Text style={styles.bonusBannerText}>
                AUXM ile işlem yap %2 bonus kazan
              </Text>
              <Ionicons name="chevron-forward" size={14} color="#a855f7" />
            </TouchableOpacity>

            {/* Market / Limit Tabs */}
            <View style={[styles.orderTypeTabs, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
              <TouchableOpacity
                style={[
                  styles.orderTypeTab,
                  orderType === 'market' && styles.orderTypeTabActive
                ]}
                onPress={() => setOrderType('market')}
              >
                <Ionicons 
                  name="flash" 
                  size={16} 
                  color={orderType === 'market' ? '#fff' : isDark ? '#64748b' : '#94a3b8'} 
                />
                <Text style={[
                  styles.orderTypeTabText,
                  { color: orderType === 'market' ? '#fff' : isDark ? '#64748b' : '#94a3b8' }
                ]}>
                  Piyasa
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.orderTypeTab,
                  orderType === 'limit' && styles.orderTypeTabActive
                ]}
                onPress={() => setOrderType('limit')}
              >
                <Ionicons 
                  name="time" 
                  size={16} 
                  color={orderType === 'limit' ? '#fff' : isDark ? '#64748b' : '#94a3b8'} 
                />
                <Text style={[
                  styles.orderTypeTabText,
                  { color: orderType === 'limit' ? '#fff' : isDark ? '#64748b' : '#94a3b8' }
                ]}>
                  Limit
                </Text>
              </TouchableOpacity>
            </View>

            {/* Limit Price Input (only for limit orders) */}
            {orderType === 'limit' && (
              <View style={styles.limitPriceSection}>
                <Text style={[styles.tradeLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                  Limit Fiyatı (USD)
                </Text>
                <View style={[
                  styles.amountInputContainer, 
                  { 
                    backgroundColor: isDark ? '#1e293b' : '#f8fafc',
                    borderColor: isDark ? '#334155' : '#e2e8f0',
                  }
                ]}>
                  <Text style={[styles.dollarSign, { color: isDark ? '#64748b' : '#94a3b8' }]}>$</Text>
                  <TextInput
                    style={[styles.limitPriceInput, { color: isDark ? '#fff' : '#0f172a' }]}
                    value={limitPrice}
                    onChangeText={setLimitPrice}
                    placeholder={(currentSelectedMetal?.price || 0).toFixed(2)}
                    placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
                    keyboardType="decimal-pad"
                  />
                  <Text style={[styles.amountCurrency, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                    /gram
                  </Text>
                </View>
                <View style={styles.limitPriceHint}>
                  <Text style={[styles.limitPriceHintText, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    Güncel: ${(currentSelectedMetal?.price || 0).toFixed(2)}/g
                  </Text>
                  {limitPrice && parseFloat(limitPrice) < (currentSelectedMetal?.price || 0) && tradeMode === 'buy' && (
                    <Text style={styles.limitPriceSaving}>
                      %{(((currentSelectedMetal?.price || 0) - parseFloat(limitPrice)) / (currentSelectedMetal?.price || 1) * 100).toFixed(1)} tasarruf
                    </Text>
                  )}
                </View>
              </View>
            )}

            {/* Payment Method Selection */}
            <Text style={[styles.tradeLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {tradeMode === 'buy' ? 'Ödeme Yöntemi' : 'Alacağınız'}
            </Text>
            <View style={styles.currencyRow}>
              {[
                { id: 'AUXM', icon: '💵', color: '#a855f7' },
                { id: 'USDT', icon: '₮', color: '#26a17b' },
                { id: 'BTC', icon: '₿', color: '#f7931a' },
                { id: 'ETH', icon: 'Ξ', color: '#627eea' },
                { id: 'XRP', icon: '✕', color: '#00aae4' },
                { id: 'SOL', icon: '◎', color: '#9945ff' },
              ].map((currency) => (
                <TouchableOpacity
                  key={currency.id}
                  style={[
                    styles.currencyBtn,
                    { 
                      backgroundColor: selectedCurrency === currency.id 
                        ? currency.color + '25' 
                        : isDark ? '#1e293b' : '#f1f5f9',
                      borderColor: selectedCurrency === currency.id 
                        ? currency.color 
                        : isDark ? '#334155' : '#e2e8f0',
                    }
                  ]}
                  onPress={() => setSelectedCurrency(currency.id)}
                >
                  <Text style={[styles.currencyIcon, { color: currency.color }]}>{currency.icon}</Text>
                  <Text style={[
                    styles.currencyName, 
                    { color: selectedCurrency === currency.id ? currency.color : isDark ? '#fff' : '#0f172a' }
                  ]}>
                    {currency.id}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Balance Display */}
            <View style={styles.balanceRow}>
              <Text style={[styles.balanceLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Bakiye:</Text>
              <View style={styles.balanceValues}>
                <Text style={[styles.balanceAmount, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {selectedCurrency === 'AUXM' ? balances.auxm.toFixed(2) :
                   selectedCurrency === 'ETH' ? balances.eth.toFixed(4) :
                   selectedCurrency === 'USDT' ? balances.usdt.toFixed(2) :
                   selectedCurrency === 'BTC' ? '0.0025' :
                   selectedCurrency === 'XRP' ? '150.00' :
                   selectedCurrency === 'SOL' ? '2.50' : '0.00'
                  } {selectedCurrency}
                </Text>
                {selectedCurrency === 'AUXM' && balances.bonusAuxm > 0 && (
                  <Text style={styles.bonusAmount}>+{balances.bonusAuxm.toFixed(2)} Bonus</Text>
                )}
              </View>
            </View>

            {/* Amount Input */}
            <Text style={[styles.tradeLabel, { color: isDark ? '#94a3b8' : '#64748b', marginTop: 8 }]}>
              Miktar
            </Text>
            <View style={[
              styles.amountInputContainer, 
              { 
                backgroundColor: isDark ? '#1e293b' : '#f8fafc',
                borderColor: isDark ? '#334155' : '#e2e8f0',
              }
            ]}>
              <TextInput
                style={[styles.amountInput, { color: isDark ? '#fff' : '#0f172a' }]}
                value={tradeAmount}
                onChangeText={setTradeAmount}
                placeholder="0.00"
                placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
                keyboardType="decimal-pad"
              />
              <Text style={[styles.amountCurrency, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                {selectedCurrency}
              </Text>
            </View>

            {/* Quick Amount Buttons */}
            <View style={styles.quickAmounts}>
              {['25%', '50%', '75%', 'MAX'].map((pct) => (
                <TouchableOpacity
                  key={pct}
                  style={[styles.quickAmountBtn, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}
                  onPress={() => {
                    const balance = selectedCurrency === 'AUXM' 
                      ? balances.auxm + balances.bonusAuxm 
                      : selectedCurrency === 'ETH' 
                        ? balances.eth 
                        : selectedCurrency === 'USDT'
                          ? balances.usdt
                          : selectedCurrency === 'BTC'
                            ? 0.0025
                            : selectedCurrency === 'XRP'
                              ? 150
                              : 2.5;
                    const multiplier = pct === 'MAX' ? 1 : parseInt(pct) / 100;
                    setTradeAmount((balance * multiplier).toFixed(selectedCurrency === 'BTC' || selectedCurrency === 'ETH' ? 4 : 2));
                  }}
                >
                  <Text style={[styles.quickAmountText, { color: isDark ? '#94a3b8' : '#64748b' }]}>{pct}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Arrow Divider */}
            <View style={styles.arrowDivider}>
              <View style={[styles.arrowCircle, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
                <Ionicons name="swap-vertical" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              </View>
            </View>

            {/* You Receive */}
            <Text style={[styles.tradeLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {tradeMode === 'buy' ? 'Alacağınız' : 'Ödeyeceğiniz'}
            </Text>
            <View style={[
              styles.receiveBox, 
              { 
                backgroundColor: isDark ? '#1e293b' : '#f8fafc',
                borderColor: isDark ? '#334155' : '#e2e8f0',
              }
            ]}>
              <View style={[styles.receiveIcon, { backgroundColor: (currentSelectedMetal?.color || '#EAB308') + '20' }]}>
                {currentSelectedMetal && metalIcons[currentSelectedMetal.symbol] && (
                  <Image source={metalIcons[currentSelectedMetal.symbol]} style={styles.receiveIconImage} resizeMode="contain" />
                )}
              </View>
              <View style={styles.receiveInfo}>
                <Text style={[styles.receiveAmount, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {currentSelectedMetal && tradeAmount 
                    ? (parseFloat(tradeAmount) / (orderType === 'limit' && limitPrice ? parseFloat(limitPrice) : currentSelectedMetal.price || 1)).toFixed(4)
                    : '0.0000'
                  } {currentSelectedMetal?.symbol}
                </Text>
                <Text style={[styles.receivePrice, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                  @ ${orderType === 'limit' && limitPrice ? parseFloat(limitPrice).toFixed(2) : (currentSelectedMetal?.price || 0).toFixed(2)}/g
                </Text>
              </View>
            </View>

            {/* Trade Summary */}
            <View style={[styles.tradeSummary, { backgroundColor: isDark ? '#1e293b50' : '#f1f5f9' }]}>
              <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>İşlem Tipi</Text>
                <Text style={[styles.summaryValue, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {orderType === 'market' ? '⚡ Piyasa' : '⏱️ Limit'}
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Fiyat</Text>
                <Text style={[styles.summaryValue, { color: isDark ? '#fff' : '#0f172a' }]}>
                  ${orderType === 'limit' && limitPrice ? parseFloat(limitPrice).toFixed(2) : (currentSelectedMetal?.price || 0).toFixed(2)}/g
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>İşlem Ücreti</Text>
                <Text style={[styles.summaryValue, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {tradeAmount && parseFloat(tradeAmount) > 0 
                    ? '$' + (parseFloat(tradeAmount) * 0.001).toFixed(2) + ' (0.1%)'
                    : '0.1%'
                  }
                </Text>
              </View>
            </View>

            {/* Limit Order Info */}
            {orderType === 'limit' && (
              <View style={[styles.limitOrderInfo, { backgroundColor: isDark ? '#3b82f620' : '#eff6ff' }]}>
                <Ionicons name="information-circle" size={16} color="#3b82f6" />
                <Text style={styles.limitOrderInfoText}>
                  Emir, belirlediğiniz fiyata ulaşıldığında otomatik gerçekleşir. İstediğiniz zaman iptal edebilirsiniz.
                </Text>
              </View>
            )}
          </ScrollView>

          {/* Trade Button */}
          <View style={[styles.tradeButtonContainer, { paddingBottom: insets.bottom + 12 }]}>
            <TouchableOpacity
              style={[
                styles.tradeButton,
                { 
                  backgroundColor: !tradeAmount || parseFloat(tradeAmount) <= 0 || isProcessing || isTrading || !address
                    ? isDark ? '#334155' : '#cbd5e1'
                    : tradeMode === 'buy' ? '#10b981' : '#ef4444'
                }
              ]}
              disabled={!tradeAmount || parseFloat(tradeAmount) <= 0 || isProcessing || isTrading || !address}
              onPress={async () => {
                if (!address) {
                  Alert.alert('Hata', 'Lütfen önce cüzdanınızı bağlayın');
                  return;
                }
                
                if (!currentSelectedMetal) return;
                
                setIsProcessing(true);
                try {
                  const amount = parseFloat(tradeAmount);
                  
                  // Limit Order
                  if (orderType === 'limit') {
                    const price = parseFloat(limitPrice);
                    if (!price || price <= 0) {
                      Alert.alert('Hata', 'Geçerli bir limit fiyatı girin');
                      setIsProcessing(false);
                      return;
                    }
                    
                    // Gram hesapla
                    const grams = amount / price;
                    
                    const result = await createOrder({
                      type: tradeMode,
                      metal: currentSelectedMetal.symbol as 'AUXG' | 'AUXS' | 'AUXPT' | 'AUXPD',
                      grams: grams,
                      limitPrice: price,
                      paymentMethod: selectedCurrency as 'AUXM' | 'USDT' | 'USD',
                    });
                    
                    if (result.success) {
                      Alert.alert(
                        'Başarılı',
                        `Limit emri oluşturuldu: ${grams.toFixed(4)}g ${currentSelectedMetal.symbol} @ $${price.toFixed(2)}/g`,
                        [{ text: 'Tamam', onPress: () => setTradeModalVisible(false) }]
                      );
                    } else {
                      Alert.alert('Hata', result.error || 'Emir oluşturulamadı');
                    }
                  } 
                  // Market Order
                  else {
                    let result;
                    
                    if (tradeMode === 'buy') {
                      result = await executeBuy({
                        fromToken: selectedCurrency,
                        toToken: currentSelectedMetal.symbol,
                        amount: amount,
                      });
                    } else {
                      // Sell: metal gönder, AUXM al
                      const grams = amount / (currentSelectedMetal.price || 1);
                      result = await executeSell({
                        fromToken: currentSelectedMetal.symbol,
                        toToken: 'AUXM',
                        amount: grams,
                      });
                    }
                    
                    if (result.success && result.transaction) {
                      // Record trend
                      fetch('https://auxite-wallet.vercel.app/api/trends', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ 
                          symbol: currentSelectedMetal.symbol, 
                          action: tradeMode 
                        })
                      }).catch(() => {});
                      
                      Alert.alert(
                        'Başarılı',
                        `${tradeMode === 'buy' ? 'Satın alındı' : 'Satıldı'}: ${result.transaction.toAmount.toFixed(4)} ${result.transaction.toToken}`,
                        [{ text: 'Tamam', onPress: () => setTradeModalVisible(false) }]
                      );
                    } else {
                      Alert.alert('Hata', result.error || 'İşlem başarısız');
                    }
                  }
                } catch (e: any) {
                  console.error('Trade error:', e);
                  Alert.alert('Hata', e.message || 'İşlem sırasında hata oluştu');
                } finally {
                  setIsProcessing(false);
                }
              }}
            >
              {isProcessing || isTrading ? (
                <Text style={styles.tradeButtonText}>İşleniyor...</Text>
              ) : !address ? (
                <Text style={styles.tradeButtonText}>Cüzdan Bağlayın</Text>
              ) : (
                <>
                  <Ionicons 
                    name={tradeMode === 'buy' ? 'arrow-up-circle' : 'arrow-down-circle'} 
                    size={22} 
                    color="#fff" 
                  />
                  <Text style={styles.tradeButtonText}>
                    {orderType === 'limit' ? 'Emir Ver' : (tradeMode === 'buy' ? 'Satın Al' : 'Sat')} {currentSelectedMetal?.symbol}
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 12 },
  
  // Banner styles
  bannerContainer: { marginBottom: 16 },
  banner: { borderRadius: 16, overflow: 'hidden' },
  bannerContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  bannerTextContainer: { flex: 1 },
  bannerTitle: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
  bannerSubtitle: { fontSize: 12 },
  bannerBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  bannerBadgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },

  // Trending section
  trendingSection: { marginBottom: 16 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, paddingHorizontal: 2 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  trendingCards: { flexDirection: 'row', gap: 8 },
  trendingCard: { 
    flex: 1,
    padding: 10, 
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  trendingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  trendingIcon: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  trendingIconImage: { width: 18, height: 18 },
  trendingCryptoIcon: { fontSize: 14, fontWeight: '700' },
  trendBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 5, paddingVertical: 2, borderRadius: 6, gap: 2 },
  trendBadgeText: { fontSize: 8, fontWeight: '600' },
  trendingSymbol: { fontSize: 12, fontWeight: '700', marginBottom: 4 },
  trendingPriceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  trendingPrice: { fontSize: 12, fontWeight: '700' },
  trendingChange: { fontSize: 9, fontWeight: '600' },
  trendingBar: { flexDirection: 'row', height: 3, borderRadius: 2, overflow: 'hidden', backgroundColor: '#e2e8f0' },
  trendingBarFill: { height: '100%' },
  trendingBarLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  trendingBarLabel: { fontSize: 8, fontWeight: '500' },

  // List section
  listSection: { borderRadius: 12, overflow: 'hidden', marginBottom: 4 },
  tableHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingTop: 12, paddingBottom: 6 },
  headerTitle: { flex: 1, fontSize: 13, fontWeight: '600', marginLeft: 44 },
  headerLabel: { width: 70, fontSize: 9, textAlign: 'center' },

  metalRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1 },
  metalLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  metalIcon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  metalImage: { width: 22, height: 22 },
  auxmIconFallback: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  auxmIconText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  cryptoIconText: {
    fontSize: 16,
    fontWeight: '700',
  },
  usdtIconFallback: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  usdtIconText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  metalSymbol: { fontSize: 13, fontWeight: '600' },
  metalName: { fontSize: 10, marginTop: 1 },
  metalPrice: { width: 70, fontSize: 12, fontWeight: '600', textAlign: 'center' },
  changeValue: { width: 70, fontSize: 11, fontWeight: '500', textAlign: 'right' },

  modalContainer: { flex: 1 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 8 },
  closeBtn: { padding: 4 },
  modalTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  modalIcon: { width: 36, height: 36 },
  modalTitle: { fontSize: 18, fontWeight: 'bold' },
  modalSubtitle: { fontSize: 11 },
  
  priceSection: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 12, gap: 10 },
  modalPrice: { fontSize: 28, fontWeight: 'bold' },
  changeBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, gap: 4 },
  modalChange: { fontSize: 13, fontWeight: '600' },
  
  chartContainer: { flex: 1 },
  chart: { flex: 1 },
  loadingContainer: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center' },

  actionButtons: { flexDirection: 'row', paddingHorizontal: 16, paddingTop: 12, gap: 12 },
  actionBtn: { 
    flex: 1, 
    flexDirection: 'row',
    alignItems: 'center', 
    justifyContent: 'center',
    paddingVertical: 14, 
    borderRadius: 14,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  buyBtn: { backgroundColor: '#10b981' },
  sellBtn: { backgroundColor: '#ef4444' },
  actionBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },

  // Info Box styles
  infoBox: {
    marginTop: 16,
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
  },
  infoIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#10b98115',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    marginBottom: 16,
  },
  findAssetsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3b82f6',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    gap: 8,
  },
  findAssetsBtnText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },

  // Allocation Modal styles
  allocationModal: {
    flex: 1,
  },
  allocationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  allocationTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  allocationContent: {
    flex: 1,
    padding: 16,
  },
  vaultCard: {
    padding: 14,
    borderRadius: 12,
    marginBottom: 12,
  },
  vaultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  vaultFlag: {
    fontSize: 28,
    marginRight: 12,
  },
  vaultInfo: {
    flex: 1,
  },
  vaultCity: {
    fontSize: 15,
    fontWeight: '600',
  },
  vaultCountry: {
    fontSize: 12,
    marginTop: 2,
  },
  securityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  securityText: {
    color: '#10b981',
    fontSize: 11,
    fontWeight: '700',
  },
  vaultDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  vaultMetals: {
    flexDirection: 'row',
    gap: 6,
  },
  metalTag: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    gap: 4,
  },
  metalTagIcon: {
    width: 14,
    height: 14,
  },
  metalTagText: {
    fontSize: 10,
    fontWeight: '600',
  },
  vaultCapacity: {
    fontSize: 11,
  },
  infoFooter: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 12,
    borderRadius: 10,
    marginTop: 8,
    gap: 10,
  },
  infoFooterText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 16,
  },

  // Trade Modal styles
  tradeModalContainer: {
    flex: 1,
  },
  tradeModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  tradeModalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  tradeModalIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tradeModalIconImage: {
    width: 20,
    height: 20,
  },
  tradeModalTitle: {
    fontSize: 15,
    fontWeight: '600',
  },
  tradeModalContent: {
    flex: 1,
    padding: 16,
  },
  bonusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#a855f710',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 12,
    gap: 6,
  },
  bonusBannerText: {
    flex: 1,
    fontSize: 11,
    color: '#a855f7',
    fontWeight: '500',
  },
  orderTypeTabs: {
    flexDirection: 'row',
    borderRadius: 10,
    padding: 3,
    marginBottom: 14,
  },
  orderTypeTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: 8,
    gap: 5,
  },
  orderTypeTabActive: {
    backgroundColor: '#3b82f6',
  },
  orderTypeTabText: {
    fontSize: 12,
    fontWeight: '500',
  },
  limitPriceSection: {
    marginBottom: 14,
  },
  dollarSign: {
    fontSize: 18,
    fontWeight: '600',
    marginRight: 4,
  },
  limitPriceInput: {
    flex: 1,
    fontSize: 18,
    fontFamily: 'monospace',
    fontWeight: '600',
    paddingVertical: 10,
  },
  limitPriceHint: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  limitPriceHintText: {
    fontSize: 10,
  },
  limitPriceSaving: {
    fontSize: 10,
    color: '#10b981',
    fontWeight: '600',
  },
  currencyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  tradeLabel: {
    fontSize: 11,
    marginBottom: 8,
    fontWeight: '500',
  },
  currencyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 5,
    paddingVertical: 5,
    borderRadius: 6,
    borderWidth: 1,
    gap: 2,
  },
  currencyIcon: {
    fontSize: 10,
  },
  currencyName: {
    fontSize: 8,
    fontWeight: '600',
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
    marginTop: 4,
  },
  balanceLabel: {
    fontSize: 11,
  },
  balanceValues: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  balanceAmount: {
    fontSize: 11,
    fontFamily: 'monospace',
    fontWeight: '500',
  },
  bonusAmount: {
    fontSize: 10,
    fontFamily: 'monospace',
    color: '#a855f7',
  },
  amountInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 2,
    marginBottom: 10,
  },
  amountInput: {
    flex: 1,
    fontSize: 20,
    fontFamily: 'monospace',
    fontWeight: '600',
    paddingVertical: 10,
  },
  amountCurrency: {
    fontSize: 13,
    fontWeight: '500',
  },
  quickAmounts: {
    flexDirection: 'row',
    gap: 6,
    marginBottom: 14,
  },
  quickAmountBtn: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 6,
    alignItems: 'center',
  },
  quickAmountText: {
    fontSize: 11,
    fontWeight: '500',
  },
  arrowDivider: {
    alignItems: 'center',
    marginVertical: 6,
  },
  arrowCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  receiveBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    gap: 10,
    marginBottom: 14,
  },
  receiveIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  receiveIconImage: {
    width: 24,
    height: 24,
  },
  receiveInfo: {
    flex: 1,
  },
  receiveAmount: {
    fontSize: 17,
    fontFamily: 'monospace',
    fontWeight: '600',
  },
  receivePrice: {
    fontSize: 11,
    marginTop: 2,
  },
  bonusInfoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#a855f715',
    borderRadius: 8,
    padding: 10,
    gap: 6,
    marginBottom: 14,
  },
  bonusInfoIcon: {
    fontSize: 14,
  },
  bonusInfoText: {
    fontSize: 11,
    color: '#a855f7',
    fontFamily: 'monospace',
  },
  tradeSummary: {
    borderRadius: 10,
    padding: 12,
    marginBottom: 14,
  },
  limitOrderInfo: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 10,
    borderRadius: 8,
    gap: 8,
    marginBottom: 14,
  },
  limitOrderInfoText: {
    flex: 1,
    fontSize: 11,
    color: '#3b82f6',
    lineHeight: 15,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  summaryLabel: {
    fontSize: 12,
  },
  summaryValue: {
    fontSize: 12,
    fontWeight: '500',
  },
  tradeButtonContainer: {
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  tradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    gap: 8,
  },
  tradeButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },

  // New Modal Tab Styles
  modalTabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    paddingHorizontal: 12,
  },
  modalTabBtn: {
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  modalTabBtnActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#10b981',
  },
  modalTabText: {
    fontSize: 13,
    fontWeight: '600',
  },
  tabContentScroll: {
    flex: 1,
    padding: 16,
  },
  priceHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#10b98120',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10b981',
  },
  liveText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#10b981',
  },
  priceStats: {
    alignItems: 'flex-end',
  },
  priceStat: {
    fontSize: 10,
    marginBottom: 2,
  },
  infoCard: {
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
  },
  infoCardTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  infoLabel: {
    fontSize: 12,
  },
  infoValue: {
    fontSize: 12,
    fontWeight: '500',
  },
  minimalActions: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderTopWidth: 1,
  },
  minimalBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  minimalBtnText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700',
  },
  ordersSection: {
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  ordersColumns: {
    flexDirection: 'row',
    gap: 12,
  },
  ordersColumn: {
    flex: 1,
  },
  ordersColumnTitle: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  orderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
  },
  orderItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  orderTypeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  orderAmount: {
    fontSize: 11,
    fontWeight: '600',
  },
  orderPrice: {
    fontSize: 10,
  },
  orderDate: {
    fontSize: 9,
  },
  noOrders: {
    fontSize: 10,
    textAlign: 'center',
    marginTop: 10,
  },
});
