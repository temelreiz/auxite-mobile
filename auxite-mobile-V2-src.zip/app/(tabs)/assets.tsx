// app/(tabs)/assets.tsx
// Varlıklarım / My Assets - API Entegreli, Tab Menü

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  useColorScheme,
  RefreshControl,
  Image,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useStore } from '@/stores/useStore';

// Import Modals
import { DepositMethodModal, CoinSelectModal, DepositAddressModal, UsdDepositModal, DepositCoin } from '@/components/DepositModals';
import QuickBuyModal from '@/components/QuickBuyModal';
import { WithdrawModal, SendModal } from '@/components/WalletModals';
import { LockedAssetsModal } from '@/components/LockedAssetsModal';

const API_BASE_URL = 'https://auxite-wallet.vercel.app';
const TROY_OZ_TO_GRAM = 31.1035;

const metalIcons: Record<string, any> = {
  AUXG: require('@/assets/images/metals/gold.png'),
  AUXS: require('@/assets/images/metals/silver.png'),
  AUXPT: require('@/assets/images/metals/platinum.png'),
  AUXPD: require('@/assets/images/metals/palladium.png'),
};

interface Asset {
  symbol: string;
  name: string;
  balance: number;
  price: number;
  value: number;
  change24h: number;
  color: string;
  icon?: string;
}

interface Allocation {
  id: string;
  metal: string;
  grams: number;
  custodian: string;
  timestamp: string;
  txHash?: string;
}

interface StakePosition {
  id: string;
  metalSymbol: string;
  amountGrams: number;
  durationMonths: number;
  apyPercent: number;
  progress: number;
  timeRemaining?: number;
  isMatured: boolean;
  shortCode: string;
  expectedRewardGrams: number;
  startDate?: string;
  endDate?: string;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw' | 'buy' | 'sell' | 'stake' | 'convert' | 'allocate';
  asset: string;
  amount: number;
  value: number;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  txHash?: string;
}

const METAL_INFO: Record<string, { emoji: string; color: string; name: string }> = {
  AUXG: { emoji: '🥇', color: '#f59e0b', name: 'Gold' },
  AUXS: { emoji: '🥈', color: '#94a3b8', name: 'Silver' },
  AUXPT: { emoji: '💎', color: '#22d3ee', name: 'Platinum' },
  AUXPD: { emoji: '🔶', color: '#fb7185', name: 'Palladium' },
};

const CUSTODIAN_NAMES: Record<string, string> = {
  zurich: 'Zurich 🇨🇭',
  singapore: 'Singapore 🇸🇬',
  london: 'London 🇬🇧',
  dubai: 'Dubai 🇦🇪',
};

const ASSET_COLORS: Record<string, string> = {
  AUXG: '#EAB308',
  AUXS: '#94A3B8',
  AUXPT: '#E2E8F0',
  AUXPD: '#64748B',
  USD: '#22C55E',
  USDT: '#26A17B',
  AUXM: '#A855F7',
  BTC: '#F7931A',
  ETH: '#627EEA',
};

type TabType = 'metals' | 'crypto' | 'allocations' | 'staking';

export default function AssetsScreen() {
  const colorScheme = useColorScheme();
  const { theme, language, walletAddress, isConnected } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('metals');
  const [loading, setLoading] = useState(true);
  
  // Modal States
  const [showDepositMethod, setShowDepositMethod] = useState(false);
  const [showCoinSelect, setShowCoinSelect] = useState(false);
  const [showDepositAddress, setShowDepositAddress] = useState(false);
  const [showUsdDeposit, setShowUsdDeposit] = useState(false);
  const [showQuickBuy, setShowQuickBuy] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [showSend, setShowSend] = useState(false);
  const [showLockedAssets, setShowLockedAssets] = useState(false);
  const [selectedCoin, setSelectedCoin] = useState<DepositCoin | null>(null);

  // Translations
  const t = {
    totalValue: language === 'tr' ? 'Toplam Varlık' : 'Total Assets',
    available: language === 'tr' ? 'Kullanılabilir' : 'Available',
    locked: language === 'tr' ? 'Kilitli' : 'Locked',
    deposit: language === 'tr' ? 'Yatır' : 'Deposit',
    quickBuy: language === 'tr' ? 'Hızlı Al' : 'Quick Buy',
    send: language === 'tr' ? 'Gönder' : 'Send',
    convert: language === 'tr' ? 'Dönüştür' : 'Convert',
    stake: language === 'tr' ? 'Stake' : 'Stake',
    withdraw: language === 'tr' ? 'Çek' : 'Withdraw',
    metals: language === 'tr' ? 'Metaller' : 'Metals',
    crypto: language === 'tr' ? 'Kripto' : 'Crypto',
    allocations: language === 'tr' ? 'Tahsisler' : 'Physical',
    staking: language === 'tr' ? 'Staking' : 'Staking',
    recentTx: language === 'tr' ? 'Son İşlemler' : 'Recent',
    viewAll: language === 'tr' ? 'Tümü' : 'All',
    noData: language === 'tr' ? 'Henüz veri yok' : 'No data yet',
    active: language === 'tr' ? 'Aktif' : 'Active',
    completed: language === 'tr' ? 'Tamamlandı' : 'Done',
    daysLeft: language === 'tr' ? 'gün' : 'days',
    months: language === 'tr' ? 'ay' : 'mo',
    connectWallet: language === 'tr' ? 'Cüzdan bağlayın' : 'Connect wallet',
  };

  // Data States
  const [metalPrices, setMetalPrices] = useState<Record<string, number>>({ AUXG: 95, AUXS: 1.15, AUXPT: 32, AUXPD: 35 });
  const [cryptoPrices, setCryptoPrices] = useState<Record<string, number>>({ BTC: 105000, ETH: 3800 });
  
  const [metals, setMetals] = useState<Asset[]>([]);
  const [cryptos, setCryptos] = useState<Asset[]>([]);
  const [allocations, setAllocations] = useState<Allocation[]>([]);
  const [stakes, setStakes] = useState<StakePosition[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Computed Values
  const totalMetals = metals.reduce((sum, m) => sum + m.value, 0);
  const totalCrypto = cryptos.reduce((sum, c) => sum + c.value, 0);
  const totalAllocations = allocations.reduce((sum, a) => sum + (a.grams * (metalPrices[a.metal] || 0)), 0);
  const totalStaking = stakes.reduce((sum, s) => sum + (s.amountGrams * (metalPrices[s.metalSymbol] || 0)), 0);
  const totalAvailable = totalMetals + totalCrypto;
  const totalLocked = totalAllocations + totalStaking;
  const totalValue = totalAvailable + totalLocked;

  // ═══════════════════════════════════════════════════════════════════════════
  // API FETCH FUNCTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  const fetchPrices = async () => {
    try {
      // Metal fiyatları
      const metalRes = await fetch(`${API_BASE_URL}/api/metals`);
      const metalData = await metalRes.json();
      
      if (metalData.ok && metalData.data) {
        const newMetalPrices: Record<string, number> = {};
        metalData.data.forEach((m: any) => {
          if (m.symbol && m.priceOz) {
            newMetalPrices[m.symbol] = m.priceOz / TROY_OZ_TO_GRAM;
          }
        });
        if (Object.keys(newMetalPrices).length > 0) {
          setMetalPrices(prev => ({ ...prev, ...newMetalPrices }));
        }
      }

      // Kripto fiyatları
      const cryptoRes = await fetch(`${API_BASE_URL}/api/crypto`);
      const cryptoData = await cryptoRes.json();
      
      if (cryptoData.bitcoin || cryptoData.ethereum) {
        setCryptoPrices({
          BTC: cryptoData.bitcoin?.usd || 105000,
          ETH: cryptoData.ethereum?.usd || 3800,
        });
      }
    } catch (error) {
      console.error('Price fetch error:', error);
    }
  };

  const fetchBalances = async () => {
    if (!walletAddress) {
      loadMockBalances();
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/balances?wallet=${walletAddress}`);
      const data = await res.json();

      if (data.ok && data.balances) {
        // Metal bakiyeleri
        const metalBalances: Asset[] = [];
        const cryptoBalances: Asset[] = [];

        Object.entries(data.balances).forEach(([symbol, balance]: [string, any]) => {
          const bal = typeof balance === 'number' ? balance : parseFloat(balance) || 0;
          if (bal <= 0) return;

          if (['AUXG', 'AUXS', 'AUXPT', 'AUXPD'].includes(symbol)) {
            const price = metalPrices[symbol] || 0;
            metalBalances.push({
              symbol,
              name: METAL_INFO[symbol]?.name || symbol,
              balance: bal,
              price,
              value: bal * price,
              change24h: data.changes?.[symbol] || 0,
              color: ASSET_COLORS[symbol] || '#64748b',
            });
          } else {
            const price = symbol === 'BTC' ? cryptoPrices.BTC : symbol === 'ETH' ? cryptoPrices.ETH : 1;
            cryptoBalances.push({
              symbol,
              name: getAssetName(symbol),
              balance: bal,
              price,
              value: bal * price,
              change24h: data.changes?.[symbol] || 0,
              color: ASSET_COLORS[symbol] || '#64748b',
              icon: getAssetIcon(symbol),
            });
          }
        });

        if (metalBalances.length > 0) setMetals(metalBalances);
        if (cryptoBalances.length > 0) setCryptos(cryptoBalances);
      } else {
        loadMockBalances();
      }
    } catch (error) {
      console.error('Balance fetch error:', error);
      loadMockBalances();
    }
  };

  const fetchAllocations = async () => {
    if (!walletAddress) {
      loadMockAllocations();
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/allocations?wallet=${walletAddress}`);
      const data = await res.json();

      if (data.ok && data.allocations && data.allocations.length > 0) {
        setAllocations(data.allocations);
      } else {
        loadMockAllocations();
      }
    } catch (error) {
      console.error('Allocations fetch error:', error);
      loadMockAllocations();
    }
  };

  const fetchStakes = async () => {
    if (!walletAddress) {
      loadMockStakes();
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/staking/positions?wallet=${walletAddress}`);
      const data = await res.json();

      if (data.ok && data.positions && data.positions.length > 0) {
        setStakes(data.positions);
      } else {
        loadMockStakes();
      }
    } catch (error) {
      console.error('Stakes fetch error:', error);
      loadMockStakes();
    }
  };

  const fetchTransactions = async () => {
    if (!walletAddress) {
      loadMockTransactions();
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/transactions?wallet=${walletAddress}&limit=5`);
      const data = await res.json();

      if (data.ok && data.transactions && data.transactions.length > 0) {
        setTransactions(data.transactions);
      } else {
        loadMockTransactions();
      }
    } catch (error) {
      console.error('Transactions fetch error:', error);
      loadMockTransactions();
    }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // MOCK DATA LOADERS (Demo için)
  // ═══════════════════════════════════════════════════════════════════════════

  const loadMockBalances = () => {
    setMetals([
      { symbol: 'AUXG', name: 'Gold', balance: 125.50, price: metalPrices.AUXG, value: 125.50 * metalPrices.AUXG, change24h: 1.25, color: '#EAB308' },
      { symbol: 'AUXS', name: 'Silver', balance: 2500.00, price: metalPrices.AUXS, value: 2500 * metalPrices.AUXS, change24h: -0.85, color: '#94A3B8' },
      { symbol: 'AUXPT', name: 'Platinum', balance: 15.75, price: metalPrices.AUXPT, value: 15.75 * metalPrices.AUXPT, change24h: 0.45, color: '#E2E8F0' },
      { symbol: 'AUXPD', name: 'Palladium', balance: 8.25, price: metalPrices.AUXPD, value: 8.25 * metalPrices.AUXPD, change24h: -1.20, color: '#64748B' },
    ]);
    setCryptos([
      { symbol: 'USD', name: 'US Dollar', balance: 1000.00, price: 1, value: 1000, change24h: 0, color: '#22C55E', icon: '$' },
      { symbol: 'USDT', name: 'Tether', balance: 5000.00, price: 1, value: 5000, change24h: 0.01, color: '#26A17B', icon: '₮' },
      { symbol: 'AUXM', name: 'Auxite Money', balance: 15000.00, price: 1, value: 15000, change24h: 0, color: '#A855F7', icon: '◈' },
      { symbol: 'BTC', name: 'Bitcoin', balance: 0.0456, price: cryptoPrices.BTC, value: 0.0456 * cryptoPrices.BTC, change24h: 2.35, color: '#F7931A', icon: '₿' },
      { symbol: 'ETH', name: 'Ethereum', balance: 1.5234, price: cryptoPrices.ETH, value: 1.5234 * cryptoPrices.ETH, change24h: 1.80, color: '#627EEA', icon: 'Ξ' },
    ]);
  };

  const loadMockAllocations = () => {
    setAllocations([
      { id: '1', metal: 'AUXG', grams: 50, custodian: 'zurich', timestamp: '2024-12-01' },
      { id: '2', metal: 'AUXS', grams: 500, custodian: 'singapore', timestamp: '2024-11-15' },
      { id: '3', metal: 'AUXPT', grams: 5, custodian: 'london', timestamp: '2024-10-20' },
    ]);
  };

  const loadMockStakes = () => {
    setStakes([
      { id: '1', metalSymbol: 'AUXG', amountGrams: 25.5, durationMonths: 6, apyPercent: 6.0, progress: 45, timeRemaining: 98, isMatured: false, shortCode: 'STK-A1B2C3', expectedRewardGrams: 0.765 },
      { id: '2', metalSymbol: 'AUXS', amountGrams: 200, durationMonths: 3, apyPercent: 3.5, progress: 80, timeRemaining: 18, isMatured: false, shortCode: 'STK-D4E5F6', expectedRewardGrams: 1.75 },
      { id: '3', metalSymbol: 'AUXG', amountGrams: 10, durationMonths: 12, apyPercent: 8.5, progress: 100, isMatured: true, shortCode: 'STK-G7H8I9', expectedRewardGrams: 0.85 },
    ]);
  };

  const loadMockTransactions = () => {
    setTransactions([
      { id: '1', type: 'deposit', asset: 'USDT', amount: 1000, value: 1000, status: 'completed', date: '2024-12-18' },
      { id: '2', type: 'buy', asset: 'AUXG', amount: 10.5, value: 999.90, status: 'completed', date: '2024-12-17' },
      { id: '3', type: 'stake', asset: 'AUXG', amount: 50, value: 4760, status: 'pending', date: '2024-12-16' },
    ]);
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════════════

  const getAssetName = (symbol: string): string => {
    const names: Record<string, string> = {
      USD: 'US Dollar', USDT: 'Tether', AUXM: 'Auxite Money', BTC: 'Bitcoin', ETH: 'Ethereum'
    };
    return names[symbol] || symbol;
  };

  const getAssetIcon = (symbol: string): string => {
    const icons: Record<string, string> = { USD: '$', USDT: '₮', AUXM: '◈', BTC: '₿', ETH: 'Ξ' };
    return icons[symbol] || symbol[0];
  };

  const formatValue = (v: number) => '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  
  const formatBalance = (b: number, s: string) => {
    if (['BTC', 'ETH'].includes(s)) return b.toFixed(4);
    if (['AUXG', 'AUXS', 'AUXPT', 'AUXPD'].includes(s)) return b.toFixed(2) + 'g';
    return b.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const getChangeColor = (c: number) => c > 0 ? '#10b981' : c < 0 ? '#ef4444' : isDark ? '#94a3b8' : '#64748b';
  const getTypeIcon = (type: string) => ({ deposit: 'arrow-down-circle', withdraw: 'arrow-up-circle', buy: 'cart', sell: 'pricetag', stake: 'trending-up', convert: 'swap-horizontal', allocate: 'cube' }[type] || 'ellipse');
  const getTypeColor = (type: string) => ({ deposit: '#10b981', withdraw: '#ef4444', buy: '#8b5cf6', sell: '#f59e0b', stake: '#eab308', convert: '#f97316', allocate: '#22d3ee' }[type] || '#64748b');

  // ═══════════════════════════════════════════════════════════════════════════
  // EFFECTS
  // ═══════════════════════════════════════════════════════════════════════════

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchPrices();
      await Promise.all([fetchBalances(), fetchAllocations(), fetchStakes(), fetchTransactions()]);
      setLoading(false);
    };
    loadData();

    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, [walletAddress]);

  // Fiyatlar değişince bakiyeleri güncelle
  useEffect(() => {
    setMetals(prev => prev.map(m => ({ ...m, price: metalPrices[m.symbol] || m.price, value: m.balance * (metalPrices[m.symbol] || m.price) })));
  }, [metalPrices]);

  useEffect(() => {
    setCryptos(prev => prev.map(c => {
      const price = c.symbol === 'BTC' ? cryptoPrices.BTC : c.symbol === 'ETH' ? cryptoPrices.ETH : c.price;
      return { ...c, price, value: c.balance * price };
    }));
  }, [cryptoPrices]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchPrices();
    await Promise.all([fetchBalances(), fetchAllocations(), fetchStakes(), fetchTransactions()]);
    setRefreshing(false);
  }, [walletAddress]);

  // ═══════════════════════════════════════════════════════════════════════════
  // HANDLERS
  // ═══════════════════════════════════════════════════════════════════════════

  const handleDeposit = () => setShowDepositMethod(true);
  const handleSelectCrypto = () => { setShowDepositMethod(false); setShowCoinSelect(true); };
  const handleSelectUsd = () => { setShowDepositMethod(false); setShowUsdDeposit(true); };
  const handleSelectCoin = (coin: DepositCoin) => { setSelectedCoin(coin); setShowCoinSelect(false); setShowDepositAddress(true); };
  const handleQuickBuy = () => setShowQuickBuy(true);
  const handleSend = () => setShowSend(true);
  const handleConvert = () => router.push('/(tabs)/convert' as any);
  const handleStakeNav = () => router.push('/(tabs)/stake' as any);
  const handleWithdraw = () => setShowWithdraw(true);

  // ═══════════════════════════════════════════════════════════════════════════
  // COMPONENTS
  // ═══════════════════════════════════════════════════════════════════════════

  const ActionButton = ({ icon, label, color, onPress }: { icon: string; label: string; color: string; onPress: () => void }) => (
    <TouchableOpacity style={[styles.actionButton, { backgroundColor: isDark ? '#1e293b' : '#fff' }]} onPress={onPress} activeOpacity={0.7}>
      <View style={[styles.actionIconContainer, { backgroundColor: color + '20' }]}>
        <Ionicons name={icon as any} size={18} color={color} />
      </View>
      <Text style={[styles.actionLabel, { color: isDark ? '#e2e8f0' : '#334155' }]}>{label}</Text>
    </TouchableOpacity>
  );

  const AssetRow = ({ asset, isMetal }: { asset: Asset; isMetal: boolean }) => (
    <TouchableOpacity style={[styles.assetRow, { borderBottomColor: isDark ? '#334155' : '#f1f5f9' }]} activeOpacity={0.7}>
      <View style={styles.assetLeft}>
        <View style={[styles.assetIcon, { backgroundColor: asset.color + '20' }]}>
          {isMetal && metalIcons[asset.symbol] ? (
            <Image source={metalIcons[asset.symbol]} style={styles.metalImage} resizeMode="contain" />
          ) : (
            <Text style={[styles.assetIconText, { color: asset.color }]}>{asset.icon || asset.symbol[0]}</Text>
          )}
        </View>
        <View>
          <Text style={[styles.assetSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{asset.symbol}</Text>
          <Text style={[styles.assetName, { color: isDark ? '#64748b' : '#94a3b8' }]}>{asset.name}</Text>
        </View>
      </View>
      <View style={styles.assetRight}>
        <Text style={[styles.assetBalance, { color: isDark ? '#fff' : '#0f172a' }]}>{formatBalance(asset.balance, asset.symbol)}</Text>
        <Text style={[styles.assetValue, { color: getChangeColor(asset.change24h) }]}>{formatValue(asset.value)}</Text>
      </View>
    </TouchableOpacity>
  );

  const AllocationRow = ({ alloc }: { alloc: Allocation }) => {
    const metal = METAL_INFO[alloc.metal];
    const price = metalPrices[alloc.metal] || 0;
    const value = alloc.grams * price;
    return (
      <View style={[styles.assetRow, { borderBottomColor: isDark ? '#334155' : '#f1f5f9' }]}>
        <View style={styles.assetLeft}>
          <View style={[styles.assetIcon, { backgroundColor: (metal?.color || '#64748b') + '20' }]}>
            {metalIcons[alloc.metal] ? (
              <Image source={metalIcons[alloc.metal]} style={styles.metalImage} resizeMode="contain" />
            ) : (
              <Text style={[styles.assetIconText, { color: metal?.color }]}>{alloc.metal[0]}</Text>
            )}
          </View>
          <View>
            <Text style={[styles.assetSymbol, { color: metal?.color }]}>{alloc.metal}</Text>
            <Text style={[styles.assetName, { color: isDark ? '#64748b' : '#94a3b8' }]}>{CUSTODIAN_NAMES[alloc.custodian]}</Text>
          </View>
        </View>
        <View style={styles.assetRight}>
          <Text style={[styles.assetBalance, { color: isDark ? '#fff' : '#0f172a' }]}>{alloc.grams}g</Text>
          <Text style={[styles.assetValue, { color: isDark ? '#64748b' : '#94a3b8' }]}>≈ {formatValue(value)}</Text>
        </View>
      </View>
    );
  };

  const StakeRow = ({ stake }: { stake: StakePosition }) => {
    const metal = METAL_INFO[stake.metalSymbol];
    return (
      <View style={[styles.assetRow, { borderBottomColor: isDark ? '#334155' : '#f1f5f9' }]}>
        <View style={styles.assetLeft}>
          <View style={[styles.assetIcon, { backgroundColor: (metal?.color || '#64748b') + '20' }]}>
            {metalIcons[stake.metalSymbol] ? (
              <Image source={metalIcons[stake.metalSymbol]} style={styles.metalImage} resizeMode="contain" />
            ) : (
              <Text style={[styles.assetIconText, { color: metal?.color }]}>{stake.metalSymbol[0]}</Text>
            )}
          </View>
          <View>
            <View style={styles.stakeHeader}>
              <Text style={[styles.assetSymbol, { color: metal?.color }]}>{stake.metalSymbol}</Text>
              <View style={[styles.stakeBadge, { backgroundColor: stake.isMatured ? '#10b98120' : '#3b82f620' }]}>
                <Text style={[styles.stakeBadgeText, { color: stake.isMatured ? '#10b981' : '#3b82f6' }]}>
                  {stake.isMatured ? t.completed : t.active}
                </Text>
              </View>
            </View>
            <Text style={[styles.assetName, { color: isDark ? '#64748b' : '#94a3b8' }]}>
              {stake.durationMonths}{t.months} • {stake.apyPercent}% APY
            </Text>
          </View>
        </View>
        <View style={styles.assetRight}>
          <Text style={[styles.assetBalance, { color: isDark ? '#fff' : '#0f172a' }]}>{stake.amountGrams.toFixed(2)}g</Text>
          <View style={styles.progressRow}>
            <View style={[styles.progressBar, { backgroundColor: isDark ? '#0f172a' : '#e2e8f0' }]}>
              <View style={[styles.progressFill, { width: `${stake.progress}%`, backgroundColor: stake.isMatured ? '#10b981' : '#3b82f6' }]} />
            </View>
            <Text style={[styles.progressText, { color: isDark ? '#64748b' : '#94a3b8' }]}>{stake.progress}%</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#f59e0b" />}
        showsVerticalScrollIndicator={false}
      >
        {/* Total Value Card */}
        <View style={[styles.totalCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <Text style={[styles.totalLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.totalValue}</Text>
          <Text style={[styles.totalValue, { color: isDark ? '#fff' : '#0f172a' }]}>
            {loading ? '...' : formatValue(totalValue)}
          </Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: '#10b981' }]}>{loading ? '...' : formatValue(totalAvailable)}</Text>
              <Text style={[styles.statLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.available}</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]} />
            <TouchableOpacity style={styles.statItem} onPress={() => setShowLockedAssets(true)}>
              <Text style={[styles.statValue, { color: '#f59e0b' }]}>{loading ? '...' : formatValue(totalLocked)}</Text>
              <Text style={[styles.statLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.locked} 🔒</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Action Buttons - 2 Rows, 3 per row */}
        <View style={styles.actionsContainer}>
          <View style={styles.actionsRow}>
            <ActionButton icon="add-circle" label={t.deposit} color="#10b981" onPress={handleDeposit} />
            <ActionButton icon="cart" label={t.quickBuy} color="#8b5cf6" onPress={handleQuickBuy} />
            <ActionButton icon="swap-horizontal" label={t.convert} color="#f97316" onPress={handleConvert} />
          </View>
          <View style={styles.actionsRow}>
            <ActionButton icon="send" label={t.send} color="#3b82f6" onPress={handleSend} />
            <ActionButton icon="layers" label={t.stake} color="#eab308" onPress={handleStakeNav} />
            <ActionButton icon="arrow-up-circle" label={t.withdraw} color="#ef4444" onPress={handleWithdraw} />
          </View>
        </View>

        {/* My Assets Title */}
        <Text style={[styles.myAssetsTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
          {language === 'tr' ? 'Varlıklarım' : 'My Assets'}
        </Text>

        {/* Tab Menu */}
        <View style={[styles.tabContainer, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Metals Tab */}
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'metals' && styles.tabItemActive]}
            onPress={() => setActiveTab('metals')}
          >
            <Ionicons name="cube" size={16} color={activeTab === 'metals' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8')} />
            <Text style={[styles.tabLabel, { color: activeTab === 'metals' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8') }]}>{t.metals}</Text>
          </TouchableOpacity>

          {/* Crypto Tab */}
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'crypto' && styles.tabItemActive]}
            onPress={() => setActiveTab('crypto')}
          >
            <Ionicons name="logo-bitcoin" size={16} color={activeTab === 'crypto' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8')} />
            <Text style={[styles.tabLabel, { color: activeTab === 'crypto' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8') }]}>{t.crypto}</Text>
          </TouchableOpacity>

          {/* Allocations Tab */}
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'allocations' && styles.tabItemActive]}
            onPress={() => setActiveTab('allocations')}
          >
            <Ionicons name="lock-closed" size={16} color={activeTab === 'allocations' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8')} />
            <Text style={[styles.tabLabel, { color: activeTab === 'allocations' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8') }]}>{t.allocations}</Text>
          </TouchableOpacity>

          {/* Staking Tab */}
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'staking' && styles.tabItemActive]}
            onPress={() => setActiveTab('staking')}
          >
            <Ionicons name="trending-up" size={16} color={activeTab === 'staking' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8')} />
            <Text style={[styles.tabLabel, { color: activeTab === 'staking' ? '#f59e0b' : (isDark ? '#64748b' : '#94a3b8') }]}>{t.staking}</Text>
          </TouchableOpacity>
        </View>

        {/* Tab Content */}
        <View style={[styles.tabContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {loading ? (
            <ActivityIndicator size="small" color="#f59e0b" style={{ padding: 30 }} />
          ) : activeTab === 'metals' ? (
            metals.length === 0 ? (
              <Text style={[styles.noData, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.noData}</Text>
            ) : (
              metals.map((asset) => <AssetRow key={asset.symbol} asset={asset} isMetal={true} />)
            )
          ) : activeTab === 'crypto' ? (
            cryptos.length === 0 ? (
              <Text style={[styles.noData, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.noData}</Text>
            ) : (
              cryptos.map((asset) => <AssetRow key={asset.symbol} asset={asset} isMetal={false} />)
            )
          ) : activeTab === 'allocations' ? (
            allocations.length === 0 ? (
              <Text style={[styles.noData, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.noData}</Text>
            ) : (
              allocations.map((alloc) => <AllocationRow key={alloc.id} alloc={alloc} />)
            )
          ) : (
            stakes.length === 0 ? (
              <Text style={[styles.noData, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.noData}</Text>
            ) : (
              stakes.map((stake) => <StakeRow key={stake.id} stake={stake} />)
            )
          )}
        </View>

        {/* Recent Transactions */}
        <View style={[styles.txSection, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          <View style={styles.txHeader}>
            <Text style={[styles.txTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.recentTx}</Text>
            <TouchableOpacity><Text style={styles.viewAll}>{t.viewAll}</Text></TouchableOpacity>
          </View>
          {loading ? (
            <ActivityIndicator size="small" color="#f59e0b" style={{ padding: 20 }} />
          ) : transactions.length === 0 ? (
            <Text style={[styles.noData, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.noData}</Text>
          ) : (
            transactions.slice(0, 3).map((tx) => (
              <View key={tx.id} style={[styles.txRow, { borderBottomColor: isDark ? '#334155' : '#f1f5f9' }]}>
                <View style={styles.txLeft}>
                  <View style={[styles.txIcon, { backgroundColor: getTypeColor(tx.type) + '20' }]}>
                    <Ionicons name={getTypeIcon(tx.type) as any} size={14} color={getTypeColor(tx.type)} />
                  </View>
                  <View>
                    <Text style={[styles.txType, { color: isDark ? '#fff' : '#0f172a' }]}>{tx.type}</Text>
                    <Text style={[styles.txDate, { color: isDark ? '#64748b' : '#94a3b8' }]}>{tx.date}</Text>
                  </View>
                </View>
                <View style={styles.txRight}>
                  <Text style={[styles.txAmount, { color: isDark ? '#fff' : '#0f172a' }]}>
                    {tx.type === 'withdraw' ? '-' : '+'}{tx.amount} {tx.asset}
                  </Text>
                  <View style={[styles.txStatus, { backgroundColor: tx.status === 'completed' ? '#10b98120' : '#f59e0b20' }]}>
                    <Text style={[styles.txStatusText, { color: tx.status === 'completed' ? '#10b981' : '#f59e0b' }]}>{tx.status}</Text>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Modals */}
      <DepositMethodModal visible={showDepositMethod} onClose={() => setShowDepositMethod(false)} onSelectCrypto={handleSelectCrypto} onSelectUsd={handleSelectUsd} />
      <CoinSelectModal visible={showCoinSelect} onClose={() => setShowCoinSelect(false)} onSelectCoin={handleSelectCoin} />
      <DepositAddressModal visible={showDepositAddress} onClose={() => { setShowDepositAddress(false); setSelectedCoin(null); }} coin={selectedCoin} />
      <UsdDepositModal visible={showUsdDeposit} onClose={() => setShowUsdDeposit(false)} />
      <QuickBuyModal visible={showQuickBuy} onClose={() => setShowQuickBuy(false)} />
      <SendModal visible={showSend} onClose={() => setShowSend(false)} />
      <WithdrawModal visible={showWithdraw} onClose={() => setShowWithdraw(false)} />
      <LockedAssetsModal visible={showLockedAssets} onClose={() => setShowLockedAssets(false)} metalPrices={metalPrices} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingTop: 60 },

  // Total Card
  totalCard: { margin: 16, padding: 16, borderRadius: 16 },
  totalLabel: { fontSize: 12, marginBottom: 4 },
  totalValue: { fontSize: 28, fontWeight: '700', marginBottom: 12 },
  statsRow: { flexDirection: 'row', alignItems: 'center' },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 15, fontWeight: '600' },
  statLabel: { fontSize: 10, marginTop: 2 },
  statDivider: { width: 1, height: 30 },

  // Actions - 2 Rows
  actionsContainer: { paddingHorizontal: 16, marginBottom: 16, gap: 8 },
  actionsRow: { flexDirection: 'row', gap: 8 },
  actionButton: { flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 12 },
  actionIconContainer: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  actionLabel: { fontSize: 10, fontWeight: '600' },

  // My Assets Title
  myAssetsTitle: { fontSize: 16, fontWeight: '700', marginHorizontal: 16, marginBottom: 8 },

  // Tabs
  tabContainer: { flexDirection: 'row', marginHorizontal: 16, borderRadius: 12, padding: 4, marginBottom: 8 },
  tabItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, borderRadius: 10 },
  tabItemActive: { backgroundColor: 'rgba(245, 158, 11, 0.1)' },
  tabLabel: { fontSize: 10, fontWeight: '600' },

  // Tab Content
  tabContent: { marginHorizontal: 16, borderRadius: 12, marginBottom: 12, overflow: 'hidden' },
  noData: { padding: 30, textAlign: 'center', fontSize: 13 },

  // Asset Row
  assetRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1 },
  assetLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  assetIcon: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  metalImage: { width: 20, height: 20 },
  assetIconText: { fontSize: 15, fontWeight: '700' },
  assetSymbol: { fontSize: 13, fontWeight: '600' },
  assetName: { fontSize: 10, marginTop: 1 },
  assetRight: { alignItems: 'flex-end' },
  assetBalance: { fontSize: 13, fontWeight: '600' },
  assetValue: { fontSize: 11, marginTop: 1 },

  // Stake Row
  stakeHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  stakeBadge: { paddingHorizontal: 5, paddingVertical: 1, borderRadius: 4 },
  stakeBadgeText: { fontSize: 8, fontWeight: '600' },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  progressBar: { width: 50, height: 4, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 2 },
  progressText: { fontSize: 9 },

  // Transactions
  txSection: { marginHorizontal: 16, borderRadius: 12, overflow: 'hidden' },
  txHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, paddingBottom: 8 },
  txTitle: { fontSize: 14, fontWeight: '600' },
  viewAll: { fontSize: 11, color: '#f59e0b', fontWeight: '500' },
  txRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1 },
  txLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  txIcon: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  txType: { fontSize: 12, fontWeight: '500', textTransform: 'capitalize' },
  txDate: { fontSize: 9, marginTop: 1 },
  txRight: { alignItems: 'flex-end' },
  txAmount: { fontSize: 12, fontWeight: '600' },
  txStatus: { paddingHorizontal: 5, paddingVertical: 2, borderRadius: 4, marginTop: 2 },
  txStatusText: { fontSize: 8, fontWeight: '500' },
});
