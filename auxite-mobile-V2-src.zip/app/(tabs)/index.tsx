import { StyleSheet, ScrollView, View, Text, useColorScheme, RefreshControl, TouchableOpacity, Image, StatusBar } from 'react-native';
import { useState, useEffect, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useStore } from '@/stores/useStore';
import TopNav from '@/components/TopNav';


// Import Modals
import { DepositMethodModal, CoinSelectModal, DepositAddressModal, UsdDepositModal, DEPOSIT_COINS, DepositCoin } from '@/components/DepositModals';
import  QuickBuyModal  from '@/components/QuickBuyModal';
import { RiskCorrelationModal } from '@/components/RiskCorrelationModal';

const API_BASE_URL = 'https://auxite-wallet.vercel.app';
const TROY_OZ_TO_GRAM = 31.1035;

const metalIcons: Record<string, any> = {
  AUXG: require('@/assets/images/metals/gold.png'),
  AUXS: require('@/assets/images/metals/silver.png'),
  AUXPT: require('@/assets/images/metals/platinum.png'),
  AUXPD: require('@/assets/images/metals/palladium.png'),
};

interface PriceItem {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  color: string;
  isImage?: boolean;
}

interface LeaseRate {
  metal: string;
  color: string;
  m3: number;
  m6: number;
  m12: number;
}

// Trust Data moved to launch phase - no mock data

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const systemIsDark = colorScheme === 'dark';
  const { theme, language, isConnected } = useStore();
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  
  const [refreshing, setRefreshing] = useState(false);
  const [activeBannerIndex] = useState(0);
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MODAL STATES
  // ═══════════════════════════════════════════════════════════════════════════
  const [showDepositMethod, setShowDepositMethod] = useState(false);
  const [showCoinSelect, setShowCoinSelect] = useState(false);
  const [showDepositAddress, setShowDepositAddress] = useState(false);
  const [showUsdDeposit, setShowUsdDeposit] = useState(false);
  const [showQuickBuy, setShowQuickBuy] = useState(false);
  const [showRiskModal, setShowRiskModal] = useState(false);
  const [selectedCoin, setSelectedCoin] = useState<DepositCoin | null>(null);
  
  // Trust Data - Launch Phase (Empty State)
  const [trustData] = useState({
    isLaunchPhase: true,
    statusText: language === 'tr' ? 'Lansman Aşaması' : 'Launch Phase',
  });
  
  const [metals, setMetals] = useState<PriceItem[]>([
    { symbol: 'AUXG', name: 'Gold', price: 0, change24h: 0, color: '#EAB308', isImage: true },
    { symbol: 'AUXS', name: 'Silver', price: 0, change24h: 0, color: '#94A3B8', isImage: true },
    { symbol: 'AUXPT', name: 'Platinum', price: 0, change24h: 0, color: '#E2E8F0', isImage: true },
    { symbol: 'AUXPD', name: 'Palladium', price: 0, change24h: 0, color: '#64748B', isImage: true },
    { symbol: 'AUXM', name: 'Auxite Para', price: 1.00, change24h: 0, color: '#A855F7', isImage: false },
  ]);
  
  const [cryptos, setCryptos] = useState<PriceItem[]>([
    { symbol: 'BTC', name: 'Bitcoin', price: 0, change24h: 0, color: '#F7931A', isImage: false },
    { symbol: 'ETH', name: 'Ethereum', price: 0, change24h: 0, color: '#627EEA', isImage: false },
    { symbol: 'USDT', name: 'Tether', price: 1.00, change24h: 0, color: '#26A17B', isImage: false },
    { symbol: 'XRP', name: 'Ripple', price: 0, change24h: 0, color: '#00A3E0', isImage: false },
    { symbol: 'SOL', name: 'Solana', price: 0, change24h: 0, color: '#9945FF', isImage: false },
  ]);

  const cryptoIcons: Record<string, string> = { BTC: '₿', ETH: 'Ξ', USDT: '₮', XRP: '✕', SOL: '◎' };

  const [leaseRates] = useState<LeaseRate[]>([
    { metal: 'AUXG', color: '#EAB308', m3: 3.5, m6: 5.2, m12: 7.0 },
    { metal: 'AUXS', color: '#94A3B8', m3: 4.0, m6: 6.0, m12: 8.5 },
    { metal: 'AUXPT', color: '#E2E8F0', m3: 3.2, m6: 4.8, m12: 6.5 },
    { metal: 'AUXPD', color: '#64748B', m3: 3.8, m6: 5.5, m12: 7.2 },
  ]);

  const [news] = useState([
    { id: 1, title: 'Gold prices surge amid global uncertainty', time: '2h', source: 'Reuters' },
    { id: 2, title: 'Silver demand increases in solar panel industry', time: '4h', source: 'Bloomberg' },
  ]);

  // Translations
  const t = {
    trustCenter: language === 'en' ? 'Trust Center' : 'Güven Merkezi',
    backed: language === 'en' ? 'Backed 1:1 by Physical Assets' : '1:1 Fiziksel Varlık Destekli',
    totalReserves: language === 'en' ? 'Total Reserves' : 'Toplam Rezerv',
    fullyBacked: language === 'en' ? 'Fully Backed' : 'Tam Karşılıklı',
    reserves: language === 'en' ? 'Reserves' : 'Rezervler',
    audits: language === 'en' ? 'Audits' : 'Denetim',
    custody: language === 'en' ? 'Custody' : 'Saklama',
    viewDetails: language === 'en' ? 'View Details' : 'Detaylar',
    // Action buttons
    deposit: language === 'en' ? 'Deposit' : 'Yatır',
    quickBuy: language === 'en' ? 'Quick Buy' : 'Hızlı Al',
    convert: language === 'en' ? 'Convert' : 'Dönüştür',
    stake: language === 'en' ? 'Stake' : 'Biriktir',
  };

  const fetchPrices = async () => {
    try {
      const metalRes = await fetch(`${API_BASE_URL}/api/metals`);
      const metalData = await metalRes.json();
      if (metalData.ok && metalData.data) {
        setMetals(prev => prev.map(m => {
          const info = metalData.data.find((d: any) => d.symbol === m.symbol);
          if (info) {
            const basePrice = (info.priceOz || 0) / TROY_OZ_TO_GRAM;
            return { ...m, price: basePrice, change24h: metalData.changes?.[m.symbol] || 0 };
          }
          if (m.symbol === 'AUXM') {
            return { ...m, change24h: metalData.changes?.[m.symbol] || 0 };
          }
          return m;
        }));
      }
      
      const cryptoRes = await fetch(`${API_BASE_URL}/api/crypto`);
      const cryptoData = await cryptoRes.json();
      const cryptoApiMap: Record<string, string> = { 
        BTC: 'bitcoin', 
        ETH: 'ethereum', 
        USDT: 'tether',
        XRP: 'ripple',
        SOL: 'solana'
      };
      setCryptos(prev => prev.map(c => {
        const data = cryptoData[cryptoApiMap[c.symbol]];
        if (data) {
          const price = data.usd ?? (c.symbol === 'USDT' ? 1.00 : c.price);
          return { 
            ...c, 
            price: price,
            change24h: data.usd_24h_change || 0 
          };
        }
        return c;
      }));
    } catch (error) {
      console.error('Price fetch error:', error);
    }
  };

  // Trust data fetch removed - launch phase

  useEffect(() => {
    fetchPrices();
    const interval = setInterval(fetchPrices, 15000);
    return () => clearInterval(interval);
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchPrices();
    setRefreshing(false);
  }, []);

  const formatPrice = (price: number) => {
    if (price >= 1000) return '$' + price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (price >= 1) return '$' + price.toFixed(2);
    return '$' + price.toFixed(4);
  };

  const formatChange = (change: number) => {
    const prefix = change >= 0 ? '+' : '';
    return prefix + change.toFixed(2) + '%';
  };

  const getPriceColor = (change: number) => {
    if (change > 0) return '#10b981';
    if (change < 0) return '#ef4444';
    return isDark ? '#ffffff' : '#000000';
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // NAVIGATION & ACTION HANDLERS
  // ═══════════════════════════════════════════════════════════════════════════
  const handleTrustPress = () => {
    router.push('/(tabs)/trust' as any);
  };

  const handleQuickTrustLink = (screen: string) => {
    router.push(`/(tabs)/trust/${screen}` as any);
  };

  // Deposit Flow
  const handleDeposit = () => {
    setShowDepositMethod(true);
  };

  const handleSelectCrypto = () => {
    setShowDepositMethod(false);
    setShowCoinSelect(true);
  };

  const handleSelectUsd = () => {
    setShowDepositMethod(false);
    setShowUsdDeposit(true);
  };

  const handleSelectCoin = (coin: DepositCoin) => {
    setSelectedCoin(coin);
    setShowCoinSelect(false);
    setShowDepositAddress(true);
  };

  // Quick Buy
  const handleQuickBuy = () => {
    setShowQuickBuy(true);
  };

  // Convert
  const handleConvert = () => {
    router.push('/(tabs)/convert' as any);
  };

  // Stake
  const handleStake = () => {
    router.push('/(tabs)/stake' as any);
  };

  const TableHeader = ({ title }: { title: string }) => (
    <View style={styles.tableHeader}>
      <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{title}</Text>
      <Text style={[styles.headerLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Price</Text>
      <Text style={[styles.headerLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>24h Change</Text>
    </View>
  );

  const PriceRow = ({ item }: { item: PriceItem }) => (
    <TouchableOpacity style={[styles.priceRow, { borderBottomColor: isDark ? '#1e293b' : '#f1f5f9' }]} activeOpacity={0.7}>
      <View style={styles.priceRowLeft}>
        <View style={[styles.coinIcon, { backgroundColor: item.color + '20' }]}>
          {item.isImage && metalIcons[item.symbol] ? (
            <Image source={metalIcons[item.symbol]} style={styles.metalImage} resizeMode="contain" />
          ) : item.symbol === 'AUXM' ? (
            <View style={[styles.auxmIcon, { backgroundColor: item.color }]}>
              <Text style={styles.auxmIconText}>M</Text>
            </View>
          ) : (
            <Text style={[styles.cryptoIcon, { color: item.color }]}>{cryptoIcons[item.symbol] || item.symbol[0]}</Text>
          )}
        </View>
        <View>
          <Text style={[styles.coinSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.symbol}</Text>
          <Text style={[styles.coinName, { color: isDark ? '#64748b' : '#94a3b8' }]}>{item.name}</Text>
        </View>
      </View>
      <Text style={[styles.coinPrice, { color: getPriceColor(item.change24h) }]}>{formatPrice(item.price)}</Text>
      <Text style={[styles.changeValue, { color: item.change24h >= 0 ? '#10b981' : '#ef4444' }]}>
        {formatChange(item.change24h)}
      </Text>
    </TouchableOpacity>
  );

  const LeaseRateRow = ({ item }: { item: LeaseRate }) => (
    <View style={[styles.leaseRow, { borderBottomColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
      <View style={styles.leaseRowLeft}>
        <View style={[styles.coinIcon, { backgroundColor: item.color + '20' }]}>
          {metalIcons[item.metal] ? (
            <Image source={metalIcons[item.metal]} style={styles.metalImage} resizeMode="contain" />
          ) : (
            <View style={[styles.metalDot, { backgroundColor: item.color }]} />
          )}
        </View>
        <Text style={[styles.coinSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.metal}</Text>
      </View>
      <View style={styles.leaseRates}>
        <Text style={[styles.rateApy, { color: '#10b981' }]}>{item.m3}%</Text>
        <Text style={[styles.rateApy, { color: '#10b981' }]}>{item.m6}%</Text>
        <Text style={[styles.rateApy, { color: '#10b981' }]}>{item.m12}%</Text>
      </View>
    </View>
  );

  // Action Button Component
  const ActionButton = ({ icon, label, color, onPress }: {
    icon: string;
    label: string;
    color: string;
    onPress: () => void;
  }) => (
    <TouchableOpacity
      style={[styles.actionButton, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.actionIconContainer, { backgroundColor: color + '20' }]}>
        <Ionicons name={icon as any} size={20} color={color} />
      </View>
      <Text style={[styles.actionLabel, { color: isDark ? '#e2e8f0' : '#334155' }]}>{label}</Text>
    </TouchableOpacity>
  );

  // Trust Card Component
  const TrustCard = () => (
    <TouchableOpacity
      style={styles.trustContainer}
      onPress={handleTrustPress}
      activeOpacity={0.9}
    >
      <LinearGradient
        colors={isDark ? ['#064e3b', '#0f172a'] : ['#10b981', '#059669']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.trustGradient}
      >
        {/* Launch Phase indicator */}
        <View style={styles.trustLiveIndicator}>
          <View style={[styles.trustLiveDot, { backgroundColor: '#f59e0b' }]} />
          <Text style={styles.trustLiveText}>{trustData.statusText}</Text>
        </View>

        {/* Header */}
        <View style={styles.trustHeader}>
          <View style={styles.trustIconContainer}>
            <Ionicons name="shield-checkmark" size={24} color="#fff" />
          </View>
          <View style={styles.trustHeaderText}>
            <Text style={styles.trustTitle}>{t.trustCenter}</Text>
            <Text style={styles.trustSubtitle}>{language === 'tr' ? 'Şeffaflık & Güvenlik' : 'Transparency & Security'}</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.6)" />
        </View>

        {/* Launch Phase Message */}
        <View style={styles.trustLaunchMessage}>
          <Text style={styles.trustLaunchText}>
            {language === 'tr' 
              ? 'Veriler, ilk metal ihracından sonra yayınlanacaktır.' 
              : 'Data will be published after the first metal issuance.'}
          </Text>
        </View>

        {/* Quick Links */}
        <View style={styles.trustQuickLinks}>
          {[
            { key: 'reserves', icon: 'analytics', label: t.reserves },
            { key: 'audits', icon: 'document-text', label: t.audits },
            { key: 'custody', icon: 'lock-closed', label: t.custody },
          ].map((link) => (
            <TouchableOpacity
              key={link.key}
              style={styles.trustQuickLink}
              onPress={() => handleQuickTrustLink(link.key)}
            >
              <Ionicons name={link.icon as any} size={14} color="rgba(255,255,255,0.8)" />
              <Text style={styles.trustQuickLinkText}>{link.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      <TopNav />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#10b981" />}
        showsVerticalScrollIndicator={false}
      >
        {/* Banner */}
        <View style={styles.bannerContainer}>
          <View style={[styles.bannerPlaceholder, { backgroundColor: isDark ? '#1e293b' : '#e2e8f0' }]}>
            <Text style={[styles.bannerTitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>Dynamic Banner</Text>
            <Text style={[styles.bannerSubtitle, { color: isDark ? '#64748b' : '#94a3b8' }]}>Managed from admin</Text>
            <View style={styles.bannerIndicators}>
              <View style={[styles.indicator, { backgroundColor: activeBannerIndex === 0 ? '#10b981' : (isDark ? '#334155' : '#94a3b8') }]} />
              <View style={[styles.indicator, { backgroundColor: activeBannerIndex === 1 ? '#10b981' : (isDark ? '#334155' : '#94a3b8') }]} />
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <ActionButton 
            icon="add-circle" 
            label={t.deposit} 
            color="#10b981" 
            onPress={handleDeposit} 
          />
          <ActionButton 
            icon="cart" 
            label={t.quickBuy} 
            color="#8b5cf6" 
            onPress={handleQuickBuy} 
          />
          <ActionButton 
            icon="swap-horizontal" 
            label={t.convert} 
            color="#f97316" 
            onPress={handleConvert} 
          />
          <ActionButton 
            icon="trending-up" 
            label={t.stake} 
            color="#eab308" 
            onPress={handleStake} 
          />
        </View>

        {/* Trust Card */}
        <TrustCard />

        {/* Markets - Metal & Crypto Cards */}
        <View style={styles.marketsSection}>
          {/* Metals */}
          <View style={styles.marketHeader}>
            <Text style={[styles.marketHeaderTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
              {language === 'tr' ? 'Metaller' : 'Metals'}
            </Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/trade' as any)}>
              <Text style={styles.seeAllText}>{language === 'tr' ? 'Tümü' : 'See All'}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.cardsRow}>
            {metals.slice(0, 3).map((item) => (
              <TouchableOpacity
                key={item.symbol}
                style={[styles.assetCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
                onPress={() => router.push({ pathname: '/(tabs)/trade', params: { symbol: item.symbol } } as any)}
                activeOpacity={0.7}
              >
                <View style={[styles.cardIconContainer, { backgroundColor: item.color + '20' }]}>
                  {item.isImage && metalIcons[item.symbol] ? (
                    <Image source={metalIcons[item.symbol]} style={styles.cardMetalImage} resizeMode="contain" />
                  ) : (
                    <Text style={[styles.cardIconText, { color: item.color }]}>◈</Text>
                  )}
                </View>
                <Text style={[styles.cardSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.symbol}</Text>
                <Text style={[styles.cardPrice, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                  ${item.price.toFixed(2)}
                </Text>
                <View style={[styles.cardChangeContainer, { backgroundColor: item.change24h >= 0 ? '#10b98120' : '#ef444420' }]}>
                  <Ionicons 
                    name={item.change24h >= 0 ? 'trending-up' : 'trending-down'} 
                    size={10} 
                    color={item.change24h >= 0 ? '#10b981' : '#ef4444'} 
                  />
                  <Text style={[styles.cardChange, { color: item.change24h >= 0 ? '#10b981' : '#ef4444' }]}>
                    {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Crypto */}
          <View style={[styles.marketHeader, { marginTop: 12 }]}>
            <Text style={[styles.marketHeaderTitle, { color: isDark ? '#fff' : '#0f172a' }]}>
              {language === 'tr' ? 'Kripto' : 'Crypto'}
            </Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/trade' as any)}>
              <Text style={styles.seeAllText}>{language === 'tr' ? 'Tümü' : 'See All'}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.cardsRow}>
            {cryptos.slice(0, 3).map((item) => (
              <TouchableOpacity
                key={item.symbol}
                style={[styles.assetCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
                onPress={() => router.push({ pathname: '/(tabs)/trade', params: { symbol: item.symbol } } as any)}
                activeOpacity={0.7}
              >
                <View style={[styles.cardIconContainer, { backgroundColor: item.color + '20' }]}>
                  <Text style={[styles.cardIconText, { color: item.color }]}>{cryptoIcons[item.symbol] || item.symbol[0]}</Text>
                </View>
                <Text style={[styles.cardSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{item.symbol}</Text>
                <Text style={[styles.cardPrice, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                  ${item.price >= 1000 ? (item.price / 1000).toFixed(1) + 'K' : item.price.toFixed(2)}
                </Text>
                <View style={[styles.cardChangeContainer, { backgroundColor: item.change24h >= 0 ? '#10b98120' : '#ef444420' }]}>
                  <Ionicons 
                    name={item.change24h >= 0 ? 'trending-up' : 'trending-down'} 
                    size={10} 
                    color={item.change24h >= 0 ? '#10b981' : '#ef4444'} 
                  />
                  <Text style={[styles.cardChange, { color: item.change24h >= 0 ? '#10b981' : '#ef4444' }]}>
                    {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Risk & Correlation */}
        <TouchableOpacity 
          style={[styles.riskCard, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}
          onPress={() => setShowRiskModal(true)}
          activeOpacity={0.7}
        >
          <View style={styles.riskHeader}>
            <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>Risk & Correlation</Text>
            <View style={styles.viewMoreBadge}>
              <Text style={styles.viewMoreText}>{language === 'tr' ? 'Detay' : 'Details'}</Text>
              <Ionicons name="chevron-forward" size={12} color="#10b981" />
            </View>
          </View>
          <View style={styles.riskGrid}>
            <View style={[styles.riskItem, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
              <Text style={[styles.riskLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Gold/USD</Text>
              <Text style={[styles.riskValue, { color: '#10b981' }]}>Low</Text>
            </View>
            <View style={[styles.riskItem, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
              <Text style={[styles.riskLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>BTC/Gold</Text>
              <Text style={[styles.riskValue, { color: '#f59e0b' }]}>-0.32</Text>
            </View>
            <View style={[styles.riskItem, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
              <Text style={[styles.riskLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Volatility</Text>
              <Text style={[styles.riskValue, { color: '#10b981' }]}>12.5%</Text>
            </View>
            <View style={[styles.riskItem, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
              <Text style={[styles.riskLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>Sharpe</Text>
              <Text style={[styles.riskValue, { color: '#10b981' }]}>1.85</Text>
            </View>
          </View>
        </TouchableOpacity>

        {/* News */}
        <View style={styles.newsSection}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#fff' : '#0f172a', marginBottom: 10, marginLeft: 16 }]}>News</Text>
          {news.map((item) => (
            <TouchableOpacity key={item.id} style={[styles.newsItem, { backgroundColor: isDark ? '#1e293b' : '#fff' }]} activeOpacity={0.7}>
              <View style={styles.newsContent}>
                <Text style={[styles.newsTitle, { color: isDark ? '#fff' : '#0f172a' }]} numberOfLines={1}>{item.title}</Text>
                <Text style={[styles.newsMeta, { color: isDark ? '#64748b' : '#94a3b8' }]}>{item.source} · {item.time}</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={isDark ? '#475569' : '#cbd5e1'} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Bottom spacing for tab bar */}
        <View style={{ height: 80 }} />
      </ScrollView>

      {/* ═══════════════════════════════════════════════════════════════════════════
          MODALS
      ═══════════════════════════════════════════════════════════════════════════ */}
      
      {/* Deposit Method Selection */}
      <DepositMethodModal
        visible={showDepositMethod}
        onClose={() => setShowDepositMethod(false)}
        onSelectCrypto={handleSelectCrypto}
        onSelectUsd={handleSelectUsd}
      />

      {/* Coin Selection for Crypto Deposit */}
      <CoinSelectModal
        visible={showCoinSelect}
        onClose={() => setShowCoinSelect(false)}
        onSelectCoin={handleSelectCoin}
      />

      {/* Deposit Address with QR */}
      <DepositAddressModal
        visible={showDepositAddress}
        onClose={() => {
          setShowDepositAddress(false);
          setSelectedCoin(null);
        }}
        coin={selectedCoin}
      />

      {/* USD Deposit (Coming Soon) */}
      <UsdDepositModal
        visible={showUsdDeposit}
        onClose={() => setShowUsdDeposit(false)}
      />

      {/* Quick Buy Modal */}
      <QuickBuyModal
        visible={showQuickBuy}
        onClose={() => setShowQuickBuy(false)}
      />

      {/* Risk & Correlation Modal */}
      <RiskCorrelationModal
        visible={showRiskModal}
        onClose={() => setShowRiskModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 0 },
  
  // Banner
  bannerContainer: { marginHorizontal: 16, marginTop: 4, marginBottom: 6 },
  bannerPlaceholder: { height: 90, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  bannerTitle: { fontSize: 15, fontWeight: '600' },
  bannerSubtitle: { fontSize: 10, marginTop: 2 },
  bannerIndicators: { flexDirection: 'row', position: 'absolute', bottom: 8, gap: 4 },
  indicator: { width: 6, height: 6, borderRadius: 3 },

  // Action Buttons
  actionsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 10,
    gap: 8,
  },
  actionButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  actionIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  actionLabel: {
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'center',
  },

  // Trust Card Styles
  trustContainer: {
    marginHorizontal: 16,
    marginVertical: 6,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#10b981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  trustGradient: {
    padding: 16,
  },
  trustLiveIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  trustLiveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#4ade80',
    marginRight: 4,
  },
  trustLiveText: {
    fontSize: 9,
    color: '#4ade80',
    fontWeight: '600',
  },
  trustHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  trustIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  trustHeaderText: {
    flex: 1,
  },
  trustTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
  trustSubtitle: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  trustLaunchMessage: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    padding: 12,
    marginTop: 12,
  },
  trustLaunchText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.9)',
    textAlign: 'center',
    lineHeight: 18,
  },
  trustQuickLinks: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 6,
  },
  trustQuickLink: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingVertical: 8,
    borderRadius: 8,
  },
  trustQuickLinkText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: '500',
  },

  tabContainer: { flexDirection: 'row', marginHorizontal: 16, marginBottom: 10, borderRadius: 10, padding: 3 },
  tab: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 8 },
  activeTab: { backgroundColor: '#10b98120' },
  tabText: { fontSize: 12, fontWeight: '600' },

  listSection: { marginHorizontal: 16, marginBottom: 10, borderRadius: 12, overflow: 'hidden' },
  
  tableHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingTop: 12, paddingBottom: 8 },
  headerTitle: { flex: 1, fontSize: 13, fontWeight: '600', marginLeft: 44 },
  headerLabel: { width: 70, fontSize: 9, textAlign: 'center' },

  priceRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1 },
  priceRowLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  coinIcon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  metalImage: { width: 22, height: 22 },
  auxmIcon: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  auxmIconText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  metalDot: { width: 12, height: 12, borderRadius: 6 },
  cryptoIcon: { fontSize: 16, fontWeight: 'bold' },
  coinSymbol: { fontSize: 13, fontWeight: '600' },
  coinName: { fontSize: 10, marginTop: 1 },
  coinPrice: { width: 70, fontSize: 12, fontWeight: '600', textAlign: 'center' },
  changeValue: { width: 70, fontSize: 11, fontWeight: '500', textAlign: 'right' },

  stakeHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingTop: 12, paddingBottom: 8 },
  apyLabels: { flexDirection: 'row', width: 120, justifyContent: 'space-between' },
  apyLabel: { fontSize: 10, fontWeight: '500', width: 36, textAlign: 'center' },

  leaseRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1 },
  leaseRowLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  leaseRates: { flexDirection: 'row', width: 120, justifyContent: 'space-between' },
  rateApy: { fontSize: 12, fontWeight: '600', width: 36, textAlign: 'center' },

  riskCard: { marginHorizontal: 16, marginBottom: 10, padding: 14, borderRadius: 12 },
  riskHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  viewMoreBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#10b98120', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, gap: 2 },
  viewMoreText: { fontSize: 10, fontWeight: '600', color: '#10b981' },
  sectionTitle: { fontSize: 13, fontWeight: '600' },
  riskGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  riskItem: { width: '48%', padding: 10, borderRadius: 8 },
  riskLabel: { fontSize: 10, marginBottom: 2 },
  riskValue: { fontSize: 13, fontWeight: '600' },

  // Markets Section - Card Grid
  marketsSection: { paddingHorizontal: 16, marginBottom: 10 },
  marketHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  marketHeaderTitle: { fontSize: 14, fontWeight: '600' },
  seeAllText: { fontSize: 12, color: '#10b981', fontWeight: '500' },
  cardsRow: { flexDirection: 'row', gap: 10 },
  assetCard: { 
    flex: 1, 
    padding: 12, 
    borderRadius: 14, 
    alignItems: 'center',
  },
  cardIconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  cardMetalImage: { width: 26, height: 26 },
  cardIconText: { fontSize: 20, fontWeight: '700' },
  cardSymbol: { fontSize: 13, fontWeight: '700', marginBottom: 2 },
  cardPrice: { fontSize: 11, marginBottom: 6 },
  cardChangeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    gap: 2,
  },
  cardChange: { fontSize: 10, fontWeight: '600' },

  newsSection: { marginBottom: 10 },
  newsItem: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, padding: 12, borderRadius: 10, marginBottom: 6 },
  newsContent: { flex: 1 },
  newsTitle: { fontSize: 12, fontWeight: '500' },
  newsMeta: { fontSize: 10, marginTop: 2 },
});
