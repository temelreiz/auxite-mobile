// app/wallet-onboarding.tsx
// WalletOnboarding Sayfası - Expo Router

import React from 'react';
import { useRouter } from 'expo-router';
import WalletOnboarding from '../components/WalletOnboarding';

export default function WalletOnboardingScreen() {
  const router = useRouter();

  const handleWalletReady = (address: string) => {
    console.log('Wallet ready:', address);
    // Ana sayfaya yönlendir
    router.replace('/(tabs)');
  };

  return (
    <WalletOnboarding
      lang="tr"
      onWalletReady={handleWalletReady}
    />
  );
}
