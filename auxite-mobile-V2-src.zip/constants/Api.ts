// API Base URL - Production
export const API_BASE_URL = 'https://auxite-wallet.vercel.app';

// API Endpoints
export const ENDPOINTS = {
  // Prices
  METALS: '/api/metals',
  CRYPTO: '/api/crypto',
  PRICES: '/api/prices',
  
  // User
  USER_BALANCE: '/api/user/balance',
  USER_REGISTER: '/api/user/register',
  USER_TRANSACTIONS: '/api/user/transactions',
  
  // Trading
  TRADE: '/api/trade',
  QUOTE: '/api/quote',
  WITHDRAW: '/api/withdraw',
  
  // Staking
  LEASE_RATES: '/api/lease-rates',
  
  // Security
  SECURITY_2FA_STATUS: '/api/security/2fa/status',
  SECURITY_2FA_SETUP: '/api/security/2fa/setup',
  SECURITY_2FA_VERIFY: '/api/security/2fa/verify',
  SECURITY_BIOMETRIC: '/api/security/biometric',
  SECURITY_DEVICES: '/api/security/devices',
  
  // KYC
  KYC_STATUS: '/api/kyc',
  KYC_SUMSUB: '/api/kyc/sumsub',
};

// WebSocket URL (for real-time prices)
export const WS_URL = 'wss://auxite.com/ws';

// Supported chains
export const SUPPORTED_CHAINS = {
  POLYGON: {
    id: 137,
    name: 'Polygon',
    rpcUrl: 'https://polygon-rpc.com',
    explorer: 'https://polygonscan.com',
  },
};

// Contract addresses
export const CONTRACTS = {
  AUXM: '0x...',
  AUXG: '0x...',
  AUXS: '0x...',
  AUXPT: '0x...',
  AUXPD: '0x...',
};
