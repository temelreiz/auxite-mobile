// components/DepositModals.tsx
// Deposit Modal System - Crypto & USD Deposit

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  ScrollView,
  TextInput,
  useColorScheme,
  Alert,
  Clipboard,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useStore } from '@/stores/useStore';

// ============================================
// TYPES
// ============================================
type CoinType = 'BTC' | 'ETH' | 'XRP' | 'SOL' | 'USDT';

interface DepositCoin {
  id: CoinType;
  name: string;
  icon: string;
  color: string;
  network: string;
  minDeposit: string;
  confirmTime: string;
  address: string;
  memo?: string;
}

// ============================================
// COIN DATA
// ============================================
const DEPOSIT_COINS: DepositCoin[] = [
  { 
    id: 'BTC', 
    name: 'Bitcoin', 
    icon: '₿', 
    color: '#F7931A', 
    network: 'Bitcoin Network',
    minDeposit: '0.0001 BTC',
    confirmTime: '~30 min',
    address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
  },
  { 
    id: 'ETH', 
    name: 'Ethereum', 
    icon: 'Ξ', 
    color: '#627EEA', 
    network: 'ERC-20',
    minDeposit: '0.001 ETH',
    confirmTime: '~5 min',
    address: '0x742d35Cc6634C0532925a3b844Bc9e7595f5bAcE'
  },
  { 
    id: 'XRP', 
    name: 'Ripple', 
    icon: '✕', 
    color: '#23292F', 
    network: 'XRP Ledger',
    minDeposit: '10 XRP',
    confirmTime: '~10 sec',
    address: 'rPVMhWBsfF9iMXYj3aAzJVkPDTFNSyWdKy',
    memo: '12345678'
  },
  { 
    id: 'SOL', 
    name: 'Solana', 
    icon: '◎', 
    color: '#9945FF', 
    network: 'Solana',
    minDeposit: '0.01 SOL',
    confirmTime: '~1 min',
    address: '7EYnhQoR9YM3N7UoaKRoA44Uy8JeaZV3qyouov87awMs'
  },
  { 
    id: 'USDT', 
    name: 'Tether', 
    icon: '₮', 
    color: '#26A17B', 
    network: 'ERC-20 / TRC-20',
    minDeposit: '10 USDT',
    confirmTime: '~5 min',
    address: '0x742d35Cc6634C0532925a3b844Bc9e7595f5bAcE'
  },
];

// ============================================
// TRANSLATIONS
// ============================================
const translations: Record<string, Record<string, string>> = {
  tr: {
    selectMethod: 'Yatırma Yöntemi Seçin',
    cryptoDeposit: 'Kripto Yatır',
    cryptoDepositDesc: 'Diğer borsalardan/cüzdanlardan kripto yatırın',
    usdDeposit: 'USD Yatır',
    usdDepositDesc: 'Kredi kartı ile USD yatırın (MoonPay)',
    selectCoin: 'Yatırılacak Coin Seç',
    deposit: 'Yatır',
    address: 'Adres',
    copy: 'Kopyala',
    copied: 'Kopyalandı!',
    minDeposit: 'Min. Yatırım',
    confirmTime: 'Onay Süresi',
    network: 'Ağ',
    destinationTag: 'Destination Tag',
    tagWarning: 'Tag olmadan gönderim yaparsanız bakiyeniz kaybolabilir!',
    close: 'Kapat',
    comingSoon: 'Yakında Aktif',
    comingSoonDesc: 'Kredi kartı ile USD yatırma özelliği çok yakında hizmetinizde olacak.',
    poweredBy: 'Powered by MoonPay',
    ok: 'Tamam',
    testDeposit: 'Test Yatırımı',
    amount: 'Miktar',
    depositBtn: 'Yatır',
    processing: 'İşleniyor...',
    convertToAuxm: 'AUXM\'e Dönüştür',
    conversionDesc: '1 AUXM = 1 USD + bonus',
  },
  en: {
    selectMethod: 'Select Deposit Method',
    cryptoDeposit: 'Deposit Crypto',
    cryptoDepositDesc: 'Deposit crypto from other exchanges/wallets',
    usdDeposit: 'Deposit USD',
    usdDepositDesc: 'Deposit USD via credit card (MoonPay)',
    selectCoin: 'Select Coin to Deposit',
    deposit: 'Deposit',
    address: 'Address',
    copy: 'Copy',
    copied: 'Copied!',
    minDeposit: 'Min. Deposit',
    confirmTime: 'Confirm Time',
    network: 'Network',
    destinationTag: 'Destination Tag',
    tagWarning: 'Your funds may be lost if you send without the tag!',
    close: 'Close',
    comingSoon: 'Coming Soon',
    comingSoonDesc: 'Credit card USD deposit feature will be available very soon.',
    poweredBy: 'Powered by MoonPay',
    ok: 'OK',
    testDeposit: 'Test Deposit',
    amount: 'Amount',
    depositBtn: 'Deposit',
    processing: 'Processing...',
    convertToAuxm: 'Convert to AUXM',
    conversionDesc: '1 AUXM = 1 USD + bonus',
  },
};

// ============================================
// PROPS
// ============================================
interface DepositMethodModalProps {
  visible: boolean;
  onClose: () => void;
  onSelectCrypto: () => void;
  onSelectUsd: () => void;
}

interface CoinSelectModalProps {
  visible: boolean;
  onClose: () => void;
  onSelectCoin: (coin: DepositCoin) => void;
}

interface DepositAddressModalProps {
  visible: boolean;
  onClose: () => void;
  coin: DepositCoin | null;
}

interface UsdDepositModalProps {
  visible: boolean;
  onClose: () => void;
}

// ============================================
// 1. DEPOSIT METHOD SELECTION MODAL
// ============================================
export function DepositMethodModal({ visible, onClose, onSelectCrypto, onSelectUsd }: DepositMethodModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.selectMethod}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          {/* Options */}
          <View style={styles.optionsContainer}>
            {/* Crypto Deposit */}
            <TouchableOpacity
              style={[styles.optionCard, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: isDark ? '#334155' : '#e2e8f0' }]}
              onPress={onSelectCrypto}
              activeOpacity={0.7}
            >
              <View style={[styles.optionIcon, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]}>
                <Ionicons name="download-outline" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
              </View>
              <View style={styles.optionText}>
                <Text style={[styles.optionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.cryptoDeposit}</Text>
                <Text style={[styles.optionDesc, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.cryptoDepositDesc}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
            </TouchableOpacity>

            {/* USD Deposit */}
            <TouchableOpacity
              style={[styles.optionCard, { backgroundColor: '#10b98115', borderColor: '#10b98130' }]}
              onPress={onSelectUsd}
              activeOpacity={0.7}
            >
              <View style={[styles.optionIcon, { backgroundColor: '#10b98120' }]}>
                <Text style={styles.dollarIcon}>$</Text>
              </View>
              <View style={styles.optionText}>
                <Text style={[styles.optionTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.usdDeposit}</Text>
                <Text style={[styles.optionDesc, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.usdDepositDesc}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 2. COIN SELECTION MODAL
// ============================================
export function CoinSelectModal({ visible, onClose, onSelectCoin }: CoinSelectModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.selectCoin}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          {/* Coin List */}
          <ScrollView style={styles.coinList}>
            {DEPOSIT_COINS.map((coin) => (
              <TouchableOpacity
                key={coin.id}
                style={[styles.coinItem, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: isDark ? '#334155' : '#e2e8f0' }]}
                onPress={() => onSelectCoin(coin)}
                activeOpacity={0.7}
              >
                <View style={[styles.coinIcon, { backgroundColor: coin.color + '20' }]}>
                  <Text style={[styles.coinIconText, { color: coin.color }]}>{coin.icon}</Text>
                </View>
                <View style={styles.coinInfo}>
                  <Text style={[styles.coinSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{coin.id}</Text>
                  <Text style={[styles.coinName, { color: isDark ? '#94a3b8' : '#64748b' }]}>{coin.name}</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 3. DEPOSIT ADDRESS MODAL
// ============================================
export function DepositAddressModal({ visible, onClose, coin }: DepositAddressModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  const [copied, setCopied] = useState(false);
  const [copiedMemo, setCopiedMemo] = useState(false);
  const [testAmount, setTestAmount] = useState('');
  const [isDepositing, setIsDepositing] = useState(false);

  if (!coin) return null;

  const handleCopyAddress = () => {
    Clipboard.setString(coin.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyMemo = () => {
    if (coin.memo) {
      Clipboard.setString(coin.memo);
      setCopiedMemo(true);
      setTimeout(() => setCopiedMemo(false), 2000);
    }
  };

  const handleTestDeposit = async () => {
    if (!testAmount) return;
    setIsDepositing(true);
    // Simulate deposit
    await new Promise(r => setTimeout(r, 1500));
    setIsDepositing(false);
    Alert.alert('Success', `Test deposit of ${testAmount} ${coin.id} completed!`);
    setTestAmount('');
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff', maxHeight: '85%' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View style={styles.coinHeaderRow}>
              <View style={[styles.coinIconLarge, { backgroundColor: coin.color + '20' }]}>
                <Text style={[styles.coinIconTextLarge, { color: coin.color }]}>{coin.icon}</Text>
              </View>
              <View>
                <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{coin.id} {t.deposit}</Text>
                <Text style={[styles.networkText, { color: isDark ? '#94a3b8' : '#64748b' }]}>{coin.network}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* QR Code Placeholder */}
            <View style={[styles.qrContainer, { backgroundColor: '#fff' }]}>
              <View style={styles.qrPlaceholder}>
                <Ionicons name="qr-code" size={100} color="#cbd5e1" />
              </View>
            </View>

            {/* Address */}
            <View style={[styles.addressContainer, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
              <View style={styles.addressHeader}>
                <Text style={[styles.addressLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.address}</Text>
                <TouchableOpacity onPress={handleCopyAddress}>
                  <Text style={[styles.copyButton, { color: copied ? '#10b981' : '#10b981' }]}>
                    {copied ? `✓ ${t.copied}` : t.copy}
                  </Text>
                </TouchableOpacity>
              </View>
              <Text style={[styles.addressText, { color: isDark ? '#fff' : '#0f172a' }]} selectable>
                {coin.address}
              </Text>
            </View>

            {/* Memo (XRP) */}
            {coin.memo && (
              <View style={[styles.memoContainer, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
                <View style={styles.addressHeader}>
                  <Text style={styles.memoLabel}>⚠️ {t.destinationTag}</Text>
                  <TouchableOpacity onPress={handleCopyMemo}>
                    <Text style={[styles.copyButton, { color: copiedMemo ? '#f59e0b' : '#f59e0b' }]}>
                      {copiedMemo ? '✓' : t.copy}
                    </Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.memoText}>{coin.memo}</Text>
                <Text style={styles.memoWarning}>{t.tagWarning}</Text>
              </View>
            )}

            {/* Info */}
            <View style={[styles.infoContainer, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
              <View style={styles.infoRow}>
                <Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.minDeposit}</Text>
                <Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>{coin.minDeposit}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={[styles.infoLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.confirmTime}</Text>
                <Text style={[styles.infoValue, { color: isDark ? '#fff' : '#0f172a' }]}>{coin.confirmTime}</Text>
              </View>
            </View>

            {/* Test Deposit */}
            <View style={[styles.testContainer, { backgroundColor: isDark ? '#7c3aed15' : '#f3e8ff', borderColor: '#7c3aed30' }]}>
              <Text style={styles.testTitle}>🧪 {t.testDeposit}</Text>
              <View style={styles.testInputRow}>
                <TextInput
                  style={[styles.testInput, { backgroundColor: isDark ? '#1e293b' : '#fff', color: isDark ? '#fff' : '#0f172a' }]}
                  value={testAmount}
                  onChangeText={setTestAmount}
                  placeholder={`0.00 ${coin.id}`}
                  placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
                  keyboardType="decimal-pad"
                />
              </View>
              <TouchableOpacity
                style={[styles.testButton, (!testAmount || isDepositing) && styles.testButtonDisabled]}
                onPress={handleTestDeposit}
                disabled={!testAmount || isDepositing}
              >
                {isDepositing ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.testButtonText}>{t.depositBtn}</Text>
                )}
              </TouchableOpacity>
            </View>

            {/* Close Button */}
            <TouchableOpacity
              style={[styles.closeModalButton, { backgroundColor: isDark ? '#0f172a' : '#e2e8f0' }]}
              onPress={onClose}
            >
              <Text style={[styles.closeModalButtonText, { color: isDark ? '#fff' : '#0f172a' }]}>{t.close}</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 4. USD DEPOSIT MODAL (Coming Soon)
// ============================================
export function UsdDepositModal({ visible, onClose }: UsdDepositModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.usdDeposit}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                Credit/Debit Card
              </Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          {/* Coming Soon Content */}
          <View style={styles.comingSoonContainer}>
            <View style={[styles.comingSoonIcon, { backgroundColor: '#8b5cf620' }]}>
              <Ionicons name="time-outline" size={48} color="#8b5cf6" />
            </View>
            <Text style={[styles.comingSoonTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.comingSoon}</Text>
            <Text style={[styles.comingSoonDesc, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.comingSoonDesc}</Text>

            {/* MoonPay Badge */}
            <View style={[styles.moonpayBadge, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
              <View style={styles.moonpayIcon}>
                <Text style={styles.moonpayIconText}>🌙</Text>
              </View>
              <Text style={[styles.moonpayText, { color: isDark ? '#fff' : '#0f172a' }]}>MoonPay</Text>
            </View>
            <Text style={[styles.poweredBy, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.poweredBy}</Text>

            <TouchableOpacity style={styles.okButton} onPress={onClose}>
              <LinearGradient colors={['#8b5cf6', '#7c3aed']} style={styles.okButtonGradient}>
                <Text style={styles.okButtonText}>{t.ok}</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(148,163,184,0.2)' },
  modalTitle: { fontSize: 18, fontWeight: '700' },
  modalSubtitle: { fontSize: 12, marginTop: 2 },
  closeButton: { padding: 4 },

  // Options
  optionsContainer: { padding: 16, gap: 12 },
  optionCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 16, borderWidth: 1 },
  optionIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  dollarIcon: { fontSize: 22, fontWeight: '700', color: '#10b981' },
  optionText: { flex: 1 },
  optionTitle: { fontSize: 15, fontWeight: '600', marginBottom: 4 },
  optionDesc: { fontSize: 12 },

  // Coin List
  coinList: { padding: 16 },
  coinItem: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 14, borderWidth: 1, marginBottom: 10 },
  coinIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  coinIconText: { fontSize: 20, fontWeight: '700' },
  coinInfo: { flex: 1 },
  coinSymbol: { fontSize: 15, fontWeight: '600' },
  coinName: { fontSize: 12, marginTop: 2 },

  // Coin Header Row
  coinHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  coinIconLarge: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  coinIconTextLarge: { fontSize: 22, fontWeight: '700' },
  networkText: { fontSize: 11, marginTop: 2 },

  // QR
  qrContainer: { alignItems: 'center', justifyContent: 'center', margin: 16, padding: 20, borderRadius: 16 },
  qrPlaceholder: { width: 140, height: 140, alignItems: 'center', justifyContent: 'center' },

  // Address
  addressContainer: { marginHorizontal: 16, padding: 14, borderRadius: 14, marginBottom: 12 },
  addressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  addressLabel: { fontSize: 11 },
  copyButton: { fontSize: 11, fontWeight: '600' },
  addressText: { fontSize: 11, fontFamily: 'monospace', lineHeight: 18 },

  // Memo
  memoContainer: { marginHorizontal: 16, padding: 14, borderRadius: 14, borderWidth: 1, marginBottom: 12 },
  memoLabel: { fontSize: 11, fontWeight: '600', color: '#f59e0b' },
  memoText: { fontSize: 18, fontWeight: '700', color: '#f59e0b', marginTop: 6 },
  memoWarning: { fontSize: 10, color: '#f59e0b', marginTop: 6 },

  // Info
  infoContainer: { marginHorizontal: 16, padding: 14, borderRadius: 14, marginBottom: 12 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  infoLabel: { fontSize: 11 },
  infoValue: { fontSize: 11, fontWeight: '500' },

  // Test Deposit
  testContainer: { marginHorizontal: 16, padding: 14, borderRadius: 14, borderWidth: 1, marginBottom: 16 },
  testTitle: { fontSize: 12, fontWeight: '600', color: '#8b5cf6', marginBottom: 12 },
  testInputRow: { marginBottom: 12 },
  testInput: { borderRadius: 10, padding: 12, fontSize: 14, fontFamily: 'monospace' },
  testButton: { backgroundColor: '#8b5cf6', borderRadius: 10, padding: 12, alignItems: 'center' },
  testButtonDisabled: { opacity: 0.5 },
  testButtonText: { color: '#fff', fontSize: 13, fontWeight: '600' },

  // Close Button
  closeModalButton: { marginHorizontal: 16, padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 16 },
  closeModalButtonText: { fontSize: 15, fontWeight: '600' },

  // Coming Soon
  comingSoonContainer: { alignItems: 'center', padding: 32 },
  comingSoonIcon: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  comingSoonTitle: { fontSize: 20, fontWeight: '700', marginBottom: 8 },
  comingSoonDesc: { fontSize: 13, textAlign: 'center', marginBottom: 24 },
  moonpayBadge: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 12, gap: 8, marginBottom: 8 },
  moonpayIcon: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#7c3aed', alignItems: 'center', justifyContent: 'center' },
  moonpayIconText: { fontSize: 14 },
  moonpayText: { fontSize: 15, fontWeight: '600' },
  poweredBy: { fontSize: 11, marginBottom: 24 },
  okButton: { width: '100%', borderRadius: 14, overflow: 'hidden' },
  okButtonGradient: { padding: 16, alignItems: 'center' },
  okButtonText: { color: '#fff', fontSize: 15, fontWeight: '600' },
});

export { DEPOSIT_COINS };
export type { DepositCoin };
