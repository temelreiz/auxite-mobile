// components/QuickBuyModal.tsx
// Quick Buy Metal Modal - React Native Version
// 6-Language Support | Dark/Light Mode

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  ScrollView,
  useColorScheme,
  ActivityIndicator,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useStore } from '@/stores/useStore';

// ============================================
// TRANSLATIONS (6 Languages)
// ============================================
const translations: Record<string, Record<string, string>> = {
  tr: {
    buyMetal: 'Metal Satın Al',
    selectMetal: 'Metal Seçin',
    youPay: 'Ödeme',
    youReceive: 'Alacağınız',
    balance: 'Bakiye',
    total: 'Toplam',
    transactionFee: 'İşlem Ücreti',
    getQuote: 'Fiyat Al',
    confirm: 'Onayla',
    processing: 'İşleniyor...',
    success: 'Başarılı!',
    insufficientBalance: 'Yetersiz bakiye',
    minAmount: 'Minimum miktar',
    maxAmount: 'Maksimum miktar',
    enterAmount: 'Miktar girin',
    gold: 'Altın',
    silver: 'Gümüş',
    platinum: 'Platin',
    palladium: 'Paladyum',
  },
  en: {
    buyMetal: 'Buy Metal',
    selectMetal: 'Select Metal',
    youPay: 'You Pay',
    youReceive: 'You Receive',
    balance: 'Balance',
    total: 'Total',
    transactionFee: 'Transaction fee',
    getQuote: 'Get Quote',
    confirm: 'Confirm',
    processing: 'Processing...',
    success: 'Success!',
    insufficientBalance: 'Insufficient balance',
    minAmount: 'Minimum amount',
    maxAmount: 'Maximum amount',
    enterAmount: 'Enter amount',
    gold: 'Gold',
    silver: 'Silver',
    platinum: 'Platinum',
    palladium: 'Palladium',
  },
  de: {
    buyMetal: 'Metall kaufen',
    selectMetal: 'Metall auswählen',
    youPay: 'Sie zahlen',
    youReceive: 'Sie erhalten',
    balance: 'Guthaben',
    total: 'Gesamt',
    transactionFee: 'Transaktionsgebühr',
    getQuote: 'Angebot anfordern',
    confirm: 'Bestätigen',
    processing: 'Verarbeitung...',
    success: 'Erfolgreich!',
    insufficientBalance: 'Unzureichendes Guthaben',
    minAmount: 'Mindestbetrag',
    maxAmount: 'Höchstbetrag',
    enterAmount: 'Betrag eingeben',
    gold: 'Gold',
    silver: 'Silber',
    platinum: 'Platin',
    palladium: 'Palladium',
  },
  fr: {
    buyMetal: 'Acheter du Métal',
    selectMetal: 'Sélectionner le métal',
    youPay: 'Vous payez',
    youReceive: 'Vous recevez',
    balance: 'Solde',
    total: 'Total',
    transactionFee: 'Frais de transaction',
    getQuote: 'Obtenir un devis',
    confirm: 'Confirmer',
    processing: 'Traitement...',
    success: 'Succès !',
    insufficientBalance: 'Solde insuffisant',
    minAmount: 'Montant minimum',
    maxAmount: 'Montant maximum',
    enterAmount: 'Entrez le montant',
    gold: 'Or',
    silver: 'Argent',
    platinum: 'Platine',
    palladium: 'Palladium',
  },
  ar: {
    buyMetal: 'شراء المعدن',
    selectMetal: 'اختر المعدن',
    youPay: 'تدفع',
    youReceive: 'تستلم',
    balance: 'الرصيد',
    total: 'المجموع',
    transactionFee: 'رسوم المعاملة',
    getQuote: 'احصل على عرض',
    confirm: 'تأكيد',
    processing: 'جاري المعالجة...',
    success: 'نجاح!',
    insufficientBalance: 'رصيد غير كافٍ',
    minAmount: 'الحد الأدنى للمبلغ',
    maxAmount: 'الحد الأقصى للمبلغ',
    enterAmount: 'أدخل المبلغ',
    gold: 'ذهب',
    silver: 'فضة',
    platinum: 'بلاتين',
    palladium: 'بالاديوم',
  },
  ru: {
    buyMetal: 'Купить металл',
    selectMetal: 'Выберите металл',
    youPay: 'Вы платите',
    youReceive: 'Вы получите',
    balance: 'Баланс',
    total: 'Итого',
    transactionFee: 'Комиссия',
    getQuote: 'Получить котировку',
    confirm: 'Подтвердить',
    processing: 'Обработка...',
    success: 'Успешно!',
    insufficientBalance: 'Недостаточно средств',
    minAmount: 'Минимальная сумма',
    maxAmount: 'Максимальная сумма',
    enterAmount: 'Введите сумму',
    gold: 'Золото',
    silver: 'Серебро',
    platinum: 'Платина',
    palladium: 'Палладий',
  },
};

// ============================================
// METALS & PAYMENT METHODS
// ============================================
const METALS = [
  { symbol: 'AUXG', name: 'gold', color: '#F59E0B', price: 140 },
  { symbol: 'AUXS', name: 'silver', color: '#94A3B8', price: 2 },
  { symbol: 'AUXPT', name: 'platinum', color: '#06B6D4', price: 58 },
  { symbol: 'AUXPD', name: 'palladium', color: '#8B5CF6', price: 50 },
];

const PAYMENT_METHODS = [
  { symbol: 'AUXM', icon: '◇', name: 'AUXM', color: '#A855F7' },
  { symbol: 'USDT', icon: '₮', name: 'USDT', color: '#26A17B' },
  { symbol: 'BTC', icon: '₿', name: 'BTC', color: '#F7931A' },
  { symbol: 'ETH', icon: 'Ξ', name: 'ETH', color: '#627EEA' },
  { symbol: 'XRP', icon: '✕', name: 'XRP', color: '#00AAE4' },
  { symbol: 'SOL', icon: '◎', name: 'SOL', color: '#9945FF' },
];

// ============================================
// PROPS
// ============================================
interface QuickBuyModalProps {
  visible: boolean;
  onClose: () => void;
}

// ============================================
// MAIN COMPONENT
// ============================================
export default function QuickBuyModal({ visible, onClose }: QuickBuyModalProps) {
  const colorScheme = useColorScheme();
  const insets = useSafeAreaInsets();
  const { language, theme } = useStore();

  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  const [selectedMetal, setSelectedMetal] = useState(METALS[0]);
  const [selectedPayment, setSelectedPayment] = useState(PAYMENT_METHODS[0]);
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Mock balances
  const balances: Record<string, number> = {
    AUXM: 375.01,
    USDT: 1250.00,
    BTC: 0.0125,
    ETH: 0.658,
    XRP: 1500.00,
    SOL: 12.5,
  };

  const balance = balances[selectedPayment.symbol] || 0;
  const amountNum = parseFloat(amount) || 0;
  
  // Coin prices in USD (mock)
  const coinPrices: Record<string, number> = {
    AUXM: 1,       // 1:1 USD
    USDT: 1,       // 1:1 USD
    BTC: 95000,
    ETH: 3400,
    XRP: 2.20,
    SOL: 180,
  };
  
  const paymentValueUSD = amountNum * (coinPrices[selectedPayment.symbol] || 1);
  const receiveAmount = paymentValueUSD / selectedMetal.price;

  const isValidAmount = amountNum > 0 && amountNum <= balance;

  const handleGetQuote = () => {
    if (!isValidAmount) return;
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      // TODO: Implement actual quote/buy logic
      onClose();
    }, 1500);
  };

  const handleMaxPress = () => {
    setAmount(balance.toString());
  };

  // Colors
  const colors = {
    background: isDark ? '#0f172a' : '#ffffff',
    surface: isDark ? '#1e293b' : '#f8fafc',
    surfaceAlt: isDark ? '#334155' : '#f1f5f9',
    border: isDark ? '#334155' : '#e2e8f0',
    text: isDark ? '#ffffff' : '#0f172a',
    textSecondary: isDark ? '#94a3b8' : '#64748b',
    primary: '#10b981',
    primaryLight: isDark ? '#10b98130' : '#10b98120',
    purple: '#8b5cf6',
    purpleLight: isDark ? '#8b5cf630' : '#8b5cf620',
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{t.buyMetal}</Text>
          <TouchableOpacity
            style={[styles.closeButton, { backgroundColor: colors.surface }]}
            onPress={onClose}
          >
            <Ionicons name="close" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <ScrollView
          style={styles.content}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Select Metal */}
          <View style={styles.section}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
              {t.selectMetal}
            </Text>
            <View style={styles.metalGrid}>
              {METALS.map((metal) => (
                <TouchableOpacity
                  key={metal.symbol}
                  style={[
                    styles.metalCard,
                    {
                      backgroundColor: colors.surface,
                      borderColor: selectedMetal.symbol === metal.symbol ? colors.primary : colors.border,
                      borderWidth: selectedMetal.symbol === metal.symbol ? 2 : 1,
                    },
                    selectedMetal.symbol === metal.symbol && { backgroundColor: colors.primaryLight },
                  ]}
                  onPress={() => setSelectedMetal(metal)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.metalIcon, { backgroundColor: metal.color + '20' }]}>
                    <View style={[styles.metalDot, { backgroundColor: metal.color }]} />
                  </View>
                  <Text
                    style={[
                      styles.metalSymbol,
                      {
                        color: selectedMetal.symbol === metal.symbol ? colors.primary : colors.text,
                      },
                    ]}
                  >
                    {metal.symbol}
                  </Text>
                  <Text style={[styles.metalPrice, { color: colors.textSecondary }]}>
                    ${metal.price}/g
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* You Pay */}
          <View style={styles.section}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
              {t.youPay}
            </Text>
            
            {/* Payment Methods */}
            <View style={styles.paymentGrid}>
              {PAYMENT_METHODS.map((method) => (
                <TouchableOpacity
                  key={method.symbol}
                  style={[
                    styles.paymentCard,
                    {
                      backgroundColor: colors.surface,
                      borderColor: selectedPayment.symbol === method.symbol ? method.color : colors.border,
                      borderWidth: selectedPayment.symbol === method.symbol ? 2 : 1,
                    },
                    selectedPayment.symbol === method.symbol && { backgroundColor: method.color + '15' },
                  ]}
                  onPress={() => setSelectedPayment(method)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.paymentIconBg, { backgroundColor: method.color }]}>
                    <Text style={styles.paymentIcon}>{method.icon}</Text>
                  </View>
                  <Text
                    style={[
                      styles.paymentSymbol,
                      {
                        color: selectedPayment.symbol === method.symbol ? method.color : colors.text,
                      },
                    ]}
                  >
                    {method.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Balance Info */}
            <View style={styles.balanceRow}>
              <Text style={[styles.balanceLabel, { color: colors.textSecondary }]}>
                {t.balance}:
              </Text>
              <Text style={[styles.balanceValue, { color: colors.text }]}>
                {balance.toFixed(['BTC', 'ETH', 'SOL'].includes(selectedPayment.symbol) ? 4 : 2)} {selectedPayment.symbol}
              </Text>
            </View>

            {/* Amount Input */}
            <View style={[styles.inputContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <TextInput
                style={[styles.input, { color: colors.text }]}
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                placeholderTextColor={colors.textSecondary}
                keyboardType="decimal-pad"
              />
              <TouchableOpacity
                style={[styles.maxButton, { backgroundColor: colors.surfaceAlt }]}
                onPress={handleMaxPress}
              >
                <Text style={[styles.maxButtonText, { color: colors.textSecondary }]}>MAX</Text>
              </TouchableOpacity>
            </View>

            {/* Insufficient Balance Warning */}
            {amountNum > balance && (
              <Text style={styles.errorText}>{t.insufficientBalance}</Text>
            )}
          </View>

          {/* Arrow Divider */}
          <View style={styles.arrowContainer}>
            <View style={[styles.arrowCircle, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Ionicons name="arrow-down" size={20} color={colors.primary} />
            </View>
          </View>

          {/* You Receive */}
          <View style={styles.section}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
              {t.youReceive}
            </Text>
            <View style={[styles.receiveCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={[styles.receiveIcon, { backgroundColor: selectedMetal.color + '20' }]}>
                <View style={[styles.receiveDot, { backgroundColor: selectedMetal.color }]} />
              </View>
              <View style={styles.receiveInfo}>
                <View style={styles.receiveAmountRow}>
                  <Text style={[styles.receiveAmount, { color: colors.text }]}>
                    {receiveAmount.toFixed(4)}g
                  </Text>
                  <Text style={[styles.receiveSymbol, { color: colors.textSecondary }]}>
                    {selectedMetal.symbol}
                  </Text>
                </View>
                <Text style={[styles.receivePrice, { color: colors.textSecondary }]}>
                  @ ${selectedMetal.price.toFixed(2)}/gram
                </Text>
              </View>
            </View>
          </View>

          {/* Transaction Fee */}
          <View style={[styles.feeRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.feeLabel, { color: colors.textSecondary }]}>
              {t.transactionFee}:
            </Text>
            <Text style={[styles.feeValue, { color: colors.text }]}>0.1%</Text>
          </View>
        </ScrollView>

        {/* Footer Button */}
        <View style={[styles.footer, { paddingBottom: insets.bottom + 16, borderTopColor: colors.border }]}>
          <TouchableOpacity
            style={[
              styles.submitButton,
              !isValidAmount && styles.submitButtonDisabled,
            ]}
            onPress={handleGetQuote}
            disabled={!isValidAmount || isProcessing}
            activeOpacity={0.8}
          >
            {isProcessing ? (
              <>
                <ActivityIndicator size="small" color="#ffffff" />
                <Text style={styles.submitButtonText}>{t.processing}</Text>
              </>
            ) : (
              <>
                <Ionicons name="lock-closed" size={18} color="#ffffff" />
                <Text style={styles.submitButtonText}>{t.getQuote}</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
    gap: 20,
  },
  section: {
    gap: 12,
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  metalGrid: {
    flexDirection: 'row',
    gap: 10,
  },
  metalCard: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignItems: 'center',
    gap: 6,
  },
  metalIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metalDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
  },
  metalSymbol: {
    fontSize: 12,
    fontWeight: '700',
  },
  metalPrice: {
    fontSize: 10,
  },
  paymentGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  paymentCard: {
    width: '31%',
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    gap: 4,
  },
  paymentIconBg: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentIcon: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: '700',
  },
  paymentSymbol: {
    fontSize: 11,
    fontWeight: '600',
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 4,
  },
  balanceLabel: {
    fontSize: 13,
  },
  balanceValue: {
    fontSize: 13,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    paddingLeft: 16,
    paddingRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 18,
    fontWeight: '600',
    paddingVertical: 14,
  },
  maxButton: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  maxButtonText: {
    fontSize: 12,
    fontWeight: '700',
  },
  errorText: {
    fontSize: 12,
    color: '#ef4444',
    fontWeight: '500',
  },
  arrowContainer: {
    alignItems: 'center',
    marginVertical: -8,
  },
  arrowCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  receiveCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    gap: 14,
  },
  receiveIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  receiveDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
  },
  receiveInfo: {
    flex: 1,
  },
  receiveAmountRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 6,
  },
  receiveAmount: {
    fontSize: 22,
    fontWeight: '700',
  },
  receiveSymbol: {
    fontSize: 16,
    fontWeight: '500',
  },
  receivePrice: {
    fontSize: 12,
    marginTop: 2,
  },
  feeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  feeLabel: {
    fontSize: 13,
  },
  feeValue: {
    fontSize: 13,
    fontWeight: '600',
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 16,
    borderTopWidth: 1,
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 12,
    backgroundColor: '#10b981',
  },
  submitButtonDisabled: {
    backgroundColor: '#64748b',
    opacity: 0.5,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
});
