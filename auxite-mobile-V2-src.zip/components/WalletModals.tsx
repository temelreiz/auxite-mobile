// components/WalletModals.tsx
// Withdraw, Receive, Send Modals

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  ScrollView,
  TextInput,
  useColorScheme,
  Alert,
  ActivityIndicator,
  Share,
  Clipboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useStore } from '@/stores/useStore';

// ============================================
// TYPES
// ============================================
type WithdrawCrypto = 'USDT' | 'BTC' | 'ETH' | 'XRP' | 'SOL';

interface CryptoInfo {
  name: string;
  icon: string;
  color: string;
  network: string;
  minWithdraw: number;
  fee: number;
}

// ============================================
// CRYPTO DATA
// ============================================
const WITHDRAW_CRYPTOS: Record<WithdrawCrypto, CryptoInfo> = {
  USDT: { name: 'Tether', icon: '₮', color: '#26A17B', network: 'ERC-20 / TRC-20', minWithdraw: 10, fee: 1 },
  BTC: { name: 'Bitcoin', icon: '₿', color: '#F7931A', network: 'Bitcoin', minWithdraw: 0.0005, fee: 0.0001 },
  ETH: { name: 'Ethereum', icon: 'Ξ', color: '#627EEA', network: 'ERC-20', minWithdraw: 0.01, fee: 0.001 },
  XRP: { name: 'Ripple', icon: '✕', color: '#23292F', network: 'XRP Ledger', minWithdraw: 1, fee: 0.1 },
  SOL: { name: 'Solana', icon: '◎', color: '#9945FF', network: 'Solana', minWithdraw: 0.1, fee: 0.01 },
};

// Supported tokens for receive/send
const SUPPORTED_TOKENS = [
  { symbol: 'AUXG', name: 'Gold', color: '#EAB308' },
  { symbol: 'AUXS', name: 'Silver', color: '#94A3B8' },
  { symbol: 'AUXPT', name: 'Platinum', color: '#CBD5E1' },
  { symbol: 'AUXPD', name: 'Palladium', color: '#64748B' },
  { symbol: 'ETH', name: 'Ethereum', color: '#627EEA' },
];

// ============================================
// TRANSLATIONS
// ============================================
const translations: Record<string, Record<string, string>> = {
  tr: {
    // Withdraw
    withdraw: 'Para Çek',
    withdrawSubtitle: 'AUXM\'i kripto olarak çekin',
    withdrawableBalance: 'Çekilebilir Bakiye',
    bonusLocked: 'Bonus (çekilemez)',
    auxmAmount: 'Çekilecek AUXM Miktarı',
    selectCrypto: 'Kripto Seçin',
    walletAddress: 'Cüzdan Adresi',
    network: 'Ağ',
    youWillReceive: 'Alacağınız',
    networkFee: 'Ağ Ücreti',
    netReceive: 'Net Alacak',
    insufficientBalance: 'Yetersiz AUXM bakiyesi',
    minimum: 'Minimum çekim',
    verifyAddress: 'Adresi kontrol edin. İşlem geri alınamaz.',
    continue: 'Devam Et',
    processing: 'İşleniyor...',
    confirmWithdrawal: 'Çekimi Onayla',
    withdrawalSuccess: 'Çekim Başlatıldı!',
    txComplete: 'İşlem 10-30 dakika içinde tamamlanacak',
    close: 'Kapat',
    destinationTag: 'Destination Tag',
    max: 'MAX',
    // Receive
    receive: 'Token Al',
    receiveSubtitle: 'Bu adresi paylaşarak token alabilirsiniz',
    yourAddress: 'Cüzdan Adresiniz',
    copy: 'Kopyala',
    copied: 'Kopyalandı!',
    share: 'Paylaş',
    supportedTokens: 'Desteklenen Tokenlar',
    warning: 'Sadece desteklenen tokenları bu adrese gönderin.',
    selectNetwork: 'Ağ Seçin',
    // Send
    send: 'Gönder',
    sendSubtitle: 'Token gönderin',
    selectToken: 'Token Seç',
    recipientAddress: 'Alıcı Adresi',
    amount: 'Miktar',
    balance: 'Bakiye',
    sendToken: 'Gönder',
    confirmSend: 'Gönderimi Onayla',
    sendSuccess: 'Gönderim Başarılı!',
    invalidAddress: 'Geçersiz adres',
  },
  en: {
    // Withdraw
    withdraw: 'Withdraw',
    withdrawSubtitle: 'Withdraw AUXM as crypto',
    withdrawableBalance: 'Withdrawable Balance',
    bonusLocked: 'Bonus (locked)',
    auxmAmount: 'AUXM Amount to Withdraw',
    selectCrypto: 'Select Crypto',
    walletAddress: 'Wallet Address',
    network: 'Network',
    youWillReceive: 'You will receive',
    networkFee: 'Network Fee',
    netReceive: 'Net Receive',
    insufficientBalance: 'Insufficient AUXM balance',
    minimum: 'Minimum',
    verifyAddress: 'Verify address. This cannot be reversed.',
    continue: 'Continue',
    processing: 'Processing...',
    confirmWithdrawal: 'Confirm Withdrawal',
    withdrawalSuccess: 'Withdrawal Started!',
    txComplete: 'Transaction will complete in 10-30 minutes',
    close: 'Close',
    destinationTag: 'Destination Tag',
    max: 'MAX',
    // Receive
    receive: 'Receive',
    receiveSubtitle: 'Share this address to receive tokens',
    yourAddress: 'Your Wallet Address',
    copy: 'Copy',
    copied: 'Copied!',
    share: 'Share',
    supportedTokens: 'Supported Tokens',
    warning: 'Only send supported tokens to this address.',
    selectNetwork: 'Select Network',
    // Send
    send: 'Send',
    sendSubtitle: 'Send tokens',
    selectToken: 'Select Token',
    recipientAddress: 'Recipient Address',
    amount: 'Amount',
    balance: 'Balance',
    sendToken: 'Send',
    confirmSend: 'Confirm Send',
    sendSuccess: 'Send Successful!',
    invalidAddress: 'Invalid address',
  },
};

// ============================================
// 1. WITHDRAW MODAL
// ============================================
interface WithdrawModalProps {
  visible: boolean;
  onClose: () => void;
}

export function WithdrawModal({ visible, onClose }: WithdrawModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  // States
  const [step, setStep] = useState<'select' | 'confirm' | 'success'>('select');
  const [selectedCrypto, setSelectedCrypto] = useState<WithdrawCrypto>('USDT');
  const [auxmAmount, setAuxmAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [xrpMemo, setXrpMemo] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Simulated balances
  const auxmBalance = 5000;
  const bonusAuxm = 250;

  // Crypto prices (simulated)
  const cryptoPrices: Record<WithdrawCrypto, number> = {
    USDT: 1, BTC: 105000, ETH: 3800, XRP: 2.35, SOL: 220,
  };

  // Reset on open
  useEffect(() => {
    if (visible) {
      setStep('select');
      setSelectedCrypto('USDT');
      setAuxmAmount('');
      setWithdrawAddress('');
      setXrpMemo('');
    }
  }, [visible]);

  const crypto = WITHDRAW_CRYPTOS[selectedCrypto];
  const auxmAmountNum = parseFloat(auxmAmount) || 0;
  const cryptoPrice = cryptoPrices[selectedCrypto];
  
  const receiveAmount = auxmAmountNum / cryptoPrice;
  const netReceiveAmount = Math.max(0, receiveAmount - crypto.fee);

  const canAfford = auxmAmountNum <= auxmBalance && auxmAmountNum > 0;
  const meetsMinimum = receiveAmount >= crypto.minWithdraw;
  const hasValidAddress = withdrawAddress.length > 10;
  const hasXrpMemo = selectedCrypto !== 'XRP' || xrpMemo.length > 0;

  const handleMaxClick = () => setAuxmAmount(auxmBalance.toFixed(2));

  const handleContinue = () => {
    if (canAfford && meetsMinimum && hasValidAddress && hasXrpMemo) {
      setStep('confirm');
    }
  };

  const handleWithdraw = async () => {
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 2000));
    setIsProcessing(false);
    setStep('success');
    setTimeout(() => onClose(), 3000);
  };

  // Success View
  if (step === 'success') {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
        <View style={styles.modalOverlay}>
          <View style={[styles.successContainer, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={[styles.successIcon, { backgroundColor: '#10b98120' }]}>
              <Ionicons name="checkmark-circle" size={64} color="#10b981" />
            </View>
            <Text style={[styles.successTitle, { color: '#10b981' }]}>{t.withdrawalSuccess}</Text>
            <Text style={[styles.successDetail, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {netReceiveAmount.toFixed(6)} {selectedCrypto}
            </Text>
            <Text style={[styles.successSubtext, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.txComplete}</Text>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff', maxHeight: '90%' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.withdraw}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.withdrawSubtitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {step === 'select' ? (
              <>
                {/* Balance Card */}
                <View style={[styles.balanceCard, { backgroundColor: '#ef444415', borderColor: '#ef444430' }]}>
                  <View style={styles.balanceRow}>
                    <Text style={[styles.balanceLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.withdrawableBalance}</Text>
                    <Text style={[styles.balanceValue, { color: '#ef4444' }]}>{auxmBalance.toLocaleString()} AUXM</Text>
                  </View>
                  {bonusAuxm > 0 && (
                    <View style={styles.balanceRow}>
                      <Text style={[styles.bonusLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.bonusLocked}</Text>
                      <Text style={[styles.bonusValue, { color: '#8b5cf6' }]}>🔒 {bonusAuxm} AUXM</Text>
                    </View>
                  )}
                </View>

                {/* AUXM Amount Input */}
                <View style={styles.section}>
                  <View style={styles.inputHeader}>
                    <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.auxmAmount}</Text>
                    <TouchableOpacity onPress={handleMaxClick}>
                      <Text style={styles.maxButton}>{t.max}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={[styles.inputContainer, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
                    <TextInput
                      style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                      value={auxmAmount}
                      onChangeText={setAuxmAmount}
                      placeholder="0.00"
                      placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                      keyboardType="decimal-pad"
                    />
                    <Text style={[styles.inputSuffix, { color: isDark ? '#94a3b8' : '#64748b' }]}>AUXM</Text>
                  </View>
                </View>

                {/* Crypto Selection */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectCrypto}</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {(Object.keys(WITHDRAW_CRYPTOS) as WithdrawCrypto[]).map((key) => {
                      const c = WITHDRAW_CRYPTOS[key];
                      const isSelected = selectedCrypto === key;
                      return (
                        <TouchableOpacity
                          key={key}
                          style={[
                            styles.cryptoCard,
                            { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: isSelected ? '#ef4444' : (isDark ? '#334155' : '#e2e8f0') },
                            isSelected && { borderWidth: 2 }
                          ]}
                          onPress={() => setSelectedCrypto(key)}
                        >
                          <View style={[styles.cryptoIcon, { backgroundColor: c.color + '20' }]}>
                            <Text style={[styles.cryptoIconText, { color: c.color }]}>{c.icon}</Text>
                          </View>
                          <Text style={[styles.cryptoSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{key}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                </View>

                {/* Address Input */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{selectedCrypto} {t.walletAddress}</Text>
                  <TextInput
                    style={[styles.addressInput, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', color: isDark ? '#fff' : '#0f172a' }]}
                    value={withdrawAddress}
                    onChangeText={setWithdrawAddress}
                    placeholder={selectedCrypto === 'BTC' ? 'bc1q...' : selectedCrypto === 'XRP' ? 'r...' : '0x...'}
                    placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                    autoCapitalize="none"
                  />
                  <Text style={[styles.networkText, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.network}: {crypto.network}</Text>
                </View>

                {/* XRP Memo */}
                {selectedCrypto === 'XRP' && (
                  <View style={styles.section}>
                    <Text style={[styles.sectionLabel, { color: '#f59e0b' }]}>⚠️ {t.destinationTag} *</Text>
                    <TextInput
                      style={[styles.addressInput, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', color: isDark ? '#fff' : '#0f172a' }]}
                      value={xrpMemo}
                      onChangeText={setXrpMemo}
                      placeholder="123456789"
                      placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                      keyboardType="number-pad"
                    />
                  </View>
                )}

                {/* Preview */}
                {auxmAmountNum > 0 && (
                  <View style={[styles.previewCard, { backgroundColor: '#ef444410', borderColor: '#ef444430' }]}>
                    <View style={styles.previewRow}>
                      <Text style={[styles.previewLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.youWillReceive}</Text>
                      <Text style={[styles.previewValue, { color: isDark ? '#fff' : '#0f172a' }]}>{receiveAmount.toFixed(6)} {selectedCrypto}</Text>
                    </View>
                    <View style={styles.previewRow}>
                      <Text style={[styles.previewLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.networkFee}</Text>
                      <Text style={[styles.previewValue, { color: isDark ? '#94a3b8' : '#64748b' }]}>-{crypto.fee} {selectedCrypto}</Text>
                    </View>
                    <View style={[styles.divider, { backgroundColor: '#ef444430' }]} />
                    <View style={styles.previewRow}>
                      <Text style={[styles.netLabel, { color: '#ef4444' }]}>{t.netReceive}</Text>
                      <Text style={[styles.netValue, { color: '#ef4444' }]}>{netReceiveAmount.toFixed(6)} {selectedCrypto}</Text>
                    </View>
                  </View>
                )}

                {/* Warnings */}
                {!canAfford && auxmAmountNum > 0 && (
                  <View style={styles.warningCard}>
                    <Ionicons name="warning" size={16} color="#ef4444" />
                    <Text style={styles.warningText}>{t.insufficientBalance}</Text>
                  </View>
                )}
                {!meetsMinimum && auxmAmountNum > 0 && canAfford && (
                  <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
                    <Ionicons name="warning" size={16} color="#f59e0b" />
                    <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.minimum}: {crypto.minWithdraw} {selectedCrypto}</Text>
                  </View>
                )}
              </>
            ) : (
              /* Confirm Step */
              <>
                <View style={[styles.confirmCard, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>AUXM</Text>
                    <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{auxmAmountNum.toFixed(2)}</Text>
                  </View>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectCrypto}</Text>
                    <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{selectedCrypto}</Text>
                  </View>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.walletAddress}</Text>
                    <Text style={[styles.confirmAddress, { color: isDark ? '#fff' : '#0f172a' }]}>
                      {withdrawAddress.slice(0, 8)}...{withdrawAddress.slice(-6)}
                    </Text>
                  </View>
                  <View style={[styles.divider, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]} />
                  <View style={styles.confirmRow}>
                    <Text style={[styles.netLabel, { color: '#ef4444' }]}>{t.netReceive}</Text>
                    <Text style={[styles.netValue, { color: '#ef4444' }]}>{netReceiveAmount.toFixed(6)} {selectedCrypto}</Text>
                  </View>
                </View>

                <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
                  <Ionicons name="warning" size={16} color="#f59e0b" />
                  <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.verifyAddress}</Text>
                </View>
              </>
            )}

            {/* Action Button */}
            <TouchableOpacity
              style={[styles.actionButton, (!canAfford || !meetsMinimum || !hasValidAddress || !hasXrpMemo || isProcessing) && styles.actionButtonDisabled]}
              onPress={step === 'select' ? handleContinue : handleWithdraw}
              disabled={!canAfford || !meetsMinimum || !hasValidAddress || !hasXrpMemo || isProcessing}
            >
              <LinearGradient
                colors={['#ef4444', '#f97316']}
                style={styles.actionButtonGradient}
              >
                {isProcessing ? (
                  <>
                    <ActivityIndicator size="small" color="#fff" />
                    <Text style={styles.actionButtonText}>{t.processing}</Text>
                  </>
                ) : (
                  <Text style={styles.actionButtonText}>
                    {step === 'select' ? t.continue : t.confirmWithdrawal}
                  </Text>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <View style={{ height: 20 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 2. RECEIVE MODAL
// ============================================
interface ReceiveModalProps {
  visible: boolean;
  onClose: () => void;
  walletAddress?: string;
}

export function ReceiveModal({ visible, onClose, walletAddress }: ReceiveModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  const [copied, setCopied] = useState(false);
  const [selectedNetwork, setSelectedNetwork] = useState<'ETH' | 'BASE'>('ETH');

  const address = walletAddress || '0xe6df1234567890abcdef1234567890abcdef3ba3';

  const handleCopy = () => {
    Clipboard.setString(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `My Auxite Wallet Address: ${address}`,
      });
    } catch {
      handleCopy();
    }
  };

  const networks = [
    { id: 'ETH' as const, name: 'Ethereum', color: '#627EEA' },
    { id: 'BASE' as const, name: 'Base', color: '#0052FF' },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.receive}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.receiveSubtitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Network Selection */}
            <View style={styles.networkContainer}>
              {networks.map((network) => (
                <TouchableOpacity
                  key={network.id}
                  style={[
                    styles.networkOption,
                    { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: selectedNetwork === network.id ? network.color : (isDark ? '#334155' : '#e2e8f0') },
                    selectedNetwork === network.id && { borderWidth: 2 }
                  ]}
                  onPress={() => setSelectedNetwork(network.id)}
                >
                  <View style={[styles.networkDot, { backgroundColor: network.color }]} />
                  <Text style={[styles.networkName, { color: isDark ? '#fff' : '#0f172a' }]}>{network.name}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* QR Code Placeholder */}
            <View style={styles.qrContainer}>
              <View style={styles.qrPlaceholder}>
                <Ionicons name="qr-code" size={140} color="#94a3b8" />
              </View>
            </View>

            {/* Network Badge */}
            <View style={styles.networkBadgeContainer}>
              <View style={[styles.networkBadge, { backgroundColor: networks.find(n => n.id === selectedNetwork)?.color }]}>
                <Text style={styles.networkBadgeText}>
                  {selectedNetwork === 'ETH' ? 'Ethereum Mainnet' : 'Base Network'}
                </Text>
              </View>
            </View>

            {/* Address */}
            <View style={[styles.addressCard, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
              <View style={styles.addressHeader}>
                <Text style={[styles.addressLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.yourAddress}</Text>
                <TouchableOpacity onPress={handleCopy}>
                  <Text style={[styles.copyButton, { color: copied ? '#10b981' : '#10b981' }]}>
                    {copied ? `✓ ${t.copied}` : t.copy}
                  </Text>
                </TouchableOpacity>
              </View>
              <Text style={[styles.addressText, { color: isDark ? '#fff' : '#0f172a' }]} selectable>
                {address}
              </Text>
            </View>

            {/* Supported Tokens */}
            <View style={[styles.tokensCard, { backgroundColor: isDark ? '#0f172a50' : '#f8fafc' }]}>
              <Text style={[styles.tokensLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.supportedTokens}</Text>
              <View style={styles.tokensList}>
                {SUPPORTED_TOKENS.map((token) => (
                  <View key={token.symbol} style={[styles.tokenBadge, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]}>
                    <Text style={[styles.tokenBadgeText, { color: isDark ? '#e2e8f0' : '#334155' }]}>{token.symbol}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Warning */}
            <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
              <Ionicons name="warning" size={16} color="#f59e0b" />
              <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.warning}</Text>
            </View>

            {/* Action Buttons */}
            <View style={styles.receiveActions}>
              <TouchableOpacity
                style={[styles.receiveActionBtn, { backgroundColor: isDark ? '#0f172a' : '#e2e8f0', flex: 1 }]}
                onPress={handleCopy}
              >
                <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={20} color={copied ? '#10b981' : (isDark ? '#fff' : '#0f172a')} />
                <Text style={[styles.receiveActionText, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {copied ? t.copied.replace('!', '') : t.copy}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.receiveActionBtn, { backgroundColor: '#8b5cf6', flex: 1 }]}
                onPress={handleShare}
              >
                <Ionicons name="share-outline" size={20} color="#fff" />
                <Text style={[styles.receiveActionText, { color: '#fff' }]}>{t.share}</Text>
              </TouchableOpacity>
            </View>

            <View style={{ height: 20 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 3. SEND MODAL
// ============================================
interface SendModalProps {
  visible: boolean;
  onClose: () => void;
}

export function SendModal({ visible, onClose }: SendModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  const [selectedToken, setSelectedToken] = useState(SUPPORTED_TOKENS[0]);
  const [recipientAddress, setRecipientAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<'input' | 'confirm' | 'success'>('input');
  const [isProcessing, setIsProcessing] = useState(false);

  // Simulated balances
  const balances: Record<string, number> = {
    AUXG: 125.5, AUXS: 2500, AUXPT: 15.75, AUXPD: 8.25, ETH: 1.5234,
  };

  useEffect(() => {
    if (visible) {
      setStep('input');
      setSelectedToken(SUPPORTED_TOKENS[0]);
      setRecipientAddress('');
      setAmount('');
    }
  }, [visible]);

  const amountNum = parseFloat(amount) || 0;
  const balance = balances[selectedToken.symbol] || 0;
  const canAfford = amountNum > 0 && amountNum <= balance;
  const hasValidAddress = recipientAddress.length > 10;

  const handleMaxClick = () => setAmount(balance.toString());

  const handleContinue = () => {
    if (canAfford && hasValidAddress) {
      setStep('confirm');
    }
  };

  const handleSend = async () => {
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 2000));
    setIsProcessing(false);
    setStep('success');
    setTimeout(() => onClose(), 3000);
  };

  // Success View
  if (step === 'success') {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
        <View style={styles.modalOverlay}>
          <View style={[styles.successContainer, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={[styles.successIcon, { backgroundColor: '#10b98120' }]}>
              <Ionicons name="checkmark-circle" size={64} color="#10b981" />
            </View>
            <Text style={[styles.successTitle, { color: '#10b981' }]}>{t.sendSuccess}</Text>
            <Text style={[styles.successDetail, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {amountNum} {selectedToken.symbol}
            </Text>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.send}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.sendSubtitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {step === 'input' ? (
              <>
                {/* Token Selection */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectToken}</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {SUPPORTED_TOKENS.map((token) => {
                      const isSelected = selectedToken.symbol === token.symbol;
                      return (
                        <TouchableOpacity
                          key={token.symbol}
                          style={[
                            styles.cryptoCard,
                            { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: isSelected ? '#8b5cf6' : (isDark ? '#334155' : '#e2e8f0') },
                            isSelected && { borderWidth: 2 }
                          ]}
                          onPress={() => setSelectedToken(token)}
                        >
                          <View style={[styles.cryptoIcon, { backgroundColor: token.color + '20' }]}>
                            <Text style={[styles.cryptoIconText, { color: token.color }]}>{token.symbol[0]}</Text>
                          </View>
                          <Text style={[styles.cryptoSymbol, { color: isDark ? '#fff' : '#0f172a' }]}>{token.symbol}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                </View>

                {/* Recipient Address */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.recipientAddress}</Text>
                  <TextInput
                    style={[styles.addressInput, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', color: isDark ? '#fff' : '#0f172a' }]}
                    value={recipientAddress}
                    onChangeText={setRecipientAddress}
                    placeholder="0x..."
                    placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                    autoCapitalize="none"
                  />
                </View>

                {/* Amount */}
                <View style={styles.section}>
                  <View style={styles.inputHeader}>
                    <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.amount}</Text>
                    <TouchableOpacity onPress={handleMaxClick}>
                      <Text style={styles.maxButton}>{t.max}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={[styles.inputContainer, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
                    <TextInput
                      style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                      value={amount}
                      onChangeText={setAmount}
                      placeholder="0.00"
                      placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                      keyboardType="decimal-pad"
                    />
                    <Text style={[styles.inputSuffix, { color: isDark ? '#94a3b8' : '#64748b' }]}>{selectedToken.symbol}</Text>
                  </View>
                  <Text style={[styles.balanceText, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                    {t.balance}: {balance.toFixed(4)} {selectedToken.symbol}
                  </Text>
                </View>

                {/* Warnings */}
                {!canAfford && amountNum > 0 && (
                  <View style={styles.warningCard}>
                    <Ionicons name="warning" size={16} color="#ef4444" />
                    <Text style={styles.warningText}>{t.insufficientBalance}</Text>
                  </View>
                )}
              </>
            ) : (
              /* Confirm Step */
              <View style={[styles.confirmCard, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
                <View style={styles.confirmRow}>
                  <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectToken}</Text>
                  <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{selectedToken.symbol}</Text>
                </View>
                <View style={styles.confirmRow}>
                  <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.amount}</Text>
                  <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{amountNum}</Text>
                </View>
                <View style={styles.confirmRow}>
                  <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.recipientAddress}</Text>
                  <Text style={[styles.confirmAddress, { color: isDark ? '#fff' : '#0f172a' }]}>
                    {recipientAddress.slice(0, 8)}...{recipientAddress.slice(-6)}
                  </Text>
                </View>
              </View>
            )}

            {/* Action Button */}
            <TouchableOpacity
              style={[styles.actionButton, (!canAfford || !hasValidAddress || isProcessing) && styles.actionButtonDisabled]}
              onPress={step === 'input' ? handleContinue : handleSend}
              disabled={!canAfford || !hasValidAddress || isProcessing}
            >
              <LinearGradient
                colors={['#8b5cf6', '#7c3aed']}
                style={styles.actionButtonGradient}
              >
                {isProcessing ? (
                  <>
                    <ActivityIndicator size="small" color="#fff" />
                    <Text style={styles.actionButtonText}>{t.processing}</Text>
                  </>
                ) : (
                  <Text style={styles.actionButtonText}>
                    {step === 'input' ? t.continue : t.confirmSend}
                  </Text>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <View style={{ height: 20 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(148,163,184,0.2)' },
  modalTitle: { fontSize: 18, fontWeight: '700' },
  modalSubtitle: { fontSize: 12, marginTop: 2 },
  closeButton: { padding: 4 },

  // Success
  successContainer: { margin: 20, padding: 32, borderRadius: 24, alignItems: 'center' },
  successIcon: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  successTitle: { fontSize: 20, fontWeight: '700', marginBottom: 8 },
  successDetail: { fontSize: 16, marginBottom: 4 },
  successSubtext: { fontSize: 12 },

  // Balance Card
  balanceCard: { marginHorizontal: 16, marginTop: 16, padding: 14, borderRadius: 14, borderWidth: 1 },
  balanceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  balanceLabel: { fontSize: 12 },
  balanceValue: { fontSize: 16, fontWeight: '700' },
  bonusLabel: { fontSize: 11 },
  bonusValue: { fontSize: 12, fontWeight: '600' },

  // Section
  section: { paddingHorizontal: 16, marginTop: 16 },
  sectionLabel: { fontSize: 12, marginBottom: 8 },
  inputHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  maxButton: { fontSize: 12, fontWeight: '600', color: '#ef4444' },

  // Input
  inputContainer: { flexDirection: 'row', alignItems: 'center', borderRadius: 12, paddingHorizontal: 14 },
  input: { flex: 1, fontSize: 18, fontWeight: '600', paddingVertical: 14 },
  inputSuffix: { fontSize: 14, fontWeight: '500' },
  addressInput: { borderRadius: 12, padding: 14, fontSize: 13, fontFamily: 'monospace' },
  networkText: { fontSize: 10, marginTop: 4 },
  balanceText: { fontSize: 11, marginTop: 6 },

  // Crypto Selection
  cryptoCard: { alignItems: 'center', padding: 12, borderRadius: 12, borderWidth: 1, marginRight: 10, minWidth: 70 },
  cryptoIcon: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  cryptoIconText: { fontSize: 16, fontWeight: '700' },
  cryptoSymbol: { fontSize: 11, fontWeight: '600' },

  // Preview/Confirm Card
  previewCard: { marginHorizontal: 16, marginTop: 16, padding: 14, borderRadius: 14, borderWidth: 1 },
  confirmCard: { marginHorizontal: 16, marginTop: 16, padding: 14, borderRadius: 14 },
  previewRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  confirmRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  previewLabel: { fontSize: 12 },
  previewValue: { fontSize: 14, fontWeight: '600' },
  confirmLabel: { fontSize: 12 },
  confirmValue: { fontSize: 14, fontWeight: '600' },
  confirmAddress: { fontSize: 11, fontFamily: 'monospace' },
  divider: { height: 1, marginVertical: 8 },
  netLabel: { fontSize: 13, fontWeight: '600' },
  netValue: { fontSize: 16, fontWeight: '700' },

  // Warning
  warningCard: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 16, marginTop: 12, padding: 12, borderRadius: 12, backgroundColor: '#ef444415', borderWidth: 1, borderColor: '#ef444430' },
  warningText: { fontSize: 12, color: '#ef4444', flex: 1 },

  // Action Button
  actionButton: { marginHorizontal: 16, marginTop: 20, borderRadius: 14, overflow: 'hidden' },
  actionButtonDisabled: { opacity: 0.5 },
  actionButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, gap: 8 },
  actionButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },

  // Receive specific
  networkContainer: { flexDirection: 'row', paddingHorizontal: 16, marginTop: 16, gap: 10 },
  networkOption: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 12, borderRadius: 12, borderWidth: 1, gap: 8 },
  networkDot: { width: 10, height: 10, borderRadius: 5 },
  networkName: { fontSize: 13, fontWeight: '500' },
  qrContainer: { alignItems: 'center', marginTop: 20, marginBottom: 12 },
  qrPlaceholder: { width: 180, height: 180, backgroundColor: '#fff', borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  networkBadgeContainer: { alignItems: 'center', marginBottom: 16 },
  networkBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  networkBadgeText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  addressCard: { marginHorizontal: 16, padding: 14, borderRadius: 14 },
  addressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  addressLabel: { fontSize: 11 },
  copyButton: { fontSize: 11, fontWeight: '600' },
  addressText: { fontSize: 11, fontFamily: 'monospace', lineHeight: 18 },
  tokensCard: { marginHorizontal: 16, marginTop: 12, padding: 14, borderRadius: 14 },
  tokensLabel: { fontSize: 11, marginBottom: 8 },
  tokensList: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  tokenBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6 },
  tokenBadgeText: { fontSize: 11, fontWeight: '500' },
  receiveActions: { flexDirection: 'row', gap: 12, marginHorizontal: 16, marginTop: 16 },
  receiveActionBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 14, borderRadius: 12, gap: 8 },
  receiveActionText: { fontSize: 14, fontWeight: '600' },
});

export default { WithdrawModal, ReceiveModal, SendModal };
