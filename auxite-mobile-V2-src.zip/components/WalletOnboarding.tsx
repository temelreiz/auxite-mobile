// components/WalletOnboarding.tsx
// React Native versiyonu - Auxite Wallet Onboarding

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  ActivityIndicator,
  Dimensions,
  Platform,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import * as Crypto from 'expo-crypto';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// ============================================
// RENK PALETİ
// ============================================
const colors = {
  background: '#0F172A',
  surface: '#1E293B',
  surfaceLight: '#334155',
  primary: '#10B981',
  primaryDark: '#059669',
  text: '#FFFFFF',
  textSecondary: '#94A3B8',
  textMuted: '#64748B',
  border: '#334155',
  error: '#EF4444',
  warning: '#F59E0B',
  warningBg: 'rgba(245, 158, 11, 0.1)',
};

const { width } = Dimensions.get('window');

// ============================================
// BIP39 WORD LIST (2048 kelime)
// ============================================
const BIP39_WORDLIST = 'abandon,ability,able,about,above,absent,absorb,abstract,absurd,abuse,access,accident,account,accuse,achieve,acid,acoustic,acquire,across,act,action,actor,actress,actual,adapt,add,addict,address,adjust,admit,adult,advance,advice,aerobic,affair,afford,afraid,again,age,agent,agree,ahead,aim,air,airport,aisle,alarm,album,alcohol,alert,alien,all,alley,allow,almost,alone,alpha,already,also,alter,always,amateur,amazing,among,amount,amused,analyst,anchor,ancient,anger,angle,angry,animal,ankle,announce,annual,another,answer,antenna,antique,anxiety,any,apart,apology,appear,apple,approve,april,arch,arctic,area,arena,argue,arm,armed,armor,army,around,arrange,arrest,arrive,arrow,art,artefact,artist,artwork,ask,aspect,assault,asset,assist,assume,asthma,athlete,atom,attack,attend,attitude,attract,auction,audit,august,aunt,author,auto,autumn,average,avocado,avoid,awake,aware,away,awesome,awful,awkward,axis,baby,bachelor,bacon,badge,bag,balance,balcony,ball,bamboo,banana,banner,bar,barely,bargain,barrel,base,basic,basket,battle,beach,bean,beauty,because,become,beef,before,begin,behave,behind,believe,below,belt,bench,benefit,best,betray,better,between,beyond,bicycle,bid,bike,bind,biology,bird,birth,bitter,black,blade,blame,blanket,blast,bleak,bless,blind,blood,blossom,blouse,blue,blur,blush,board,boat,body,boil,bomb,bone,bonus,book,boost,border,boring,borrow,boss,bottom,bounce,box,boy,bracket,brain,brand,brass,brave,bread,breeze,brick,bridge,brief,bright,bring,brisk,broccoli,broken,bronze,broom,brother,brown,brush,bubble,buddy,budget,buffalo,build,bulb,bulk,bullet,bundle,bunker,burden,burger,burst,bus,business,busy,butter,buyer,buzz,cabbage,cabin,cable,cactus,cage,cake,call,calm,camera,camp,can,canal,cancel,candy,cannon,canoe,canvas,canyon,capable,capital,captain,car,carbon,card,cargo,carpet,carry,cart,case,cash,casino,castle,casual,cat,catalog,catch,category,cattle,caught,cause,caution,cave,ceiling,celery,cement,census,century,cereal,certain,chair,chalk,champion,change,chaos,chapter,charge,chase,chat,cheap,check,cheese,chef,cherry,chest,chicken,chief,child,chimney,choice,choose,chronic,chuckle,chunk,churn,cigar,cinnamon,circle,citizen,city,civil,claim,clap,clarify,claw,clay,clean,clerk,clever,click,client,cliff,climb,clinic,clip,clock,clog,close,cloth,cloud,clown,club,clump,cluster,clutch,coach,coast,coconut,code,coffee,coil,coin,collect,color,column,combine,come,comfort,comic,common,company,concert,conduct,confirm,congress,connect,consider,control,convince,cook,cool,copper,copy,coral,core,corn,correct,cost,cotton,couch,country,couple,course,cousin,cover,coyote,crack,cradle,craft,cram,crane,crash,crater,crawl,crazy,cream,credit,creek,crew,cricket,crime,crisp,critic,crop,cross,crouch,crowd,crucial,cruel,cruise,crumble,crunch,crush,cry,crystal,cube,culture,cup,cupboard,curious,current,curtain,curve,cushion,custom,cute,cycle,dad,damage,damp,dance,danger,daring,dash,daughter,dawn,day,deal,debate,debris,decade,december,decide,decline,decorate,decrease,deer,defense,define,defy,degree,delay,deliver,demand,demise,denial,dentist,deny,depart,depend,deposit,depth,deputy,derive,describe,desert,design,desk,despair,destroy,detail,detect,develop,device,devote,diagram,dial,diamond,diary,dice,diesel,diet,differ,digital,dignity,dilemma,dinner,dinosaur,direct,dirt,disagree,discover,disease,dish,dismiss,disorder,display,distance,divert,divide,divorce,dizzy,doctor,document,dog,doll,dolphin,domain,donate,donkey,donor,door,dose,double,dove,draft,dragon,drama,drastic,draw,dream,dress,drift,drill,drink,drip,drive,drop,drum,dry,duck,dumb,dune,during,dust,dutch,duty,dwarf,dynamic,eager,eagle,early,earn,earth,easily,east,easy,echo,ecology,economy,edge,edit,educate,effort,egg,eight,either,elbow,elder,electric,elegant,element,elephant,elevator,elite,else,embark,embody,embrace,emerge,emotion,employ,empower,empty,enable,enact,end,endless,endorse,enemy,energy,enforce,engage,engine,enhance,enjoy,enlist,enough,enrich,enroll,ensure,enter,entire,entry,envelope,episode,equal,equip,era,erase,erode,erosion,error,erupt,escape,essay,essence,estate,eternal,ethics,evidence,evil,evoke,evolve,exact,example,excess,exchange,excite,exclude,excuse,execute,exercise,exhaust,exhibit,exile,exist,exit,exotic,expand,expect,expire,explain,expose,express,extend,extra,eye,eyebrow,fabric,face,faculty,fade,faint,faith,fall,false,fame,family,famous,fan,fancy,fantasy,farm,fashion,fat,fatal,father,fatigue,fault,favorite,feature,february,federal,fee,feed,feel,female,fence,festival,fetch,fever,few,fiber,fiction,field,figure,file,film,filter,final,find,fine,finger,finish,fire,firm,first,fiscal,fish,fit,fitness,fix,flag,flame,flash,flat,flavor,flee,flight,flip,float,flock,floor,flower,fluid,flush,fly,foam,focus,fog,foil,fold,follow,food,foot,force,forest,forget,fork,fortune,forum,forward,fossil,foster,found,fox,fragile,frame,frequent,fresh,friend,fringe,frog,front,frost,frown,frozen,fruit,fuel,fun,funny,furnace,fury,future,gadget,gain,galaxy,gallery,game,gap,garage,garbage,garden,garlic,garment,gas,gasp,gate,gather,gauge,gaze,general,genius,genre,gentle,genuine,gesture,ghost,giant,gift,giggle,ginger,giraffe,girl,give,glad,glance,glare,glass,glide,glimpse,globe,gloom,glory,glove,glow,glue,goat,goddess,gold,good,goose,gorilla,gospel,gossip,govern,gown,grab,grace,grain,grant,grape,grass,gravity,great,green,grid,grief,grit,grocery,group,grow,grunt,guard,guess,guide,guilt,guitar,gun,gym,habit,hair,half,hammer,hamster,hand,happy,harbor,hard,harsh,harvest,hat,have,hawk,hazard,head,health,heart,heavy,hedgehog,height,hello,helmet,help,hen,hero,hidden,high,hill,hint,hip,hire,history,hobby,hockey,hold,hole,holiday,hollow,home,honey,hood,hope,horn,horror,horse,hospital,host,hotel,hour,hover,hub,huge,human,humble,humor,hundred,hungry,hunt,hurdle,hurry,hurt,husband,hybrid,ice,icon,idea,identify,idle,ignore,ill,illegal,illness,image,imitate,immense,immune,impact,impose,improve,impulse,inch,include,income,increase,index,indicate,indoor,industry,infant,inflict,inform,inhale,inherit,initial,inject,injury,inmate,inner,innocent,input,inquiry,insane,insect,inside,inspire,install,intact,interest,into,invest,invite,involve,iron,island,isolate,issue,item,ivory,jacket,jaguar,jar,jazz,jealous,jeans,jelly,jewel,job,join,joke,journey,joy,judge,juice,jump,jungle,junior,junk,just,kangaroo,keen,keep,ketchup,key,kick,kid,kidney,kind,kingdom,kiss,kit,kitchen,kite,kitten,kiwi,knee,knife,knock,know,lab,label,labor,ladder,lady,lake,lamp,language,laptop,large,later,latin,laugh,laundry,lava,law,lawn,lawsuit,layer,lazy,leader,leaf,learn,leave,lecture,left,leg,legal,legend,leisure,lemon,lend,length,lens,leopard,lesson,letter,level,liar,liberty,library,license,life,lift,light,like,limb,limit,link,lion,liquid,list,little,live,lizard,load,loan,lobster,local,lock,logic,lonely,long,loop,lottery,loud,lounge,love,loyal,lucky,luggage,lumber,lunar,lunch,luxury,lyrics,machine,mad,magic,magnet,maid,mail,main,major,make,mammal,man,manage,mandate,mango,mansion,manual,maple,marble,march,margin,marine,market,marriage,mask,mass,master,match,material,math,matrix,matter,maximum,maze,meadow,mean,measure,meat,mechanic,medal,media,melody,melt,member,memory,mention,menu,mercy,merge,merit,merry,mesh,message,metal,method,middle,midnight,milk,million,mimic,mind,minimum,minor,minute,miracle,mirror,misery,miss,mistake,mix,mixed,mixture,mobile,model,modify,mom,moment,monitor,monkey,monster,month,moon,moral,more,morning,mosquito,mother,motion,motor,mountain,mouse,move,movie,much,muffin,mule,multiply,muscle,museum,mushroom,music,must,mutual,myself,mystery,myth,naive,name,napkin,narrow,nasty,nation,nature,near,neck,need,negative,neglect,neither,nephew,nerve,nest,net,network,neutral,never,news,next,nice,night,noble,noise,nominee,noodle,normal,north,nose,notable,note,nothing,notice,novel,now,nuclear,number,nurse,nut,oak,obey,object,oblige,obscure,observe,obtain,obvious,occur,ocean,october,odor,off,offer,office,often,oil,okay,old,olive,olympic,omit,once,one,onion,online,only,open,opera,opinion,oppose,option,orange,orbit,orchard,order,ordinary,organ,orient,original,orphan,ostrich,other,outdoor,outer,output,outside,oval,oven,over,own,owner,oxygen,oyster,ozone,pact,paddle,page,pair,palace,palm,panda,panel,panic,panther,paper,parade,parent,park,parrot,party,pass,patch,path,patient,patrol,pattern,pause,pave,payment,peace,peanut,pear,peasant,pelican,pen,penalty,pencil,people,pepper,perfect,permit,person,pet,phone,photo,phrase,physical,piano,picnic,picture,piece,pig,pigeon,pill,pilot,pink,pioneer,pipe,pistol,pitch,pizza,place,planet,plastic,plate,play,please,pledge,pluck,plug,plunge,poem,poet,point,polar,pole,police,pond,pony,pool,popular,portion,position,possible,post,potato,pottery,poverty,powder,power,practice,praise,predict,prefer,prepare,present,pretty,prevent,price,pride,primary,print,priority,prison,private,prize,problem,process,produce,profit,program,project,promote,proof,property,prosper,protect,proud,provide,public,pudding,pull,pulp,pulse,pumpkin,punch,pupil,puppy,purchase,purity,purpose,purse,push,put,puzzle,pyramid,quality,quantum,quarter,question,quick,quit,quiz,quote,rabbit,raccoon,race,rack,radar,radio,rail,rain,raise,rally,ramp,ranch,random,range,rapid,rare,rate,rather,raven,raw,razor,ready,real,reason,rebel,rebuild,recall,receive,recipe,record,recycle,reduce,reflect,reform,refuse,region,regret,regular,reject,relax,release,relief,rely,remain,remember,remind,remove,render,renew,rent,reopen,repair,repeat,replace,report,require,rescue,resemble,resist,resource,response,result,retire,retreat,return,reunion,reveal,review,reward,rhythm,rib,ribbon,rice,rich,ride,ridge,rifle,right,rigid,ring,riot,ripple,risk,ritual,rival,river,road,roast,robot,robust,rocket,romance,roof,rookie,room,rose,rotate,rough,round,route,royal,rubber,rude,rug,rule,run,runway,rural,sad,saddle,sadness,safe,sail,salad,salmon,salon,salt,salute,same,sample,sand,satisfy,satoshi,sauce,sausage,save,say,scale,scan,scare,scatter,scene,scheme,school,science,scissors,scorpion,scout,scrap,screen,script,scrub,sea,search,season,seat,second,secret,section,security,seed,seek,segment,select,sell,seminar,senior,sense,sentence,series,service,session,settle,setup,seven,shadow,shaft,shallow,share,shed,shell,sheriff,shield,shift,shine,ship,shiver,shock,shoe,shoot,shop,short,shoulder,shove,shrimp,shrug,shuffle,shy,sibling,sick,side,siege,sight,sign,silent,silk,silly,silver,similar,simple,since,sing,siren,sister,situate,six,size,skate,sketch,ski,skill,skin,skirt,skull,slab,slam,sleep,slender,slice,slide,slight,slim,slogan,slot,slow,slush,small,smart,smile,smoke,smooth,snack,snake,snap,sniff,snow,soap,soccer,social,sock,soda,soft,solar,soldier,solid,solution,solve,someone,song,soon,sorry,sort,soul,sound,soup,source,south,space,spare,spatial,spawn,speak,special,speed,spell,spend,sphere,spice,spider,spike,spin,spirit,split,spoil,sponsor,spoon,sport,spot,spray,spread,spring,spy,square,squeeze,squirrel,stable,stadium,staff,stage,stairs,stamp,stand,start,state,stay,steak,steel,stem,step,stereo,stick,still,sting,stock,stomach,stone,stool,story,stove,strategy,street,strike,strong,struggle,student,stuff,stumble,style,subject,submit,subway,success,such,sudden,suffer,sugar,suggest,suit,summer,sun,sunny,sunset,super,supply,supreme,sure,surface,surge,surprise,surround,survey,suspect,sustain,swallow,swamp,swap,swarm,swear,sweet,swift,swim,swing,switch,sword,symbol,symptom,syrup,system,table,tackle,tag,tail,talent,talk,tank,tape,target,task,taste,tattoo,taxi,teach,team,tell,ten,tenant,tennis,tent,term,test,text,thank,that,theme,then,theory,there,they,thing,this,thought,three,thrive,throw,thumb,thunder,ticket,tide,tiger,tilt,timber,time,tiny,tip,tired,tissue,title,toast,tobacco,today,toddler,toe,together,toilet,token,tomato,tomorrow,tone,tongue,tonight,tool,tooth,top,topic,topple,torch,tornado,tortoise,toss,total,tourist,toward,tower,town,toy,track,trade,traffic,tragic,train,transfer,trap,trash,travel,tray,treat,tree,trend,trial,tribe,trick,trigger,trim,trip,trophy,trouble,truck,true,truly,trumpet,trust,truth,try,tube,tuition,tumble,tuna,tunnel,turkey,turn,turtle,twelve,twenty,twice,twin,twist,two,type,typical,ugly,umbrella,unable,unaware,uncle,uncover,under,undo,unfair,unfold,unhappy,uniform,unique,unit,universe,unknown,unlock,until,unusual,unveil,update,upgrade,uphold,upon,upper,upset,urban,urge,usage,use,used,useful,useless,usual,utility,vacant,vacuum,vague,valid,valley,valve,van,vanish,vapor,various,vast,vault,vehicle,velvet,vendor,venture,venue,verb,verify,version,very,vessel,veteran,viable,vibrant,vicious,victory,video,view,village,vintage,violin,virtual,virus,visa,visit,visual,vital,vivid,vocal,voice,void,volcano,volume,vote,voyage,wage,wagon,wait,walk,wall,walnut,want,warfare,warm,warrior,wash,wasp,waste,water,wave,way,wealth,weapon,wear,weasel,weather,web,wedding,weekend,weird,welcome,west,wet,whale,what,wheat,wheel,when,where,whip,whisper,wide,width,wife,wild,will,win,window,wine,wing,wink,winner,winter,wire,wisdom,wise,wish,witness,wolf,woman,wonder,wood,wool,word,work,world,worry,worth,wrap,wreck,wrestle,wrist,write,wrong,yard,year,yellow,you,young,youth,zebra,zero,zone,zoo'.split(',');

// ============================================
// ÇEVİRİLER
// ============================================
const translations: Record<string, Record<string, string>> = {
  tr: {
    welcomeTitle: "Auxite Wallet'a Hoş Geldiniz",
    welcomeSubtitle: "Fiziksel metallerle desteklenen dijital tokenleri alın ve satın. Gerçek zamanlı fiyatlar ve anlık işlemler.",
    createNewWallet: "Yeni Cüzdan Oluştur",
    importWallet: "Mevcut Cüzdanı İçe Aktar",
    seedPhraseTitle: "Kurtarma İfadeniz",
    seedPhraseWarning: "⚠️ Bu 12 kelimeyi güvenli bir yere yazın! Kimseyle paylaşmayın!",
    iWroteItDown: "Yazdım, Devam Et",
    verifyTitle: "Kurtarma İfadesini Doğrula",
    selectWord: "Kelime #",
    verifyError: "Yanlış kelime seçildi",
    setPinTitle: "Şifre Oluştur",
    setPinSubtitle: "En az 6 karakterli güvenlik şifrenizi belirleyin",
    confirmPinTitle: "Şifreyi Onayla",
    pinMismatch: "Şifreler eşleşmiyor",
    enterPinTitle: "Şifre Girin",
    wrongPin: "Yanlış şifre",
    forgotPin: "Şifremi Unuttum",
    securityTip: "Güvenlik İpucu",
    neverShare: "Kurtarma ifadenizi asla paylaşmayın",
    noScreenshot: "Ekran görüntüsü almayın",
    writeOnPaper: "Kağıda yazıp güvenli yerde saklayın",
    keysOnDevice: "Anahtarlarınız yalnızca cihazınızda saklanır",
    import: "İçe Aktar",
    reveal: "Kelimeleri Göster",
    hide: "Gizle",
    copy: "Kopyala",
    copied: "Kopyalandı!",
    continue: "Devam",
    back: "Geri",
    cancel: "İptal",
    invalidSeed: "Geçersiz kurtarma ifadesi",
    enterSeedPlaceholder: "Kurtarma ifadesini girin...",
    password: "Şifre",
    confirmPassword: "Şifreyi Onayla",
    passwordHint: "En az 6 karakter",
    unlock: "Kilidi Aç",
    logout: "Çıkış Yap",
    resetConfirm: "Cüzdanınızı sıfırlamak istediğinize emin misiniz? Seed phrase ile tekrar içe aktarmanız gerekecek.",
    enterSeedHint: "Kelimeleri boşluk ile ayırarak girin",
    unlockSubtitle: "Cüzdanınıza erişmek için şifre girin",
  },
  en: {
    welcomeTitle: "Welcome to Auxite Wallet",
    welcomeSubtitle: "Buy and sell digital tokens backed by physical metals. Real-time prices and instant transactions.",
    createNewWallet: "Create New Wallet",
    importWallet: "Import Existing Wallet",
    seedPhraseTitle: "Your Recovery Phrase",
    seedPhraseWarning: "⚠️ Write down these 12 words in a safe place! Never share them!",
    iWroteItDown: "I Wrote It Down, Continue",
    verifyTitle: "Verify Recovery Phrase",
    selectWord: "Word #",
    verifyError: "Wrong word selected",
    setPinTitle: "Create Password",
    setPinSubtitle: "Set your security password (min 6 characters)",
    confirmPinTitle: "Confirm Password",
    pinMismatch: "Passwords do not match",
    enterPinTitle: "Enter Password",
    wrongPin: "Wrong password",
    forgotPin: "Forgot Password",
    securityTip: "Security Tip",
    neverShare: "Never share your recovery phrase",
    noScreenshot: "Do not take screenshots",
    writeOnPaper: "Write on paper and store safely",
    keysOnDevice: "Your keys are stored only on your device",
    import: "Import",
    reveal: "Reveal Words",
    hide: "Hide",
    copy: "Copy",
    copied: "Copied!",
    continue: "Continue",
    back: "Back",
    cancel: "Cancel",
    invalidSeed: "Invalid recovery phrase",
    enterSeedPlaceholder: "Enter recovery phrase...",
    password: "Password",
    confirmPassword: "Confirm Password",
    passwordHint: "Minimum 6 characters",
    unlock: "Unlock",
    logout: "Log Out",
    resetConfirm: "Are you sure you want to reset? You will need to re-import with your seed phrase.",
    enterSeedHint: "Enter words separated by spaces",
    unlockSubtitle: "Enter password to access your wallet",
  },
};

// ============================================
// STORAGE KEYS
// ============================================
const STORAGE_KEYS = {
  HAS_WALLET: 'auxite_has_wallet',
  ENCRYPTED_SEED: 'auxite_encrypted_seed',
  PASSWORD_HASH: 'auxite_password_hash',
  WALLET_ADDRESS: 'auxite_wallet_address',
};

// ============================================
// CRYPTO UTILS
// ============================================
function generateSeedPhrase(): string[] {
  const words: string[] = [];
  const usedIndices = new Set<number>();
  while (words.length < 12) {
    const randomIndex = Math.floor(Math.random() * BIP39_WORDLIST.length);
    if (!usedIndices.has(randomIndex)) {
      usedIndices.add(randomIndex);
      words.push(BIP39_WORDLIST[randomIndex]);
    }
  }
  return words;
}

async function hashPassword(password: string): Promise<string> {
  const data = password + 'AUXITE_SALT_2024';
  const hash = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    data
  );
  return hash;
}

async function deriveAddressFromSeed(seedPhrase: string[]): Promise<string> {
  const seedString = seedPhrase.join(' ');
  const hash = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    seedString
  );
  return '0x' + hash.substring(0, 40);
}

function encryptSeed(seedPhrase: string[], _password: string): string {
  // Basit base64 - gerçek uygulamada AES kullanın
  const seedString = seedPhrase.join(',');
  return Buffer.from(seedString).toString('base64');
}

function decryptSeed(encryptedSeed: string, _password: string): string[] | null {
  try {
    const decoded = Buffer.from(encryptedSeed, 'base64').toString('utf-8');
    return decoded.split(',');
  } catch {
    return null;
  }
}

// ============================================
// TYPES
// ============================================
type WalletStep =
  | 'checking'
  | 'onboarding'
  | 'create'
  | 'verify'
  | 'password'
  | 'confirm-password'
  | 'import'
  | 'unlock'
  | 'ready';

type Language = 'tr' | 'en';

interface WalletOnboardingProps {
  lang?: Language;
  onWalletReady: (address: string) => void;
}

// ============================================
// MAIN COMPONENT
// ============================================
export default function WalletOnboarding({
  lang = 'tr',
  onWalletReady,
}: WalletOnboardingProps) {
  const insets = useSafeAreaInsets();
  
  const [step, setStep] = useState<WalletStep>('checking');
  const [seedPhrase, setSeedPhrase] = useState<string[]>([]);
  const [seedRevealed, setSeedRevealed] = useState(false);
  const [verifyStep, setVerifyStep] = useState(0);
  const [verifyIndices, setVerifyIndices] = useState<number[]>([]);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [importSeedInput, setImportSeedInput] = useState('');
  const [storedPasswordHash, setStoredPasswordHash] = useState<string | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockError, setUnlockError] = useState('');
  const [copied, setCopied] = useState(false);
  const [verifyOptions, setVerifyOptions] = useState<string[]>([]);

  const t = (key: string) => translations[lang]?.[key] || translations['en'][key] || key;

  // Check if wallet exists
  useEffect(() => {
    checkWalletExists();
  }, []);

  // Generate verify options when step changes
  useEffect(() => {
    if (step === 'verify' && verifyIndices.length > 0) {
      const currentIndex = verifyIndices[verifyStep];
      const correctWord = seedPhrase[currentIndex];
      setVerifyOptions(getVerifyOptions(correctWord));
    }
  }, [step, verifyStep, verifyIndices]);

  const checkWalletExists = async () => {
    try {
      const hasWallet = await AsyncStorage.getItem(STORAGE_KEYS.HAS_WALLET);
      const passwordHash = await AsyncStorage.getItem(STORAGE_KEYS.PASSWORD_HASH);
      const address = await AsyncStorage.getItem(STORAGE_KEYS.WALLET_ADDRESS);

      if (hasWallet === 'true' && passwordHash) {
        setStoredPasswordHash(passwordHash);
        setWalletAddress(address);
        setStep('unlock');
      } else {
        setStep('onboarding');
      }
    } catch (error) {
      setStep('onboarding');
    }
  };

  // Create wallet
  const handleCreateWallet = () => {
    const newSeed = generateSeedPhrase();
    setSeedPhrase(newSeed);
    setSeedRevealed(false);
    setStep('create');
  };

  // Generate verify indices
  const generateVerifyIndices = (): number[] => {
    const indices: number[] = [];
    while (indices.length < 3) {
      const idx = Math.floor(Math.random() * 12);
      if (!indices.includes(idx)) {
        indices.push(idx);
      }
    }
    return indices.sort((a, b) => a - b);
  };

  // Continue after seed display
  const handleSeedContinue = () => {
    const indices = generateVerifyIndices();
    setVerifyIndices(indices);
    setVerifyStep(0);
    setStep('verify');
  };

  // Verify word
  const handleVerifyWord = (selectedWord: string, correctWord: string): boolean => {
    if (selectedWord === correctWord) {
      if (verifyStep < 2) {
        setVerifyStep(verifyStep + 1);
      } else {
        setPassword('');
        setConfirmPassword('');
        setStep('password');
      }
      return true;
    }
    return false;
  };

  // Set password
  const handleSetPassword = () => {
    if (password.length < 6) {
      setPasswordError(t('passwordHint'));
      return;
    }
    setPasswordError('');
    setStep('confirm-password');
  };

  // Confirm password and save
  const handleConfirmPassword = async () => {
    if (password !== confirmPassword) {
      setPasswordError(t('pinMismatch'));
      return;
    }

    try {
      const passwordHash = await hashPassword(password);
      const encryptedSeed = encryptSeed(seedPhrase, password);
      const address = await deriveAddressFromSeed(seedPhrase);

      await AsyncStorage.setItem(STORAGE_KEYS.HAS_WALLET, 'true');
      await AsyncStorage.setItem(STORAGE_KEYS.PASSWORD_HASH, passwordHash);
      await AsyncStorage.setItem(STORAGE_KEYS.ENCRYPTED_SEED, encryptedSeed);
      await AsyncStorage.setItem(STORAGE_KEYS.WALLET_ADDRESS, address);

      setWalletAddress(address);
      onWalletReady(address);
    } catch (error) {
      Alert.alert('Error', 'Failed to create wallet');
    }
  };

  // Import wallet
  const handleImportSubmit = () => {
    const words = importSeedInput.trim().toLowerCase().split(/\s+/);

    if (words.length !== 12 && words.length !== 24) {
      Alert.alert('Error', t('invalidSeed'));
      return;
    }

    const validWords = words.every((word) => BIP39_WORDLIST.includes(word));
    if (!validWords) {
      Alert.alert('Error', t('invalidSeed'));
      return;
    }

    setSeedPhrase(words);
    setPassword('');
    setConfirmPassword('');
    setStep('password');
  };

  // Unlock
  const handleUnlock = async () => {
    try {
      const enteredHash = await hashPassword(unlockPassword);
      if (enteredHash === storedPasswordHash) {
        if (walletAddress) {
          onWalletReady(walletAddress);
        }
      } else {
        setUnlockError(t('wrongPin'));
        setUnlockPassword('');
      }
    } catch (error) {
      setUnlockError(t('wrongPin'));
    }
  };

  // Forgot password
  const handleForgotPassword = () => {
    Alert.alert(
      t('forgotPin'),
      t('resetConfirm'),
      [
        { text: t('cancel'), style: 'cancel' },
        {
          text: t('continue'),
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.multiRemove([
              STORAGE_KEYS.HAS_WALLET,
              STORAGE_KEYS.PASSWORD_HASH,
              STORAGE_KEYS.ENCRYPTED_SEED,
              STORAGE_KEYS.WALLET_ADDRESS,
            ]);
            setStep('import');
          },
        },
      ]
    );
  };

  // Copy seed
  const handleCopySeed = async () => {
    await Clipboard.setStringAsync(seedPhrase.join(' '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Get options for verify
  const getVerifyOptions = (correctWord: string): string[] => {
    const options = [correctWord];
    while (options.length < 4) {
      const randomWord = BIP39_WORDLIST[Math.floor(Math.random() * BIP39_WORDLIST.length)];
      if (!options.includes(randomWord)) {
        options.push(randomWord);
      }
    }
    return options.sort(() => Math.random() - 0.5);
  };

  // ============================================
  // RENDER FUNCTIONS
  // ============================================

  // Checking Screen
  if (step === 'checking') {
    return (
      <View style={[styles.container, styles.centered]}>
        <View style={styles.iconCircle}>
          <Ionicons name="wallet-outline" size={40} color={colors.primary} />
        </View>
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 24 }} />
      </View>
    );
  }

  // Onboarding Screen
  if (step === 'onboarding') {
    return (
      <View style={[styles.container, { paddingTop: insets.top + 40 }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <Image 
              source={require('@/assets/images/auxite-wallet-logo.png')} 
              style={styles.logoImage}
              resizeMode="contain"
            />
          </View>

          <Text style={styles.title}>{t('welcomeTitle')}</Text>
          <Text style={styles.subtitle}>{t('welcomeSubtitle')}</Text>

          {/* Features */}
          <View style={styles.featuresRow}>
            <View style={styles.featureItem}>
              <View style={styles.featureIcon}>
                <Ionicons name="shield-checkmark-outline" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureText}>Non-custodial</Text>
            </View>
            <View style={styles.featureItem}>
              <View style={styles.featureIcon}>
                <Ionicons name="key-outline" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureText}>Your Keys</Text>
            </View>
            <View style={styles.featureItem}>
              <View style={styles.featureIcon}>
                <Ionicons name="lock-closed-outline" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureText}>Secure</Text>
            </View>
          </View>

          {/* Buttons */}
          <TouchableOpacity style={styles.primaryButton} onPress={handleCreateWallet}>
            <Ionicons name="add-circle-outline" size={22} color="#FFF" />
            <Text style={styles.primaryButtonText}>{t('createNewWallet')}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.secondaryButton} onPress={() => setStep('import')}>
            <Ionicons name="download-outline" size={22} color={colors.primary} />
            <Text style={styles.secondaryButtonText}>{t('importWallet')}</Text>
          </TouchableOpacity>

          {/* Security note */}
          <View style={styles.securityNote}>
            <Ionicons name="information-circle-outline" size={16} color={colors.textMuted} />
            <Text style={styles.securityNoteText}>{t('keysOnDevice')}</Text>
          </View>
        </ScrollView>
      </View>
    );
  }

  // Seed Display Screen
  if (step === 'create') {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Back Button */}
          <TouchableOpacity style={styles.backButton} onPress={() => setStep('onboarding')}>
            <Ionicons name="arrow-back" size={24} color={colors.textSecondary} />
            <Text style={styles.backButtonText}>{t('back')}</Text>
          </TouchableOpacity>

          <Text style={styles.title}>{t('seedPhraseTitle')}</Text>

          {/* Warning */}
          <View style={styles.warningBox}>
            <Text style={styles.warningText}>{t('seedPhraseWarning')}</Text>
          </View>

          {/* Seed Grid */}
          <View style={styles.seedGrid}>
            {seedPhrase.map((word, index) => (
              <View key={index} style={styles.seedWord}>
                <Text style={styles.seedWordIndex}>{index + 1}</Text>
                <Text style={[styles.seedWordText, !seedRevealed && styles.seedWordHidden]}>
                  {seedRevealed ? word : '••••••'}
                </Text>
              </View>
            ))}
          </View>

          {/* Actions */}
          <View style={styles.actionsRow}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => setSeedRevealed(!seedRevealed)}
            >
              <Ionicons
                name={seedRevealed ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color={colors.textSecondary}
              />
              <Text style={styles.actionButtonText}>
                {seedRevealed ? t('hide') : t('reveal')}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.actionButton, !seedRevealed && styles.actionButtonDisabled]}
              onPress={handleCopySeed}
              disabled={!seedRevealed}
            >
              <Ionicons name="copy-outline" size={20} color={colors.textSecondary} />
              <Text style={styles.actionButtonText}>{copied ? t('copied') : t('copy')}</Text>
            </TouchableOpacity>
          </View>

          {/* Security Tips */}
          <View style={styles.tipsBox}>
            <Text style={styles.tipsTitle}>{t('securityTip')}</Text>
            <View style={styles.tipItem}>
              <Ionicons name="close-circle" size={16} color={colors.error} />
              <Text style={styles.tipText}>{t('neverShare')}</Text>
            </View>
            <View style={styles.tipItem}>
              <Ionicons name="close-circle" size={16} color={colors.error} />
              <Text style={styles.tipText}>{t('noScreenshot')}</Text>
            </View>
            <View style={styles.tipItem}>
              <Ionicons name="checkmark-circle" size={16} color={colors.primary} />
              <Text style={styles.tipText}>{t('writeOnPaper')}</Text>
            </View>
          </View>

          {/* Continue Button */}
          <TouchableOpacity
            style={[styles.primaryButton, !seedRevealed && styles.buttonDisabled]}
            onPress={handleSeedContinue}
            disabled={!seedRevealed}
          >
            <Text style={styles.primaryButtonText}>{t('iWroteItDown')}</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  // Verify Screen
  if (step === 'verify') {
    const currentIndex = verifyIndices[verifyStep];
    const correctWord = seedPhrase[currentIndex];

    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Back Button */}
          <TouchableOpacity style={styles.backButton} onPress={() => setStep('create')}>
            <Ionicons name="arrow-back" size={24} color={colors.textSecondary} />
            <Text style={styles.backButtonText}>{t('back')}</Text>
          </TouchableOpacity>

          <Text style={styles.title}>{t('verifyTitle')}</Text>

          {/* Progress */}
          <View style={styles.progressRow}>
            {[0, 1, 2].map((i) => (
              <View
                key={i}
                style={[styles.progressBar, i <= verifyStep && styles.progressBarActive]}
              />
            ))}
          </View>

          {/* Prompt */}
          <View style={styles.verifyPrompt}>
            <Text style={styles.verifyPromptLabel}>{t('selectWord')}</Text>
            <Text style={styles.verifyPromptNumber}>{currentIndex + 1}</Text>
          </View>

          {/* Options */}
          <View style={styles.optionsGrid}>
            {verifyOptions.map((word, index) => (
              <TouchableOpacity
                key={index}
                style={styles.optionButton}
                onPress={() => {
                  if (!handleVerifyWord(word, correctWord)) {
                    Alert.alert('Error', t('verifyError'));
                  }
                }}
              >
                <Text style={styles.optionButtonText}>{word}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
    );
  }

  // Password Screen
  if (step === 'password' || step === 'confirm-password') {
    const isConfirm = step === 'confirm-password';

    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Back Button */}
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => setStep(isConfirm ? 'password' : 'verify')}
          >
            <Ionicons name="arrow-back" size={24} color={colors.textSecondary} />
            <Text style={styles.backButtonText}>{t('back')}</Text>
          </TouchableOpacity>

          {/* Icon */}
          <View style={[styles.iconCircle, { alignSelf: 'center', marginBottom: 24 }]}>
            <Ionicons name="lock-closed-outline" size={32} color={colors.primary} />
          </View>

          <Text style={styles.title}>
            {isConfirm ? t('confirmPinTitle') : t('setPinTitle')}
          </Text>
          <Text style={styles.subtitle}>{t('setPinSubtitle')}</Text>

          {/* Input */}
          <TextInput
            style={styles.textInput}
            value={isConfirm ? confirmPassword : password}
            onChangeText={(text) => {
              if (isConfirm) {
                setConfirmPassword(text);
              } else {
                setPassword(text);
              }
              setPasswordError('');
            }}
            placeholder={isConfirm ? t('confirmPassword') : t('password')}
            placeholderTextColor={colors.textMuted}
            secureTextEntry
            autoFocus
          />

          {/* Error */}
          {passwordError ? (
            <Text style={styles.errorText}>{passwordError}</Text>
          ) : null}

          {/* Continue Button */}
          <TouchableOpacity
            style={[
              styles.primaryButton,
              (isConfirm ? confirmPassword.length < 6 : password.length < 6) && styles.buttonDisabled,
            ]}
            onPress={isConfirm ? handleConfirmPassword : handleSetPassword}
            disabled={isConfirm ? confirmPassword.length < 6 : password.length < 6}
          >
            <Text style={styles.primaryButtonText}>{t('continue')}</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  // Import Screen
  if (step === 'import') {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Back Button */}
          <TouchableOpacity style={styles.backButton} onPress={() => setStep('onboarding')}>
            <Ionicons name="arrow-back" size={24} color={colors.textSecondary} />
            <Text style={styles.backButtonText}>{t('back')}</Text>
          </TouchableOpacity>

          <Text style={styles.title}>{t('importWallet')}</Text>
          <Text style={styles.subtitle}>{t('enterSeedHint')}</Text>

          {/* Input */}
          <TextInput
            style={[styles.textInput, styles.textArea]}
            value={importSeedInput}
            onChangeText={setImportSeedInput}
            placeholder={t('enterSeedPlaceholder')}
            placeholderTextColor={colors.textMuted}
            multiline
            numberOfLines={4}
            autoCapitalize="none"
            autoCorrect={false}
          />

          {/* Import Button */}
          <TouchableOpacity
            style={[styles.primaryButton, !importSeedInput.trim() && styles.buttonDisabled]}
            onPress={handleImportSubmit}
            disabled={!importSeedInput.trim()}
          >
            <Ionicons name="download-outline" size={22} color="#FFF" />
            <Text style={styles.primaryButtonText}>{t('import')}</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  // Unlock Screen
  if (step === 'unlock') {
    return (
      <View style={[styles.container, styles.centered]}>
        {/* Icon */}
        <View style={styles.iconCircle}>
          <Ionicons name="lock-closed-outline" size={40} color={colors.primary} />
        </View>

        <Text style={styles.title}>{t('enterPinTitle')}</Text>
        <Text style={styles.subtitle}>{t('unlockSubtitle')}</Text>

        {/* Input */}
        <TextInput
          style={[styles.textInput, { width: width - 48 }]}
          value={unlockPassword}
          onChangeText={(text) => {
            setUnlockPassword(text);
            setUnlockError('');
          }}
          onSubmitEditing={handleUnlock}
          placeholder={t('password')}
          placeholderTextColor={colors.textMuted}
          secureTextEntry
          autoFocus
        />

        {/* Error */}
        {unlockError ? <Text style={styles.errorText}>{unlockError}</Text> : null}

        {/* Unlock Button */}
        <TouchableOpacity
          style={[
            styles.primaryButton,
            { width: width - 48 },
            unlockPassword.length < 6 && styles.buttonDisabled,
          ]}
          onPress={handleUnlock}
          disabled={unlockPassword.length < 6}
        >
          <Text style={styles.primaryButtonText}>{t('unlock')}</Text>
        </TouchableOpacity>

        {/* Forgot Password */}
        <TouchableOpacity style={styles.forgotButton} onPress={handleForgotPassword}>
          <Text style={styles.forgotButtonText}>{t('forgotPin')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return null;
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  scrollContent: {
    padding: 24,
    paddingBottom: 40,
  },
  
  // Logo
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
  },
  logoImage: {
    width: 180,
    height: 60,
  },
  
  // Typography
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 22,
  },
  
  // Features
  featuresRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 32,
    marginBottom: 40,
  },
  featureItem: {
    alignItems: 'center',
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  
  // Buttons
  primaryButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 12,
  },
  primaryButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 24,
  },
  secondaryButtonText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  buttonDisabled: {
    backgroundColor: colors.surfaceLight,
    opacity: 0.6,
  },
  
  // Back Button
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 24,
  },
  backButtonText: {
    color: colors.textSecondary,
    fontSize: 16,
  },
  
  // Security Note
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  securityNoteText: {
    fontSize: 12,
    color: colors.textMuted,
  },
  
  // Icon Circle
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  
  // Warning Box
  warningBox: {
    backgroundColor: colors.warningBg,
    borderWidth: 1,
    borderColor: 'rgba(245, 158, 11, 0.3)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  warningText: {
    color: colors.warning,
    fontSize: 14,
    lineHeight: 20,
  },
  
  // Seed Grid
  seedGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  seedWord: {
    width: (width - 48 - 20) / 3,
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  seedWordIndex: {
    color: colors.textMuted,
    fontSize: 12,
    width: 18,
  },
  seedWordText: {
    color: colors.text,
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
  },
  seedWordHidden: {
    color: colors.textMuted,
  },
  
  // Actions Row
  actionsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  actionButton: {
    flex: 1,
    backgroundColor: colors.surface,
    paddingVertical: 14,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  actionButtonDisabled: {
    opacity: 0.5,
  },
  actionButtonText: {
    color: colors.textSecondary,
    fontSize: 14,
    fontWeight: '500',
  },
  
  // Tips Box
  tipsBox: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  tipsTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 12,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  tipText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  
  // Progress
  progressRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 32,
  },
  progressBar: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.surfaceLight,
  },
  progressBarActive: {
    backgroundColor: colors.primary,
  },
  
  // Verify Prompt
  verifyPrompt: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 32,
  },
  verifyPromptLabel: {
    color: colors.textSecondary,
    fontSize: 14,
    marginBottom: 8,
  },
  verifyPromptNumber: {
    color: colors.text,
    fontSize: 48,
    fontWeight: '700',
  },
  
  // Options Grid
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  optionButton: {
    width: (width - 48 - 12) / 2,
    backgroundColor: colors.surface,
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  optionButtonText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '500',
  },
  
  // Text Input
  textInput: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    color: colors.text,
    fontSize: 16,
    marginBottom: 16,
  },
  textArea: {
    minHeight: 120,
    textAlignVertical: 'top',
  },
  
  // Error
  errorText: {
    color: colors.error,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  
  // Forgot Button
  forgotButton: {
    marginTop: 16,
  },
  forgotButtonText: {
    color: colors.primary,
    fontSize: 14,
  },
});
