// components/AllocationModal.tsx
// Stake & Earn Modal for Mobile - On-chain staking integration

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  ScrollView,
  useColorScheme,
  ActivityIndicator,
  Image,
  Alert,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useStore } from '@/stores/useStore';
import { useStakingMobile } from '@/hooks/useStakingMobile';
import * as Clipboard from 'expo-clipboard';

// Metal icons
const metalIcons: Record<string, any> = {
  AUXG: require('@/assets/images/metals/gold.png'),
  AUXS: require('@/assets/images/metals/silver.png'),
  AUXPT: require('@/assets/images/metals/platinum.png'),
  AUXPD: require('@/assets/images/metals/palladium.png'),
};

// Metal colors
const metalColors: Record<string, string> = {
  AUXG: '#EAB308',
  AUXS: '#94A3B8',
  AUXPT: '#06B6D4',
  AUXPD: '#F43F5E',
};

// Translations
const translations: Record<string, Record<string, string>> = {
  tr: {
    lockEarn: 'Biriktir & Kazan',
    lockPeriod: 'Biriktirme Süresi',
    month: 'Ay',
    days: 'gün',
    amount: 'Miktar',
    balance: 'Bakiye',
    lockSuccess: 'Biriktirme Başarılı!',
    positionCreated: 'Pozisyonunuz oluşturuldu.',
    approved: 'Onaylandı',
    canLockNow: 'Şimdi biriktirebilirsiniz.',
    infoNotice: 'gün boyunca tokenleriniz biriktirilecektir. Süre sonunda anaparanız ve kazancınız otomatik olarak iade edilecektir.',
    approving: 'Onaylanıyor...',
    approveToken: 'Onayla',
    locking: 'Biriktiriliyor...',
    cancel: 'İptal',
    estimatedEarnings: 'Tahmini Kazanç',
    afterPeriod: 'Süre sonunda',
    apy: 'APY',
    stakeCode: 'Stake Kodu',
    copyCode: 'Kopyala',
    copied: 'Kopyalandı!',
    viewOnChain: 'Blockchain\'de Görüntüle',
    compounding: 'Bileşik Faiz',
    compoundingDesc: 'Kazançlar otomatik olarak anaparaya eklenir',
    txPending: 'İşlem Onay Bekliyor...',
    txConfirming: 'Blockchain\'de Doğrulanıyor...',
    done: 'Tamam',
    total: 'Toplam',
    minAmount: 'Min.',
  },
  en: {
    lockEarn: 'Stake & Earn',
    lockPeriod: 'Stake Period',
    month: 'Mo',
    days: 'days',
    amount: 'Amount',
    balance: 'Balance',
    lockSuccess: 'Stake Successful!',
    positionCreated: 'Your position has been created.',
    approved: 'Approved',
    canLockNow: 'You can now stake.',
    infoNotice: 'days your tokens will be staked. Principal and earnings will be automatically returned after the period ends.',
    approving: 'Approving...',
    approveToken: 'Approve',
    locking: 'Staking...',
    cancel: 'Cancel',
    estimatedEarnings: 'Estimated Earnings',
    afterPeriod: 'After period',
    apy: 'APY',
    stakeCode: 'Stake Code',
    copyCode: 'Copy',
    copied: 'Copied!',
    viewOnChain: 'View on Blockchain',
    compounding: 'Auto-Compound',
    compoundingDesc: 'Earnings automatically added to principal',
    txPending: 'Transaction Pending...',
    txConfirming: 'Confirming on Blockchain...',
    done: 'Done',
    total: 'Total',
    minAmount: 'Min.',
  },
  de: {
    lockEarn: 'Stake & Verdienen',
    lockPeriod: 'Stake-Zeitraum',
    month: 'Mo',
    days: 'Tage',
    amount: 'Betrag',
    balance: 'Guthaben',
    lockSuccess: 'Stake Erfolgreich!',
    positionCreated: 'Ihre Position wurde erstellt.',
    approved: 'Genehmigt',
    canLockNow: 'Sie können jetzt staken.',
    infoNotice: 'Tage werden Ihre Token gestaked. Kapital und Erträge werden nach Ablauf automatisch zurückgegeben.',
    approving: 'Genehmigung...',
    approveToken: 'Genehmigen',
    locking: 'Staking...',
    cancel: 'Abbrechen',
    estimatedEarnings: 'Geschätzte Erträge',
    afterPeriod: 'Nach der Periode',
    apy: 'APY',
    stakeCode: 'Stake-Code',
    copyCode: 'Kopieren',
    copied: 'Kopiert!',
    viewOnChain: 'Auf Blockchain anzeigen',
    compounding: 'Auto-Zinseszins',
    compoundingDesc: 'Erträge werden automatisch zum Kapital hinzugefügt',
    txPending: 'Transaktion ausstehend...',
    txConfirming: 'Wird auf Blockchain bestätigt...',
    done: 'Fertig',
    total: 'Gesamt',
    minAmount: 'Min.',
  },
  fr: {
    lockEarn: 'Stake & Gagner',
    lockPeriod: 'Période de Stake',
    month: 'Mois',
    days: 'jours',
    amount: 'Montant',
    balance: 'Solde',
    lockSuccess: 'Stake Réussi!',
    positionCreated: 'Votre position a été créée.',
    approved: 'Approuvé',
    canLockNow: 'Vous pouvez maintenant staker.',
    infoNotice: 'jours vos tokens seront stakés. Le capital et les gains seront automatiquement retournés après la période.',
    approving: 'Approbation...',
    approveToken: 'Approuver',
    locking: 'Staking...',
    cancel: 'Annuler',
    estimatedEarnings: 'Gains Estimés',
    afterPeriod: 'Après la période',
    apy: 'APY',
    stakeCode: 'Code de Stake',
    copyCode: 'Copier',
    copied: 'Copié!',
    viewOnChain: 'Voir sur Blockchain',
    compounding: 'Auto-Composition',
    compoundingDesc: 'Les gains sont automatiquement ajoutés au capital',
    txPending: 'Transaction en attente...',
    txConfirming: 'Confirmation sur Blockchain...',
    done: 'Terminé',
    total: 'Total',
    minAmount: 'Min.',
  },
  ar: {
    lockEarn: 'تخزين واربح',
    lockPeriod: 'فترة التخزين',
    month: 'شهر',
    days: 'يوم',
    amount: 'المبلغ',
    balance: 'الرصيد',
    lockSuccess: 'تم التخزين بنجاح!',
    positionCreated: 'تم إنشاء موقعك.',
    approved: 'تمت الموافقة',
    canLockNow: 'يمكنك الآن التخزين.',
    infoNotice: 'يوم سيتم تخزين رموزك. سيتم إرجاع رأس المال والأرباح تلقائياً بعد انتهاء الفترة.',
    approving: 'جاري الموافقة...',
    approveToken: 'يتأكد',
    locking: 'جاري التخزين...',
    cancel: 'إلغاء',
    estimatedEarnings: 'الأرباح المتوقعة',
    afterPeriod: 'بعد الفترة',
    apy: 'العائد السنوي',
    stakeCode: 'رمز التخزين',
    copyCode: 'نسخ',
    copied: 'تم النسخ!',
    viewOnChain: 'عرض على البلوكتشين',
    compounding: 'فائدة مركبة تلقائية',
    compoundingDesc: 'تضاف الأرباح تلقائياً إلى رأس المال',
    txPending: 'المعاملة معلقة...',
    txConfirming: 'جاري التأكيد على البلوكتشين...',
    done: 'تم',
    total: 'المجموع',
    minAmount: 'الحد الأدنى',
  },
  ru: {
    lockEarn: 'Стейкинг и Заработок',
    lockPeriod: 'Период Стейкинга',
    month: 'Мес',
    days: 'дней',
    amount: 'Сумма',
    balance: 'Баланс',
    lockSuccess: 'Стейкинг Успешен!',
    positionCreated: 'Ваша позиция создана.',
    approved: 'Одобрено',
    canLockNow: 'Теперь вы можете сделать стейкинг.',
    infoNotice: 'дней ваши токены будут в стейкинге. Основная сумма и заработок будут автоматически возвращены после окончания периода.',
    approving: 'Одобрение...',
    approveToken: 'Одобрить',
    locking: 'Стейкинг...',
    cancel: 'Отмена',
    estimatedEarnings: 'Расчетный Заработок',
    afterPeriod: 'После периода',
    apy: 'APY',
    stakeCode: 'Код Стейкинга',
    copyCode: 'Копировать',
    copied: 'Скопировано!',
    viewOnChain: 'Посмотреть в Блокчейне',
    compounding: 'Автокомпаундинг',
    compoundingDesc: 'Заработок автоматически добавляется к основной сумме',
    txPending: 'Транзакция ожидает...',
    txConfirming: 'Подтверждение в блокчейне...',
    done: 'Готово',
    total: 'Всего',
    minAmount: 'Мин.',
  },
};

interface Period {
  months: number;
  days?: number;
  apy: number;
}

interface Offer {
  metal: string;
  name: string;
  minAmount: number;
  maxAmount?: number;
  tvl: number;
  periods: Period[];
}

interface AllocationModalProps {
  visible: boolean;
  onClose: () => void;
  offer: Offer | null;
}

export function AllocationModal({ visible, onClose, offer }: AllocationModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language, walletAddress, isConnected } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language] || translations.en;

  // On-chain staking hook
  const {
    approve,
    stake,
    checkAllowance,
    getTokenBalance,
    previewReward,
    isApproving,
    isStaking,
    approveSuccess,
    stakeSuccess,
    lastStakeCode,
    lastTxHash,
    error: stakingError,
  } = useStakingMobile();

  // State
  const [selectedPeriod, setSelectedPeriod] = useState(3);
  const [amount, setAmount] = useState('');
  const [compounding, setCompounding] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [stakeCode, setStakeCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  
  // On-chain specific state
  const [balance, setBalance] = useState(0);
  const [allowance, setAllowance] = useState(0);
  const [needsApproval, setNeedsApproval] = useState(false);
  const [isLoadingBalance, setIsLoadingBalance] = useState(false);
  const [estimatedReward, setEstimatedReward] = useState(0);

  // Fetch balance and allowance when modal opens
  useEffect(() => {
    const fetchBalanceAndAllowance = async () => {
      if (visible && offer && isConnected) {
        setIsLoadingBalance(true);
        try {
          const [bal, allow] = await Promise.all([
            getTokenBalance(offer.metal),
            checkAllowance(offer.metal),
          ]);
          setBalance(bal);
          setAllowance(allow);
        } catch (err) {
          console.error('Failed to fetch balance:', err);
        } finally {
          setIsLoadingBalance(false);
        }
      }
    };

    fetchBalanceAndAllowance();
  }, [visible, offer, isConnected]);

  // Check if approval is needed when amount changes
  useEffect(() => {
    const amountNum = parseFloat(amount) || 0;
    setNeedsApproval(amountNum > 0 && amountNum > allowance);
  }, [amount, allowance]);

  // Update allowance after successful approval
  useEffect(() => {
    if (approveSuccess && offer) {
      checkAllowance(offer.metal).then(setAllowance);
    }
  }, [approveSuccess, offer]);

  // Handle successful stake
  useEffect(() => {
    if (stakeSuccess && lastStakeCode) {
      setStakeCode(lastStakeCode);
      setIsSuccess(true);
    }
  }, [stakeSuccess, lastStakeCode]);

  // Calculate estimated reward when amount/period changes
  useEffect(() => {
    const calcReward = async () => {
      const amountNum = parseFloat(amount) || 0;
      if (amountNum > 0 && offer) {
        const { expectedRewardGrams } = await previewReward(
          offer.metal as any,
          amountNum,
          selectedPeriod as 3 | 6 | 12
        );
        setEstimatedReward(expectedRewardGrams);
      } else {
        setEstimatedReward(0);
      }
    };
    calcReward();
  }, [amount, selectedPeriod, offer]);

  // Reset state when modal opens
  useEffect(() => {
    if (visible) {
      setSelectedPeriod(3);
      setAmount('');
      setCompounding(false);
      setIsSuccess(false);
      setStakeCode(null);
      setEstimatedReward(0);
    }
  }, [visible]);

  if (!offer) return null;

  const amountNum = parseFloat(amount) || 0;
  const currentPeriod = offer.periods.find(p => p.months === selectedPeriod) || offer.periods[0];
  const periodDays = currentPeriod.days || (selectedPeriod === 12 ? 365 : selectedPeriod * 30);

  // Calculate earnings (fallback calculation)
  const earnings = estimatedReward > 0 ? estimatedReward : (amountNum * currentPeriod.apy * periodDays) / (100 * 365);
  const total = amountNum + earnings;

  // Get max APY for bar visualization
  const maxAPY = Math.max(...offer.periods.map(p => p.apy));

  // Check if wallet is connected
  const isWalletConnected = isConnected && walletAddress;

  // Handle approve
  const handleApprove = async () => {
    if (!offer || amountNum <= 0) return;

    try {
      await approve(offer.metal, amountNum);
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Approval failed');
    }
  };

  // Handle stake
  const handleStake = async () => {
    if (!offer) return;

    // Validation
    if (!isWalletConnected) {
      Alert.alert(language === 'tr' ? 'Hata' : 'Error', 
        language === 'tr' ? 'Cüzdan bağlı değil' : 'Wallet not connected');
      return;
    }

    if (amountNum < offer.minAmount) {
      Alert.alert(language === 'tr' ? 'Hata' : 'Error', 
        `${t.minAmount} ${offer.minAmount}g`);
      return;
    }

    if (amountNum > balance) {
      Alert.alert(language === 'tr' ? 'Hata' : 'Error', 
        language === 'tr' ? 'Yetersiz bakiye' : 'Insufficient balance');
      return;
    }

    // Check if needs approval first
    if (needsApproval) {
      Alert.alert(language === 'tr' ? 'Hata' : 'Error', 
        language === 'tr' ? 'Önce token onayı gerekli' : 'Token approval required first');
      return;
    }

    try {
      await stake(
        offer.metal as 'AUXG' | 'AUXS' | 'AUXPT' | 'AUXPD',
        amountNum,
        selectedPeriod as 3 | 6 | 12,
        compounding,
        0 // allocationId
      );
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Staking failed');
    }
  };

  // Handle copy
  const handleCopy = async () => {
    if (stakeCode) {
      await Clipboard.setStringAsync(stakeCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // APY Period Button
  const PeriodButton = ({ period }: { period: Period }) => {
    const isSelected = selectedPeriod === period.months;
    const barHeight = (period.apy / maxAPY) * 100;
    const days = period.days || (period.months === 12 ? 365 : period.months * 30);

    return (
      <TouchableOpacity
        style={[
          styles.periodButton,
          { 
            backgroundColor: isDark ? '#0f172a' : '#f8fafc',
            borderColor: isSelected ? '#10b981' : (isDark ? '#334155' : '#e2e8f0'),
            borderWidth: 2,
          }
        ]}
        onPress={() => setSelectedPeriod(period.months)}
        activeOpacity={0.7}
      >
        {/* APY Bar */}
        <View style={styles.barContainer}>
          <View 
            style={[
              styles.bar,
              { 
                height: `${barHeight}%`,
                backgroundColor: isSelected ? '#10b981' : (isDark ? '#475569' : '#cbd5e1'),
              }
            ]} 
          />
        </View>

        {/* Period Info */}
        <Text style={[
          styles.periodMonths,
          { color: isSelected ? '#10b981' : (isDark ? '#e2e8f0' : '#334155') }
        ]}>
          {period.months} {t.month}
        </Text>
        <Text style={[styles.periodDays, { color: isDark ? '#64748b' : '#94a3b8' }]}>
          {days} {t.days}
        </Text>
        <Text style={[
          styles.periodAPY,
          { color: isSelected ? '#10b981' : (isDark ? '#94a3b8' : '#64748b') }
        ]}>
          {period.apy.toFixed(2)}%
        </Text>

        {/* Checkmark */}
        {isSelected && (
          <View style={styles.checkmark}>
            <Ionicons name="checkmark" size={10} color="#fff" />
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={[styles.modalHeader, { borderBottomColor: isDark ? '#334155' : '#e2e8f0' }]}>
            <View style={styles.headerLeft}>
              <Image source={metalIcons[offer.metal]} style={styles.headerIcon} resizeMode="contain" />
              <View>
                <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{offer.name}</Text>
                <Text style={[styles.headerSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.lockEarn}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
            {!isSuccess ? (
              <>
                {/* Period Selection */}
                <View style={styles.section}>
                  <View style={styles.labelRow}>
                    <Ionicons name="calendar-outline" size={16} color={isDark ? '#94a3b8' : '#64748b'} />
                    <Text style={[styles.sectionLabel, { color: isDark ? '#e2e8f0' : '#334155' }]}>{t.lockPeriod}</Text>
                  </View>
                  <View style={styles.periodsGrid}>
                    {offer.periods.map((period) => (
                      <PeriodButton key={period.months} period={period} />
                    ))}
                  </View>
                </View>

                {/* Amount Input */}
                <View style={styles.section}>
                  <View style={styles.labelRow}>
                    <Ionicons name="wallet-outline" size={16} color={isDark ? '#94a3b8' : '#64748b'} />
                    <Text style={[styles.sectionLabel, { color: isDark ? '#e2e8f0' : '#334155' }]}>{t.amount} (gram)</Text>
                  </View>
                  <View style={[styles.inputContainer, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
                    <TextInput
                      style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                      value={amount}
                      onChangeText={setAmount}
                      placeholder={`${t.minAmount} ${offer.minAmount}g`}
                      placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
                      keyboardType="decimal-pad"
                      editable={!isApproving && !isStaking}
                    />
                    <TouchableOpacity 
                      style={styles.maxButton}
                      onPress={() => setAmount(balance.toFixed(4))}
                      disabled={isLoadingBalance}
                    >
                      <Text style={styles.maxButtonText}>MAX</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={styles.balanceRow}>
                    {isLoadingBalance ? (
                      <View style={styles.balanceLoading}>
                        <ActivityIndicator size="small" color="#64748b" />
                        <Text style={[styles.balanceText, { color: isDark ? '#64748b' : '#94a3b8', marginLeft: 6 }]}>
                          Loading...
                        </Text>
                      </View>
                    ) : (
                      <Text style={[styles.balanceText, { color: isDark ? '#64748b' : '#94a3b8' }]}>
                        {t.balance}: {balance.toFixed(4)}g
                      </Text>
                    )}
                    {amountNum > 0 && amountNum < offer.minAmount && (
                      <Text style={styles.errorText}>{t.minAmount} {offer.minAmount}g</Text>
                    )}
                    {amountNum > balance && balance > 0 && (
                      <Text style={styles.errorText}>
                        {language === 'tr' ? 'Yetersiz bakiye' : 'Insufficient balance'}
                      </Text>
                    )}
                  </View>
                </View>

                {/* Compounding Toggle */}
                <View style={[styles.compoundingCard, { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
                  <View style={styles.compoundingLeft}>
                    <View style={[styles.compoundingIcon, { backgroundColor: '#a855f720' }]}>
                      <Ionicons name="sync" size={16} color="#a855f7" />
                    </View>
                    <View>
                      <Text style={[styles.compoundingTitle, { color: isDark ? '#e2e8f0' : '#334155' }]}>{t.compounding}</Text>
                      <Text style={[styles.compoundingDesc, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.compoundingDesc}</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    style={[styles.toggle, { backgroundColor: compounding ? '#a855f7' : (isDark ? '#475569' : '#cbd5e1') }]}
                    onPress={() => setCompounding(!compounding)}
                  >
                    <View style={[styles.toggleKnob, { transform: [{ translateX: compounding ? 18 : 2 }] }]} />
                  </TouchableOpacity>
                </View>

                {/* Earnings Calculator */}
                {amountNum > 0 && (
                  <View style={styles.earningsCard}>
                    <LinearGradient
                      colors={['#10b98120', '#06b6d420']}
                      style={styles.earningsGradient}
                    >
                      <View style={styles.earningsHeader}>
                        <Ionicons name="calculator-outline" size={16} color="#10b981" />
                        <Text style={styles.earningsTitle}>{t.estimatedEarnings}</Text>
                      </View>
                      <View style={styles.earningsGrid}>
                        <View style={styles.earningItem}>
                          <Text style={[styles.earningLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.afterPeriod}</Text>
                          <Text style={styles.earningValue}>+{earnings.toFixed(4)}g</Text>
                        </View>
                        <View style={styles.earningItem}>
                          <Text style={[styles.earningLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.total}</Text>
                          <Text style={[styles.earningTotal, { color: isDark ? '#fff' : '#0f172a' }]}>{total.toFixed(4)}g</Text>
                        </View>
                      </View>
                    </LinearGradient>
                  </View>
                )}

                {/* Info Notice */}
                <View style={[styles.infoNotice, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
                  <Ionicons name="information-circle-outline" size={16} color={isDark ? '#64748b' : '#94a3b8'} />
                  <Text style={[styles.infoText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                    {periodDays} {t.infoNotice}
                  </Text>
                </View>
              </>
            ) : (
              /* Success State */
              <View style={styles.successContainer}>
                <View style={styles.successIconContainer}>
                  <Ionicons name="checkmark-circle" size={60} color="#10b981" />
                </View>
                <Text style={[styles.successTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.lockSuccess}</Text>
                <Text style={[styles.successSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.positionCreated}</Text>

                {/* Stake Code */}
                {stakeCode && (
                  <View style={[styles.stakeCodeCard, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
                    <Text style={[styles.stakeCodeLabel, { color: '#10b981' }]}>{t.stakeCode}</Text>
                    <View style={styles.stakeCodeRow}>
                      <Text style={[styles.stakeCodeValue, { color: '#10b981' }]}>{stakeCode}</Text>
                      <TouchableOpacity style={styles.copyButton} onPress={handleCopy}>
                        <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={16} color="#10b981" />
                        <Text style={styles.copyButtonText}>{copied ? t.copied : t.copyCode}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              </View>
            )}
          </ScrollView>

          {/* Footer Actions */}
          <View style={[styles.footer, { borderTopColor: isDark ? '#334155' : '#e2e8f0' }]}>
            {!isSuccess ? (
              <>
                {/* Wallet not connected warning */}
                {!isWalletConnected && (
                  <View style={[styles.warningBox, { backgroundColor: isDark ? '#78350f20' : '#fef3c7' }]}>
                    <Ionicons name="warning" size={16} color="#f59e0b" />
                    <Text style={[styles.warningText, { color: isDark ? '#fbbf24' : '#92400e' }]}>
                      {language === 'tr' ? 'Cüzdan bağlı değil' : 'Wallet not connected'}
                    </Text>
                  </View>
                )}

                {/* Approve Button (if needed) */}
                {needsApproval && isWalletConnected && (
                  <TouchableOpacity
                    style={[styles.approveButton, isApproving && styles.stakeButtonDisabled]}
                    onPress={handleApprove}
                    disabled={isApproving || amountNum <= 0}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={isApproving ? ['#475569', '#334155'] : ['#3b82f6', '#2563eb']}
                      style={styles.stakeButtonGradient}
                    >
                      {isApproving ? (
                        <>
                          <ActivityIndicator size="small" color="#fff" />
                          <Text style={styles.stakeButtonText}>{t.approving}</Text>
                        </>
                      ) : (
                        <>
                          <Ionicons name="checkmark-circle" size={18} color="#fff" />
                          <Text style={styles.stakeButtonText}>{t.approveToken}</Text>
                        </>
                      )}
                    </LinearGradient>
                  </TouchableOpacity>
                )}

                {/* Stake Button */}
                <TouchableOpacity
                  style={[
                    styles.stakeButton, 
                    (amountNum < offer.minAmount || isStaking || needsApproval || !isWalletConnected) && styles.stakeButtonDisabled
                  ]}
                  onPress={handleStake}
                  disabled={amountNum < offer.minAmount || isStaking || needsApproval || !isWalletConnected}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={
                      amountNum >= offer.minAmount && !isStaking && !needsApproval && isWalletConnected 
                        ? ['#10b981', '#059669'] 
                        : ['#475569', '#334155']
                    }
                    style={styles.stakeButtonGradient}
                  >
                    {isStaking ? (
                      <>
                        <ActivityIndicator size="small" color="#fff" />
                        <Text style={styles.stakeButtonText}>{t.locking}</Text>
                      </>
                    ) : (
                      <>
                        <Ionicons name="lock-closed" size={18} color="#fff" />
                        <Text style={styles.stakeButtonText}>{t.lockEarn}</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                {/* Cancel Button */}
                <TouchableOpacity
                  style={[styles.cancelButton, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}
                  onPress={onClose}
                  disabled={isApproving || isStaking}
                >
                  <Text style={[styles.cancelButtonText, { color: isDark ? '#e2e8f0' : '#334155' }]}>{t.cancel}</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                {/* View on Blockchain */}
                {lastTxHash && (
                  <TouchableOpacity
                    style={[styles.viewOnChainButton, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}
                    onPress={() => Linking.openURL(`https://sepolia.basescan.org/tx/${lastTxHash}`)}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="open-outline" size={16} color={isDark ? '#94a3b8' : '#64748b'} />
                    <Text style={[styles.viewOnChainText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
                      {t.viewOnChain}
                    </Text>
                  </TouchableOpacity>
                )}

                {/* Done Button */}
                <TouchableOpacity
                  style={styles.doneButton}
                  onPress={onClose}
                  activeOpacity={0.8}
                >
                  <LinearGradient colors={['#10b981', '#059669']} style={styles.stakeButtonGradient}>
                    <Text style={styles.stakeButtonText}>{t.done}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerIcon: {
    width: 44,
    height: 44,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  headerSubtitle: {
    fontSize: 12,
    marginTop: 2,
  },
  closeButton: {
    padding: 4,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 20,
  },
  labelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: '600',
  },

  // Period Selection
  periodsGrid: {
    flexDirection: 'row',
    gap: 10,
  },
  periodButton: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    position: 'relative',
  },
  barContainer: {
    width: 24,
    height: 40,
    justifyContent: 'flex-end',
    marginBottom: 8,
  },
  bar: {
    width: '100%',
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  periodMonths: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 2,
  },
  periodDays: {
    fontSize: 9,
    marginBottom: 4,
  },
  periodAPY: {
    fontSize: 11,
    fontWeight: '600',
  },
  checkmark: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#10b981',
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Amount Input
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 16,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 16,
  },
  maxButton: {
    backgroundColor: '#10b98130',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  maxButtonText: {
    color: '#10b981',
    fontSize: 12,
    fontWeight: '700',
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  balanceText: {
    fontSize: 11,
  },
  errorText: {
    fontSize: 11,
    color: '#ef4444',
  },

  // Compounding Toggle
  compoundingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 20,
  },
  compoundingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  compoundingIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  compoundingTitle: {
    fontSize: 13,
    fontWeight: '600',
  },
  compoundingDesc: {
    fontSize: 10,
    marginTop: 2,
  },
  toggle: {
    width: 44,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
  },
  toggleKnob: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#fff',
  },

  // Earnings Calculator
  earningsCard: {
    marginBottom: 20,
    borderRadius: 12,
    overflow: 'hidden',
  },
  earningsGradient: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#10b98130',
  },
  earningsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  earningsTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#10b981',
  },
  earningsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  earningItem: {},
  earningLabel: {
    fontSize: 10,
    marginBottom: 4,
  },
  earningValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#10b981',
  },
  earningTotal: {
    fontSize: 18,
    fontWeight: '700',
  },

  // Info Notice
  infoNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 20,
  },
  infoText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 16,
  },

  // Success State
  successContainer: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  successIconContainer: {
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 8,
  },
  successSubtitle: {
    fontSize: 13,
    marginBottom: 24,
  },
  stakeCodeCard: {
    width: '100%',
    padding: 16,
    borderRadius: 12,
  },
  stakeCodeLabel: {
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 8,
  },
  stakeCodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  stakeCodeValue: {
    fontSize: 16,
    fontWeight: '700',
    fontFamily: 'monospace',
  },
  copyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#10b98120',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  copyButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10b981',
  },

  // Footer
  footer: {
    padding: 20,
    borderTopWidth: 1,
    gap: 10,
  },
  stakeButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  stakeButtonDisabled: {
    opacity: 0.7,
  },
  stakeButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  stakeButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700',
  },
  cancelButton: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  approveButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  warningBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 10,
    marginBottom: 6,
  },
  warningText: {
    fontSize: 13,
    fontWeight: '500',
  },
  viewOnChainButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 14,
    borderRadius: 12,
    marginBottom: 6,
  },
  viewOnChainText: {
    fontSize: 14,
    fontWeight: '500',
  },
  balanceLoading: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  doneButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
});

export default AllocationModal;
