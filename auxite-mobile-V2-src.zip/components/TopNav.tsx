// components/TopNav.tsx
// Üst Navigasyon - Yeni DrawerMenu ile çalışır
// ESKİ DRAWER MENÜ SİLİNDİ - Artık _layout.tsx'deki DrawerMenu kullanılıyor

import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  StyleSheet,
  useColorScheme,
  Pressable,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useStore } from '@/stores/useStore';
import { useDrawer } from '@/app/(tabs)/_layout';

const LANGUAGES = [
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
];

export default function TopNav() {
  const colorScheme = useColorScheme();
  const systemIsDark = colorScheme === 'dark';
  const { language, setLanguage, theme } = useStore();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { openDrawer } = useDrawer();

  const [langModalOpen, setLangModalOpen] = useState(false);

  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const currentLang = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  const colors = {
    background: isDark ? '#0f172a' : '#fff',
    text: isDark ? '#fff' : '#0f172a',
    surface: isDark ? '#1e293b' : '#fff',
    border: isDark ? '#1e293b' : '#f1f5f9',
    primary: '#10b981',
  };

  const t = {
    selectLanguage: language === 'tr' ? 'Dil Seçin' : 'Select Language',
  };

  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      {/* Top Nav */}
      <View style={[
        styles.topNavContainer, 
        { 
          backgroundColor: colors.background,
          paddingTop: insets.top,
        }
      ]}>
        <View style={[styles.topNav, { borderBottomColor: colors.border }]}>
          {/* Hamburger - Opens NEW DrawerMenu */}
          <TouchableOpacity style={styles.iconButton} onPress={openDrawer} activeOpacity={0.7}>
            <Ionicons name="menu" size={24} color={colors.text} />
          </TouchableOpacity>

          {/* Right Icons */}
          <View style={styles.rightIcons}>
            {/* Language */}
            <TouchableOpacity style={styles.iconButton} onPress={() => setLangModalOpen(true)} activeOpacity={0.7}>
              <Text style={styles.langFlagIcon}>{currentLang.flag}</Text>
            </TouchableOpacity>

            {/* Contact / Support */}
            <TouchableOpacity style={styles.iconButton} onPress={() => router.push('/support' as any)} activeOpacity={0.7}>
              <Ionicons name="headset-outline" size={20} color={colors.text} />
            </TouchableOpacity>

            {/* Notifications */}
            <TouchableOpacity style={styles.iconButton} onPress={() => router.push('/notifications' as any)} activeOpacity={0.7}>
              <Ionicons name="notifications-outline" size={20} color={colors.text} />
              <View style={styles.notifBadge}><Text style={styles.notifBadgeText}>3</Text></View>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Language Modal */}
      <Modal visible={langModalOpen} animationType="fade" transparent={true} onRequestClose={() => setLangModalOpen(false)}>
        <Pressable style={styles.langModalOverlay} onPress={() => setLangModalOpen(false)}>
          <Pressable style={[styles.langModal, { backgroundColor: colors.surface }]} onPress={e => e.stopPropagation()}>
            <Text style={[styles.langModalTitle, { color: colors.text }]}>{t.selectLanguage}</Text>
            {LANGUAGES.map((lang) => (
              <TouchableOpacity 
                key={lang.code} 
                style={[
                  styles.langOption, 
                  language === lang.code && styles.langOptionActive, 
                  { borderBottomColor: colors.border }
                ]} 
                onPress={() => { setLanguage(lang.code); setLangModalOpen(false); }}
              >
                <Text style={styles.langOptionFlag}>{lang.flag}</Text>
                <Text style={[styles.langOptionName, { color: colors.text }]}>{lang.name}</Text>
                {language === lang.code && <Ionicons name="checkmark-circle" size={20} color={colors.primary} />}
              </TouchableOpacity>
            ))}
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  topNavContainer: {
    width: '100%',
  },
  topNav: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    paddingHorizontal: 14, 
    paddingVertical: 10, 
    borderBottomWidth: 1,
  },
  iconButton: { 
    padding: 6, 
    position: 'relative' 
  },
  rightIcons: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 4 
  },
  langFlagIcon: { 
    fontSize: 20 
  },
  notifBadge: { 
    position: 'absolute', 
    top: 2, 
    right: 2, 
    backgroundColor: '#ef4444', 
    borderRadius: 7, 
    width: 14, 
    height: 14, 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  notifBadgeText: { 
    color: '#fff', 
    fontSize: 8, 
    fontWeight: 'bold' 
  },
  // Language Modal
  langModalOverlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.5)', 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  langModal: { 
    width: '85%', 
    maxWidth: 300, 
    borderRadius: 16, 
    padding: 20 
  },
  langModalTitle: { 
    fontSize: 16, 
    fontWeight: '600', 
    marginBottom: 16, 
    textAlign: 'center' 
  },
  langOption: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 12, 
    paddingVertical: 14, 
    borderBottomWidth: 1 
  },
  langOptionActive: { 
    backgroundColor: '#10b98110', 
    marginHorizontal: -12, 
    paddingHorizontal: 12, 
    borderRadius: 8 
  },
  langOptionFlag: { 
    fontSize: 22 
  },
  langOptionName: { 
    fontSize: 14, 
    flex: 1 
  },
});
