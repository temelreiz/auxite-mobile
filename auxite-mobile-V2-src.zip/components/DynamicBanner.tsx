// components/DynamicBanner.tsx
// Auxite Mobile App - Admin Panel'den yönetilen dinamik banner

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  useColorScheme,
  Image,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useStore } from '@/stores/useStore';
import { fetchBanners, type Banner } from '@/services/adminApi';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const BANNER_WIDTH = SCREEN_WIDTH - 32;
const AUTO_SCROLL_INTERVAL = 5000; // 5 saniye

interface DynamicBannerProps {
  onBannerPress?: (banner: Banner) => void;
}

export default function DynamicBanner({ onBannerPress }: DynamicBannerProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';

  const [banners, setBanners] = useState<Banner[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const scrollViewRef = useRef<ScrollView>(null);
  const autoScrollTimer = useRef<NodeJS.Timeout | null>(null);

  // Banner'ları yükle
  useEffect(() => {
    loadBanners();
  }, [language]);

  const loadBanners = async () => {
    try {
      setLoading(true);
      const fetchedBanners = await fetchBanners();
      setBanners(fetchedBanners);
    } catch (error) {
      console.error('Banner load error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Auto scroll
  useEffect(() => {
    if (banners.length <= 1) return;

    autoScrollTimer.current = setInterval(() => {
      setActiveIndex((prev) => {
        const nextIndex = (prev + 1) % banners.length;
        scrollViewRef.current?.scrollTo({
          x: nextIndex * BANNER_WIDTH,
          animated: true,
        });
        return nextIndex;
      });
    }, AUTO_SCROLL_INTERVAL);

    return () => {
      if (autoScrollTimer.current) {
        clearInterval(autoScrollTimer.current);
      }
    };
  }, [banners.length]);

  // Scroll event handler
  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const index = Math.round(scrollPosition / BANNER_WIDTH);
    if (index !== activeIndex && index >= 0 && index < banners.length) {
      setActiveIndex(index);
    }
  };

  // Banner action handler
  const handleBannerPress = (banner: Banner) => {
    if (onBannerPress) {
      onBannerPress(banner);
      return;
    }

    switch (banner.actionType) {
      case 'screen':
        if (banner.actionValue) {
          router.push(`/(tabs)/${banner.actionValue}` as any);
        }
        break;
      case 'link':
        if (banner.actionValue) {
          // Linking.openURL(banner.actionValue);
        }
        break;
      case 'promo':
        // Promo modal aç veya özel işlem
        break;
      default:
        break;
    }
  };

  // Loading state
  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: isDark ? '#1e293b' : '#f1f5f9' }]}>
        <ActivityIndicator color="#10b981" />
      </View>
    );
  }

  // Banner yoksa fallback göster
  if (banners.length === 0) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#10b981', '#059669']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.fallbackBanner}
        >
          <View style={styles.bannerContent}>
            <View style={styles.textContainer}>
              <Text style={styles.title}>
                {language === 'en' ? 'Welcome to Auxite! 🎉' : 'Auxite\'e Hoş Geldiniz! 🎉'}
              </Text>
              <Text style={styles.subtitle}>
                {language === 'en' 
                  ? 'Digitize your precious metal investments' 
                  : 'Değerli metal yatırımlarınızı dijitalleştirin'}
              </Text>
            </View>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>NEW</Text>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        decelerationRate="fast"
        snapToInterval={BANNER_WIDTH}
        contentContainerStyle={{ paddingHorizontal: 0 }}
      >
        {banners.map((banner, index) => (
          <TouchableOpacity
            key={banner.id}
            activeOpacity={0.9}
            onPress={() => handleBannerPress(banner)}
            style={[styles.bannerWrapper, { width: BANNER_WIDTH }]}
          >
            {banner.imageUrl ? (
              <Image
                source={{ uri: banner.imageUrl }}
                style={styles.bannerImage}
                resizeMode="cover"
              />
            ) : (
              <View style={[styles.bannerGradient, { backgroundColor: banner.backgroundColor || '#10b981' }]}>
                <View style={styles.bannerContent}>
                  <View style={styles.textContainer}>
                    <Text style={[styles.title, { color: banner.textColor || '#fff' }]}>
                      {banner.title}
                    </Text>
                    {banner.subtitle && (
                      <Text style={[styles.subtitle, { color: banner.textColor ? `${banner.textColor}cc` : '#ffffffcc' }]}>
                        {banner.subtitle}
                      </Text>
                    )}
                  </View>
                  {banner.actionType !== 'none' && (
                    <View style={styles.arrowContainer}>
                      <Ionicons name="chevron-forward" size={20} color={banner.textColor || '#fff'} />
                    </View>
                  )}
                </View>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Indicators */}
      {banners.length > 1 && (
        <View style={styles.indicators}>
          {banners.map((_, index) => (
            <View
              key={index}
              style={[
                styles.indicator,
                {
                  backgroundColor: activeIndex === index 
                    ? '#10b981' 
                    : (isDark ? '#475569' : '#cbd5e1'),
                  width: activeIndex === index ? 20 : 6,
                },
              ]}
            />
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  loadingContainer: {
    height: 100,
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bannerWrapper: {
    marginHorizontal: 0,
  },
  bannerGradient: {
    height: 100,
    borderRadius: 12,
    marginHorizontal: 16,
    overflow: 'hidden',
  },
  bannerImage: {
    height: 100,
    borderRadius: 12,
    marginHorizontal: 16,
  },
  bannerContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 15,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
  },
  badge: {
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    color: '#10b981',
    fontSize: 10,
    fontWeight: '700',
  },
  arrowContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  indicators: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    gap: 6,
  },
  indicator: {
    height: 6,
    borderRadius: 3,
  },
  fallbackBanner: {
    height: 100,
    borderRadius: 12,
    marginHorizontal: 16,
    overflow: 'hidden',
  },
});
