// app/two-factor.tsx
// Two-Factor Authentication Setup Screen
// 6-Language Support | Dark/Light Mode | QR Code + Backup Codes

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  useColorScheme,
  ActivityIndicator,
  TextInput,
  Image,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useStore } from '@/stores/useStore';
import { API_URL } from '@/constants/api';

// ============================================
// TRANSLATIONS
// ============================================
const translations = {
  tr: {
    title: 'İki Faktörlü Doğrulama',
    subtitle: 'Hesabınızı ekstra güvenlik katmanıyla koruyun',
    twoFactorAuth: 'İki Faktörlü Doğrulama',
    enabled: 'Aktif',
    disabled: 'Kapalı',
    enable: 'Aktifleştir',
    disable: 'Kapat',
    backupCodesRemaining: 'Kalan yedek kod',
    enabledAt: 'Aktifleştirme tarihi',
    whatIs2FA: '2FA Nedir?',
    whatIs2FADesc: 'İki faktörlü doğrulama, hesabınıza giriş yaparken şifrenize ek olarak telefonunuzdaki bir uygulamadan kod girmenizi gerektirir.',
    scanQRCode: 'QR Kodu Tarayın',
    scanQRCodeDesc: 'Google Authenticator veya Authy uygulamasıyla tarayın',
    verificationCode: 'Doğrulama Kodu',
    verify: 'Doğrula',
    verifying: 'Doğrulanıyor...',
    verifyAndEnable: 'Doğrula ve Aktifleştir',
    cancel: 'İptal',
    twoFAEnabled: '2FA Aktifleştirildi!',
    saveBackupCodes: 'Yedek kodlarınızı güvenli bir yere kaydedin',
    backupCodes: 'Yedek Kodlar',
    copy: 'Kopyala',
    copied: 'Kopyalandı!',
    backupWarning: 'Bu kodları bir daha göremeyeceksiniz. Güvenli bir yere kaydedin!',
    done: 'Tamamla',
    disable2FA: '2FA\'yı Kapat',
    disable2FADesc: 'Doğrulama kodunuzu girerek 2FA\'yı kapatın',
    disableWarning: '2FA\'yı kapatmak hesabınızın güvenliğini azaltır.',
    enterCode: 'Kodu girin',
    processing: 'İşleniyor...',
    error: 'Hata',
    back: 'Geri',
    loading: 'Yükleniyor...',
  },
  en: {
    title: 'Two-Factor Authentication',
    subtitle: 'Protect your account with an extra layer of security',
    twoFactorAuth: 'Two-Factor Authentication',
    enabled: 'Enabled',
    disabled: 'Disabled',
    enable: 'Enable',
    disable: 'Disable',
    backupCodesRemaining: 'Backup codes remaining',
    enabledAt: 'Enabled at',
    whatIs2FA: 'What is 2FA?',
    whatIs2FADesc: 'Two-factor authentication requires you to enter a code from an app on your phone in addition to your password when logging in.',
    scanQRCode: 'Scan QR Code',
    scanQRCodeDesc: 'Scan with Google Authenticator or Authy app',
    verificationCode: 'Verification Code',
    verify: 'Verify',
    verifying: 'Verifying...',
    verifyAndEnable: 'Verify & Enable',
    cancel: 'Cancel',
    twoFAEnabled: '2FA Enabled!',
    saveBackupCodes: 'Save your backup codes in a safe place',
    backupCodes: 'Backup Codes',
    copy: 'Copy',
    copied: 'Copied!',
    backupWarning: 'You won\'t see these codes again. Save them somewhere safe!',
    done: 'Done',
    disable2FA: 'Disable 2FA',
    disable2FADesc: 'Enter your verification code to disable 2FA',
    disableWarning: 'Disabling 2FA reduces your account security.',
    enterCode: 'Enter code',
    processing: 'Processing...',
    error: 'Error',
    back: 'Back',
    loading: 'Loading...',
  },
  de: {
    title: 'Zwei-Faktor-Authentifizierung',
    subtitle: 'Schützen Sie Ihr Konto mit einer zusätzlichen Sicherheitsebene',
    twoFactorAuth: 'Zwei-Faktor-Authentifizierung',
    enabled: 'Aktiviert',
    disabled: 'Deaktiviert',
    enable: 'Aktivieren',
    disable: 'Deaktivieren',
    backupCodesRemaining: 'Verbleibende Backup-Codes',
    enabledAt: 'Aktiviert am',
    whatIs2FA: 'Was ist 2FA?',
    whatIs2FADesc: 'Die Zwei-Faktor-Authentifizierung erfordert zusätzlich zu Ihrem Passwort einen Code aus einer App.',
    scanQRCode: 'QR-Code scannen',
    scanQRCodeDesc: 'Mit Google Authenticator oder Authy scannen',
    verificationCode: 'Verifizierungscode',
    verify: 'Verifizieren',
    verifying: 'Verifizieren...',
    verifyAndEnable: 'Verifizieren & Aktivieren',
    cancel: 'Abbrechen',
    twoFAEnabled: '2FA Aktiviert!',
    saveBackupCodes: 'Speichern Sie Ihre Backup-Codes sicher',
    backupCodes: 'Backup-Codes',
    copy: 'Kopieren',
    copied: 'Kopiert!',
    backupWarning: 'Sie werden diese Codes nicht wieder sehen. Bewahren Sie sie sicher auf!',
    done: 'Fertig',
    disable2FA: '2FA Deaktivieren',
    disable2FADesc: 'Geben Sie Ihren Code ein, um 2FA zu deaktivieren',
    disableWarning: 'Das Deaktivieren von 2FA verringert die Kontosicherheit.',
    enterCode: 'Code eingeben',
    processing: 'Verarbeitung...',
    error: 'Fehler',
    back: 'Zurück',
    loading: 'Laden...',
  },
  fr: {
    title: 'Authentification à Deux Facteurs',
    subtitle: 'Protégez votre compte avec une couche de sécurité supplémentaire',
    twoFactorAuth: 'Authentification à Deux Facteurs',
    enabled: 'Activé',
    disabled: 'Désactivé',
    enable: 'Activer',
    disable: 'Désactiver',
    backupCodesRemaining: 'Codes de secours restants',
    enabledAt: 'Activé le',
    whatIs2FA: 'Qu\'est-ce que le 2FA?',
    whatIs2FADesc: 'L\'authentification à deux facteurs nécessite un code d\'une application en plus de votre mot de passe.',
    scanQRCode: 'Scanner le QR Code',
    scanQRCodeDesc: 'Scanner avec Google Authenticator ou Authy',
    verificationCode: 'Code de Vérification',
    verify: 'Vérifier',
    verifying: 'Vérification...',
    verifyAndEnable: 'Vérifier & Activer',
    cancel: 'Annuler',
    twoFAEnabled: '2FA Activé!',
    saveBackupCodes: 'Sauvegardez vos codes de secours',
    backupCodes: 'Codes de Secours',
    copy: 'Copier',
    copied: 'Copié!',
    backupWarning: 'Vous ne reverrez plus ces codes. Gardez-les en lieu sûr!',
    done: 'Terminé',
    disable2FA: 'Désactiver 2FA',
    disable2FADesc: 'Entrez votre code pour désactiver le 2FA',
    disableWarning: 'Désactiver le 2FA réduit la sécurité de votre compte.',
    enterCode: 'Entrer le code',
    processing: 'Traitement...',
    error: 'Erreur',
    back: 'Retour',
    loading: 'Chargement...',
  },
  ar: {
    title: 'المصادقة الثنائية',
    subtitle: 'احمِ حسابك بطبقة أمان إضافية',
    twoFactorAuth: 'المصادقة الثنائية',
    enabled: 'مفعّل',
    disabled: 'معطّل',
    enable: 'تفعيل',
    disable: 'تعطيل',
    backupCodesRemaining: 'أكواد النسخ الاحتياطي المتبقية',
    enabledAt: 'تم التفعيل في',
    whatIs2FA: 'ما هي المصادقة الثنائية؟',
    whatIs2FADesc: 'تتطلب المصادقة الثنائية إدخال رمز من تطبيق على هاتفك بالإضافة إلى كلمة المرور.',
    scanQRCode: 'امسح رمز QR',
    scanQRCodeDesc: 'امسح باستخدام Google Authenticator أو Authy',
    verificationCode: 'رمز التحقق',
    verify: 'تحقق',
    verifying: 'جارٍ التحقق...',
    verifyAndEnable: 'تحقق وفعّل',
    cancel: 'إلغاء',
    twoFAEnabled: 'تم تفعيل المصادقة الثنائية!',
    saveBackupCodes: 'احفظ أكواد النسخ الاحتياطي في مكان آمن',
    backupCodes: 'أكواد النسخ الاحتياطي',
    copy: 'نسخ',
    copied: 'تم النسخ!',
    backupWarning: 'لن ترى هذه الأكواد مرة أخرى. احفظها في مكان آمن!',
    done: 'تم',
    disable2FA: 'تعطيل المصادقة الثنائية',
    disable2FADesc: 'أدخل رمز التحقق لتعطيل المصادقة الثنائية',
    disableWarning: 'تعطيل المصادقة الثنائية يقلل من أمان حسابك.',
    enterCode: 'أدخل الرمز',
    processing: 'جارٍ المعالجة...',
    error: 'خطأ',
    back: 'رجوع',
    loading: 'جارٍ التحميل...',
  },
  ru: {
    title: 'Двухфакторная Аутентификация',
    subtitle: 'Защитите свой аккаунт дополнительным уровнем безопасности',
    twoFactorAuth: 'Двухфакторная Аутентификация',
    enabled: 'Включено',
    disabled: 'Отключено',
    enable: 'Включить',
    disable: 'Отключить',
    backupCodesRemaining: 'Осталось резервных кодов',
    enabledAt: 'Включено',
    whatIs2FA: 'Что такое 2FA?',
    whatIs2FADesc: 'Двухфакторная аутентификация требует ввода кода из приложения на телефоне в дополнение к паролю.',
    scanQRCode: 'Сканируйте QR-код',
    scanQRCodeDesc: 'Сканируйте с помощью Google Authenticator или Authy',
    verificationCode: 'Код Подтверждения',
    verify: 'Подтвердить',
    verifying: 'Проверка...',
    verifyAndEnable: 'Подтвердить и Включить',
    cancel: 'Отмена',
    twoFAEnabled: '2FA Включена!',
    saveBackupCodes: 'Сохраните резервные коды в безопасном месте',
    backupCodes: 'Резервные Коды',
    copy: 'Копировать',
    copied: 'Скопировано!',
    backupWarning: 'Вы больше не увидите эти коды. Сохраните их в безопасном месте!',
    done: 'Готово',
    disable2FA: 'Отключить 2FA',
    disable2FADesc: 'Введите код подтверждения для отключения 2FA',
    disableWarning: 'Отключение 2FA снижает безопасность вашего аккаунта.',
    enterCode: 'Введите код',
    processing: 'Обработка...',
    error: 'Ошибка',
    back: 'Назад',
    loading: 'Загрузка...',
  },
};

// ============================================
// TYPES
// ============================================
interface TwoFAStatus {
  enabled: boolean;
  enabledAt?: string;
  backupCodesRemaining?: number;
}

type Step = 'status' | 'setup' | 'verify' | 'backup' | 'disable';

// ============================================
// MAIN COMPONENT
// ============================================
export default function TwoFactorScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const { theme, language, walletAddress: storeWalletAddress } = useStore();

  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language as keyof typeof translations] || translations.en;
  const isRTL = language === 'ar';

  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(storeWalletAddress);
  const [status, setStatus] = useState<TwoFAStatus | null>(null);
  const [step, setStep] = useState<Step>('status');
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [verifyCode, setVerifyCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copiedBackup, setCopiedBackup] = useState(false);

  const inputRef = useRef<TextInput>(null);

  const colors = {
    background: isDark ? '#0F172A' : '#F8FAFC',
    surface: isDark ? '#1E293B' : '#FFFFFF',
    surfaceAlt: isDark ? '#334155' : '#F1F5F9',
    text: isDark ? '#FFFFFF' : '#0F172A',
    textSecondary: isDark ? '#94A3B8' : '#64748B',
    textMuted: isDark ? '#64748B' : '#94A3B8',
    primary: '#10B981',
    danger: '#EF4444',
    amber: '#F59E0B',
    border: isDark ? '#334155' : '#E2E8F0',
  };

  useEffect(() => {
    loadData();
  }, [storeWalletAddress]);

  const loadData = async () => {
    try {
      let address = storeWalletAddress;
      if (!address) {
        address = await AsyncStorage.getItem('auxite_wallet_address');
      }
      setWalletAddress(address);

      if (address) {
        await fetchStatus(address);
      }
    } catch (err) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStatus = async (address: string) => {
    try {
      const res = await fetch(`${API_URL}/api/security/2fa/status`, {
        headers: { 'x-wallet-address': address },
      });
      const data = await res.json();
      setStatus(data);
      setStep('status');
    } catch (err) {
      console.error('Status fetch error:', err);
    }
  };

  const startSetup = async () => {
    if (!walletAddress) return;

    setProcessing(true);
    setError(null);

    try {
      const res = await fetch(`${API_URL}/api/security/2fa/setup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-wallet-address': walletAddress,
        },
        body: JSON.stringify({}),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Setup failed');
      }

      setQrCode(data.qrCodeDataUrl);
      setBackupCodes(data.backupCodes || []);
      setStep('setup');
    } catch (err: any) {
      Alert.alert(t.error, err.message);
    } finally {
      setProcessing(false);
    }
  };

  const verifyAndEnable = async () => {
    if (verifyCode.length !== 6 || !walletAddress) {
      setError(t.enterCode);
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const res = await fetch(`${API_URL}/api/security/2fa/enable`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-wallet-address': walletAddress,
        },
        body: JSON.stringify({ code: verifyCode }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Verification failed');
      }

      setStep('backup');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const disable2FA = async () => {
    if (verifyCode.length !== 6 || !walletAddress) {
      setError(t.enterCode);
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const res = await fetch(`${API_URL}/api/security/2fa/disable`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-wallet-address': walletAddress,
        },
        body: JSON.stringify({ code: verifyCode }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Disable failed');
      }

      await fetchStatus(walletAddress);
      setVerifyCode('');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const copyBackupCodes = async () => {
    await Clipboard.setStringAsync(backupCodes.join('\n'));
    setCopiedBackup(true);
    setTimeout(() => setCopiedBackup(false), 2000);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(
      language === 'tr' ? 'tr-TR' : language === 'de' ? 'de-DE' : 'en-US',
      { year: 'numeric', month: 'short', day: 'numeric' }
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{t.title}</Text>
          <Text style={[styles.headerSubtitle, { color: colors.textSecondary }]}>{t.subtitle}</Text>
        </View>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* STATUS VIEW */}
        {step === 'status' && (
          <>
            {/* Status Card */}
            <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.statusRow}>
                <View style={[styles.iconCircle, { backgroundColor: status?.enabled ? colors.primary + '20' : colors.surfaceAlt }]}>
                  <Text style={styles.iconEmoji}>🔐</Text>
                </View>
                <View style={styles.statusTextContainer}>
                  <Text style={[styles.statusTitle, { color: colors.text }]}>{t.twoFactorAuth}</Text>
                  <Text style={[styles.statusValue, { color: status?.enabled ? colors.primary : colors.textMuted }]}>
                    {status?.enabled ? t.enabled : t.disabled}
                  </Text>
                </View>
                <TouchableOpacity
                  style={[
                    styles.actionButton,
                    { backgroundColor: status?.enabled ? colors.danger + '20' : colors.primary },
                  ]}
                  onPress={() => (status?.enabled ? setStep('disable') : startSetup())}
                  disabled={processing}
                >
                  {processing ? (
                    <ActivityIndicator size="small" color={status?.enabled ? colors.danger : '#FFF'} />
                  ) : (
                    <Text style={[styles.actionButtonText, { color: status?.enabled ? colors.danger : '#FFF' }]}>
                      {status?.enabled ? t.disable : t.enable}
                    </Text>
                  )}
                </TouchableOpacity>
              </View>

              {status?.enabled && (
                <View style={[styles.statusDetails, { borderTopColor: colors.border }]}>
                  <View style={styles.statusDetailRow}>
                    <Text style={[styles.statusDetailLabel, { color: colors.textSecondary }]}>
                      {t.backupCodesRemaining}
                    </Text>
                    <Text style={[styles.statusDetailValue, {
                      color: (status.backupCodesRemaining || 0) <= 2 ? colors.amber : colors.text
                    }]}>
                      {status.backupCodesRemaining || 0}
                    </Text>
                  </View>
                  {status.enabledAt && (
                    <View style={styles.statusDetailRow}>
                      <Text style={[styles.statusDetailLabel, { color: colors.textSecondary }]}>{t.enabledAt}</Text>
                      <Text style={[styles.statusDetailValue, { color: colors.text }]}>
                        {formatDate(status.enabledAt)}
                      </Text>
                    </View>
                  )}
                </View>
              )}
            </View>

            {/* Info Card */}
            {!status?.enabled && (
              <View style={[styles.infoCard, { backgroundColor: '#3B82F6' + '15', borderColor: '#3B82F6' + '30' }]}>
                <Ionicons name="information-circle" size={20} color="#3B82F6" />
                <View style={styles.infoTextContainer}>
                  <Text style={[styles.infoTitle, { color: '#3B82F6' }]}>{t.whatIs2FA}</Text>
                  <Text style={[styles.infoDesc, { color: colors.textSecondary }]}>{t.whatIs2FADesc}</Text>
                </View>
              </View>
            )}
          </>
        )}

        {/* SETUP VIEW - QR Code */}
        {step === 'setup' && qrCode && (
          <View style={styles.setupContainer}>
            <Text style={[styles.setupTitle, { color: colors.text }]}>{t.scanQRCode}</Text>
            <Text style={[styles.setupDesc, { color: colors.textSecondary }]}>{t.scanQRCodeDesc}</Text>

            {/* QR Code */}
            <View style={styles.qrContainer}>
              <Image source={{ uri: qrCode }} style={styles.qrImage} resizeMode="contain" />
            </View>

            {/* Verify Code Input */}
            <View style={styles.inputContainer}>
              <Text style={[styles.inputLabel, { color: colors.textSecondary }]}>{t.verificationCode}</Text>
              <TextInput
                ref={inputRef}
                style={[styles.codeInput, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.border }]}
                placeholder="000000"
                placeholderTextColor={colors.textMuted}
                value={verifyCode}
                onChangeText={(text) => setVerifyCode(text.replace(/\D/g, '').slice(0, 6))}
                keyboardType="number-pad"
                maxLength={6}
                textAlign="center"
              />
            </View>

            {error && (
              <View style={[styles.errorBox, { backgroundColor: colors.danger + '15' }]}>
                <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
              </View>
            )}

            {/* Actions */}
            <View style={styles.buttonsRow}>
              <TouchableOpacity
                style={[styles.cancelButton, { backgroundColor: colors.surfaceAlt }]}
                onPress={() => {
                  setStep('status');
                  setQrCode(null);
                  setVerifyCode('');
                  setError(null);
                }}
              >
                <Text style={[styles.cancelButtonText, { color: colors.text }]}>{t.cancel}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.primaryButton, verifyCode.length !== 6 && styles.buttonDisabled]}
                onPress={verifyAndEnable}
                disabled={verifyCode.length !== 6 || processing}
              >
                {processing ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <Text style={styles.primaryButtonText}>{t.verifyAndEnable}</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* BACKUP CODES VIEW */}
        {step === 'backup' && (
          <View style={styles.backupContainer}>
            <View style={[styles.successIcon, { backgroundColor: colors.primary + '20' }]}>
              <Text style={styles.successEmoji}>✅</Text>
            </View>
            <Text style={[styles.backupTitle, { color: colors.text }]}>{t.twoFAEnabled}</Text>
            <Text style={[styles.backupDesc, { color: colors.textSecondary }]}>{t.saveBackupCodes}</Text>

            {/* Backup Codes */}
            <View style={[styles.backupCodesCard, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
              <View style={styles.backupCodesHeader}>
                <Text style={[styles.backupCodesLabel, { color: colors.textSecondary }]}>{t.backupCodes}</Text>
                <TouchableOpacity onPress={copyBackupCodes}>
                  <Text style={[styles.copyLink, { color: colors.primary }]}>
                    {copiedBackup ? `✓ ${t.copied}` : t.copy}
                  </Text>
                </TouchableOpacity>
              </View>
              <View style={styles.backupCodesGrid}>
                {backupCodes.map((code, i) => (
                  <View key={i} style={[styles.backupCodeItem, { backgroundColor: colors.surface }]}>
                    <Text style={[styles.backupCodeText, { color: colors.text }]}>{code}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Warning */}
            <View style={[styles.warningBox, { backgroundColor: colors.amber + '15', borderColor: colors.amber + '30' }]}>
              <Text style={styles.warningEmoji}>⚠️</Text>
              <Text style={[styles.warningText, { color: colors.amber }]}>{t.backupWarning}</Text>
            </View>

            <TouchableOpacity
              style={styles.doneButton}
              onPress={() => {
                setStep('status');
                if (walletAddress) fetchStatus(walletAddress);
              }}
            >
              <Text style={styles.doneButtonText}>{t.done}</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* DISABLE VIEW */}
        {step === 'disable' && (
          <View style={styles.disableContainer}>
            <View style={[styles.disableIcon, { backgroundColor: colors.danger + '20' }]}>
              <Text style={styles.disableEmoji}>🔓</Text>
            </View>
            <Text style={[styles.disableTitle, { color: colors.text }]}>{t.disable2FA}</Text>
            <Text style={[styles.disableDesc, { color: colors.textSecondary }]}>{t.disable2FADesc}</Text>

            {/* Verify Code Input */}
            <View style={styles.inputContainer}>
              <Text style={[styles.inputLabel, { color: colors.textSecondary }]}>{t.verificationCode}</Text>
              <TextInput
                style={[styles.codeInput, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.danger + '50' }]}
                placeholder="000000"
                placeholderTextColor={colors.textMuted}
                value={verifyCode}
                onChangeText={(text) => setVerifyCode(text.replace(/\D/g, '').slice(0, 6))}
                keyboardType="number-pad"
                maxLength={6}
                textAlign="center"
              />
            </View>

            {error && (
              <View style={[styles.errorBox, { backgroundColor: colors.danger + '15' }]}>
                <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
              </View>
            )}

            {/* Warning */}
            <View style={[styles.warningBox, { backgroundColor: colors.danger + '15', borderColor: colors.danger + '30' }]}>
              <Text style={styles.warningEmoji}>⚠️</Text>
              <Text style={[styles.warningText, { color: colors.danger }]}>{t.disableWarning}</Text>
            </View>

            {/* Actions */}
            <View style={styles.buttonsRow}>
              <TouchableOpacity
                style={[styles.cancelButton, { backgroundColor: colors.surfaceAlt }]}
                onPress={() => {
                  setStep('status');
                  setVerifyCode('');
                  setError(null);
                }}
              >
                <Text style={[styles.cancelButtonText, { color: colors.text }]}>{t.cancel}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.dangerButton, verifyCode.length !== 6 && styles.buttonDisabled]}
                onPress={disable2FA}
                disabled={verifyCode.length !== 6 || processing}
              >
                {processing ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <Text style={styles.dangerButtonText}>{t.disable2FA}</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  backButton: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  headerTextContainer: { flex: 1, marginLeft: 8 },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  headerSubtitle: { fontSize: 12, marginTop: 2 },
  content: { flex: 1, paddingHorizontal: 16 },

  // Status
  card: { borderRadius: 16, borderWidth: 1, padding: 16, marginBottom: 16 },
  statusRow: { flexDirection: 'row', alignItems: 'center' },
  iconCircle: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  iconEmoji: { fontSize: 24 },
  statusTextContainer: { flex: 1, marginLeft: 12 },
  statusTitle: { fontSize: 16, fontWeight: '600' },
  statusValue: { fontSize: 13, marginTop: 2 },
  actionButton: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10 },
  actionButtonText: { fontSize: 13, fontWeight: '600' },
  statusDetails: { marginTop: 16, paddingTop: 16, borderTopWidth: 1 },
  statusDetailRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  statusDetailLabel: { fontSize: 13 },
  statusDetailValue: { fontSize: 13, fontWeight: '500' },

  // Info Card
  infoCard: { flexDirection: 'row', padding: 14, borderRadius: 12, borderWidth: 1, gap: 10, marginBottom: 16 },
  infoTextContainer: { flex: 1 },
  infoTitle: { fontSize: 13, fontWeight: '600', marginBottom: 4 },
  infoDesc: { fontSize: 12, lineHeight: 18 },

  // Setup
  setupContainer: { alignItems: 'center', paddingTop: 20 },
  setupTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  setupDesc: { fontSize: 13, marginBottom: 24 },
  qrContainer: { backgroundColor: '#FFFFFF', padding: 16, borderRadius: 16, marginBottom: 24 },
  qrImage: { width: 200, height: 200 },
  inputContainer: { width: '100%', marginBottom: 16 },
  inputLabel: { fontSize: 13, marginBottom: 8 },
  codeInput: { fontSize: 28, fontWeight: '700', paddingVertical: 16, borderRadius: 12, borderWidth: 1, letterSpacing: 8 },
  errorBox: { width: '100%', padding: 12, borderRadius: 10, marginBottom: 16 },
  errorText: { fontSize: 13 },
  buttonsRow: { flexDirection: 'row', gap: 12, width: '100%' },
  cancelButton: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  cancelButtonText: { fontSize: 15, fontWeight: '600' },
  primaryButton: { flex: 1, backgroundColor: '#10B981', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  primaryButtonText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
  buttonDisabled: { opacity: 0.5 },

  // Backup
  backupContainer: { alignItems: 'center', paddingTop: 20 },
  successIcon: { width: 64, height: 64, borderRadius: 32, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  successEmoji: { fontSize: 32 },
  backupTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  backupDesc: { fontSize: 13, marginBottom: 24 },
  backupCodesCard: { width: '100%', padding: 16, borderRadius: 14, borderWidth: 1, marginBottom: 16 },
  backupCodesHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  backupCodesLabel: { fontSize: 13 },
  copyLink: { fontSize: 12, fontWeight: '500' },
  backupCodesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  backupCodeItem: { width: '48%', padding: 10, borderRadius: 8, alignItems: 'center' },
  backupCodeText: { fontSize: 14, fontFamily: 'monospace', fontWeight: '500' },
  warningBox: { flexDirection: 'row', width: '100%', padding: 12, borderRadius: 10, borderWidth: 1, gap: 8, marginBottom: 20 },
  warningEmoji: { fontSize: 16 },
  warningText: { flex: 1, fontSize: 12, lineHeight: 18 },
  doneButton: { width: '100%', backgroundColor: '#10B981', paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  doneButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },

  // Disable
  disableContainer: { alignItems: 'center', paddingTop: 20 },
  disableIcon: { width: 64, height: 64, borderRadius: 32, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  disableEmoji: { fontSize: 32 },
  disableTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  disableDesc: { fontSize: 13, marginBottom: 24 },
  dangerButton: { flex: 1, backgroundColor: '#EF4444', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  dangerButtonText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});
