// app/wallet-onboarding.tsx
// WalletOnboarding Sayfası - Expo Router

import React from 'react';
import { useRouter } from 'expo-router';
import WalletOnboarding from '../components/WalletOnboarding';
import { useStore } from '@/stores/useStore';

export default function WalletOnboardingScreen() {
  const router = useRouter();
  const { language, setWalletAddress } = useStore();

  const handleWalletReady = (address: string) => {
    console.log('Wallet ready:', address);
    // Global state'i güncelle - bu isConnected'ı da true yapar
    setWalletAddress(address);
    // Ana sayfaya yönlendir
    router.replace('/(tabs)');
  };

  return (
    <WalletOnboarding
      lang={language as 'tr' | 'en' | 'de' | 'fr' | 'ar' | 'ru'}
      onWalletReady={handleWalletReady}
    />
  );
}
