// app/(auth)/register.tsx
// Register Screen

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useStore } from '@/stores/useStore';

const translations = {
  tr: {
    createAccount: 'Hesap Oluştur',
    subtitle: 'Auxite ailesine katılın',
    fullName: 'Ad Soyad',
    fullNamePlaceholder: 'Ahmet Yılmaz',
    email: 'E-posta',
    emailPlaceholder: 'ornek@email.com',
    password: 'Şifre',
    passwordPlaceholder: 'En az 8 karakter',
    confirmPassword: 'Şifre Tekrar',
    confirmPasswordPlaceholder: 'Şifrenizi tekrar girin',
    termsAgree: 'Kayıt olarak ',
    termsLink: 'Kullanım Şartları',
    and: ' ve ',
    privacyLink: 'Gizlilik Politikası',
    termsEnd: "'nı kabul ediyorum",
    register: 'Kayıt Ol',
    registering: 'Kayıt yapılıyor...',
    hasAccount: 'Zaten hesabınız var mı?',
    login: 'Giriş Yap',
    invalidName: 'Ad soyad girin',
    invalidEmail: 'Geçerli bir e-posta girin',
    invalidPassword: 'Şifre en az 8 karakter, büyük/küçük harf ve rakam içermeli',
    passwordMismatch: 'Şifreler eşleşmiyor',
    acceptTerms: 'Kullanım şartlarını kabul etmelisiniz',
  },
  en: {
    createAccount: 'Create Account',
    subtitle: 'Join the Auxite family',
    fullName: 'Full Name',
    fullNamePlaceholder: 'John Doe',
    email: 'Email',
    emailPlaceholder: 'example@email.com',
    password: 'Password',
    passwordPlaceholder: 'At least 8 characters',
    confirmPassword: 'Confirm Password',
    confirmPasswordPlaceholder: 'Re-enter your password',
    termsAgree: 'By registering, I agree to the ',
    termsLink: 'Terms of Service',
    and: ' and ',
    privacyLink: 'Privacy Policy',
    termsEnd: '',
    register: 'Sign Up',
    registering: 'Creating account...',
    hasAccount: 'Already have an account?',
    login: 'Sign In',
    invalidName: 'Enter your full name',
    invalidEmail: 'Enter a valid email',
    invalidPassword: 'Password must be at least 8 characters with uppercase, lowercase and number',
    passwordMismatch: 'Passwords do not match',
    acceptTerms: 'You must accept the terms of service',
  },
  de: {
    createAccount: 'Konto erstellen',
    subtitle: 'Werden Sie Teil der Auxite-Familie',
    fullName: 'Vollständiger Name',
    fullNamePlaceholder: 'Max Mustermann',
    email: 'E-Mail',
    emailPlaceholder: 'beispiel@email.com',
    password: 'Passwort',
    passwordPlaceholder: 'Mindestens 8 Zeichen',
    confirmPassword: 'Passwort bestätigen',
    confirmPasswordPlaceholder: 'Passwort erneut eingeben',
    termsAgree: 'Mit der Registrierung akzeptiere ich die ',
    termsLink: 'Nutzungsbedingungen',
    and: ' und ',
    privacyLink: 'Datenschutzrichtlinie',
    termsEnd: '',
    register: 'Registrieren',
    registering: 'Konto wird erstellt...',
    hasAccount: 'Bereits ein Konto?',
    login: 'Anmelden',
    invalidName: 'Geben Sie Ihren Namen ein',
    invalidEmail: 'Geben Sie eine gültige E-Mail ein',
    invalidPassword: 'Passwort muss mindestens 8 Zeichen mit Groß-, Kleinbuchstaben und Zahl enthalten',
    passwordMismatch: 'Passwörter stimmen nicht überein',
    acceptTerms: 'Sie müssen die Nutzungsbedingungen akzeptieren',
  },
  fr: {
    createAccount: 'Créer un compte',
    subtitle: 'Rejoignez la famille Auxite',
    fullName: 'Nom complet',
    fullNamePlaceholder: 'Jean Dupont',
    email: 'E-mail',
    emailPlaceholder: 'exemple@email.com',
    password: 'Mot de passe',
    passwordPlaceholder: 'Au moins 8 caractères',
    confirmPassword: 'Confirmer le mot de passe',
    confirmPasswordPlaceholder: 'Ressaisissez votre mot de passe',
    termsAgree: "En m'inscrivant, j'accepte les ",
    termsLink: "Conditions d'utilisation",
    and: ' et la ',
    privacyLink: 'Politique de confidentialité',
    termsEnd: '',
    register: "S'inscrire",
    registering: 'Création du compte...',
    hasAccount: 'Vous avez déjà un compte?',
    login: 'Se connecter',
    invalidName: 'Entrez votre nom complet',
    invalidEmail: 'Entrez un e-mail valide',
    invalidPassword: 'Le mot de passe doit contenir au moins 8 caractères avec majuscule, minuscule et chiffre',
    passwordMismatch: 'Les mots de passe ne correspondent pas',
    acceptTerms: 'Vous devez accepter les conditions',
  },
  ar: {
    createAccount: 'إنشاء حساب',
    subtitle: 'انضم إلى عائلة Auxite',
    fullName: 'الاسم الكامل',
    fullNamePlaceholder: 'أحمد محمد',
    email: 'البريد الإلكتروني',
    emailPlaceholder: 'example@email.com',
    password: 'كلمة المرور',
    passwordPlaceholder: '8 أحرف على الأقل',
    confirmPassword: 'تأكيد كلمة المرور',
    confirmPasswordPlaceholder: 'أعد إدخال كلمة المرور',
    termsAgree: 'بالتسجيل، أوافق على ',
    termsLink: 'شروط الخدمة',
    and: ' و',
    privacyLink: 'سياسة الخصوصية',
    termsEnd: '',
    register: 'إنشاء حساب',
    registering: 'جاري إنشاء الحساب...',
    hasAccount: 'لديك حساب بالفعل؟',
    login: 'تسجيل الدخول',
    invalidName: 'أدخل اسمك الكامل',
    invalidEmail: 'أدخل بريد إلكتروني صالح',
    invalidPassword: 'كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل مع حروف كبيرة وصغيرة وأرقام',
    passwordMismatch: 'كلمات المرور غير متطابقة',
    acceptTerms: 'يجب قبول شروط الخدمة',
  },
  ru: {
    createAccount: 'Создать аккаунт',
    subtitle: 'Присоединяйтесь к семье Auxite',
    fullName: 'Полное имя',
    fullNamePlaceholder: 'Иван Иванов',
    email: 'Эл. почта',
    emailPlaceholder: 'example@email.com',
    password: 'Пароль',
    passwordPlaceholder: 'Минимум 8 символов',
    confirmPassword: 'Подтвердите пароль',
    confirmPasswordPlaceholder: 'Введите пароль повторно',
    termsAgree: 'Регистрируясь, я принимаю ',
    termsLink: 'Условия использования',
    and: ' и ',
    privacyLink: 'Политику конфиденциальности',
    termsEnd: '',
    register: 'Зарегистрироваться',
    registering: 'Создание аккаунта...',
    hasAccount: 'Уже есть аккаунт?',
    login: 'Войти',
    invalidName: 'Введите ваше имя',
    invalidEmail: 'Введите корректный email',
    invalidPassword: 'Пароль должен содержать минимум 8 символов, заглавные и строчные буквы и цифры',
    passwordMismatch: 'Пароли не совпадают',
    acceptTerms: 'Вы должны принять условия использования',
  },
};

export default function RegisterScreen() {
  const colorScheme = useColorScheme();
  const router = useRouter();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language as keyof typeof translations] || translations.en;

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePassword = (pwd: string) => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(pwd);

  const handleRegister = async () => {
    setError('');

    if (!fullName.trim()) {
      setError(t.invalidName);
      return;
    }

    if (!validateEmail(email)) {
      setError(t.invalidEmail);
      return;
    }

    if (!validatePassword(password)) {
      setError(t.invalidPassword);
      return;
    }

    if (password !== confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    if (!termsAccepted) {
      setError(t.acceptTerms);
      return;
    }

    setIsLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      router.push('/auth/verify-email');
    } catch (err) {
      setError('Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Back Button */}
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={isDark ? '#fff' : '#0f172a'} />
        </TouchableOpacity>

        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: isDark ? '#fff' : '#0f172a' }]}>
            {t.createAccount}
          </Text>
          <Text style={[styles.subtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>
            {t.subtitle}
          </Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          {/* Full Name */}
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.fullName}</Text>
            <View style={[styles.inputContainer, { backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
              <Ionicons name="person-outline" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              <TextInput
                style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                placeholder={t.fullNamePlaceholder}
                placeholderTextColor={isDark ? '#475569' : '#cbd5e1'}
                value={fullName}
                onChangeText={setFullName}
                autoCapitalize="words"
              />
            </View>
          </View>

          {/* Email */}
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.email}</Text>
            <View style={[styles.inputContainer, { backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
              <Ionicons name="mail-outline" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              <TextInput
                style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                placeholder={t.emailPlaceholder}
                placeholderTextColor={isDark ? '#475569' : '#cbd5e1'}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
          </View>

          {/* Password */}
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.password}</Text>
            <View style={[styles.inputContainer, { backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
              <Ionicons name="lock-closed-outline" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              <TextInput
                style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                placeholder={t.passwordPlaceholder}
                placeholderTextColor={isDark ? '#475569' : '#cbd5e1'}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <Ionicons name={showPassword ? 'eye-outline' : 'eye-off-outline'} size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Confirm Password */}
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.confirmPassword}</Text>
            <View style={[styles.inputContainer, { backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
              <Ionicons name="lock-closed-outline" size={20} color={isDark ? '#64748b' : '#94a3b8'} />
              <TextInput
                style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                placeholder={t.confirmPasswordPlaceholder}
                placeholderTextColor={isDark ? '#475569' : '#cbd5e1'}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry={!showPassword}
              />
            </View>
          </View>

          {/* Terms Checkbox */}
          <TouchableOpacity
            style={styles.termsContainer}
            onPress={() => setTermsAccepted(!termsAccepted)}
            activeOpacity={0.7}
          >
            <View style={[styles.checkbox, termsAccepted && styles.checkboxChecked, { borderColor: isDark ? '#334155' : '#e2e8f0' }]}>
              {termsAccepted && <Ionicons name="checkmark" size={14} color="#fff" />}
            </View>
            <Text style={[styles.termsText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {t.termsAgree}
              <Text style={styles.termsLink} onPress={() => router.push('/legal/terms')}>{t.termsLink}</Text>
              {t.and}
              <Text style={styles.termsLink} onPress={() => router.push('/legal/privacy')}>{t.privacyLink}</Text>
              {t.termsEnd}
            </Text>
          </TouchableOpacity>

          {/* Error */}
          {error ? (
            <View style={styles.errorContainer}>
              <Ionicons name="alert-circle" size={16} color="#ef4444" />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          {/* Register Button */}
          <TouchableOpacity
            style={styles.registerButton}
            onPress={handleRegister}
            disabled={isLoading}
            activeOpacity={0.8}
          >
            <LinearGradient colors={['#10b981', '#059669']} style={styles.registerButtonGradient}>
              {isLoading ? (
                <>
                  <ActivityIndicator size="small" color="#fff" />
                  <Text style={styles.registerButtonText}>{t.registering}</Text>
                </>
              ) : (
                <Text style={styles.registerButtonText}>{t.register}</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Login Link */}
        <View style={styles.loginContainer}>
          <Text style={[styles.loginText, { color: isDark ? '#94a3b8' : '#64748b' }]}>
            {t.hasAccount}
          </Text>
          <TouchableOpacity onPress={() => router.push('/auth/login')}>
            <Text style={styles.loginLink}> {t.login}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { flexGrow: 1, paddingHorizontal: 24, paddingTop: 20, paddingBottom: 40 },
  backButton: { width: 40, height: 40, justifyContent: 'center', marginBottom: 16 },
  header: { marginBottom: 28 },
  title: { fontSize: 26, fontWeight: '700', marginBottom: 8 },
  subtitle: { fontSize: 15 },
  form: { marginBottom: 24 },
  inputGroup: { marginBottom: 16 },
  label: { fontSize: 13, fontWeight: '600', marginBottom: 8 },
  inputContainer: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, height: 52, gap: 10 },
  input: { flex: 1, fontSize: 15 },
  termsContainer: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 20, gap: 10 },
  checkbox: { width: 22, height: 22, borderWidth: 2, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  checkboxChecked: { backgroundColor: '#10b981', borderColor: '#10b981' },
  termsText: { flex: 1, fontSize: 13, lineHeight: 20 },
  termsLink: { color: '#10b981', fontWeight: '600' },
  errorContainer: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fef2f2', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 10, marginBottom: 16 },
  errorText: { color: '#ef4444', fontSize: 13, flex: 1 },
  registerButton: { borderRadius: 12, overflow: 'hidden' },
  registerButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, gap: 8 },
  registerButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  loginContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  loginText: { fontSize: 14 },
  loginLink: { color: '#10b981', fontSize: 14, fontWeight: '600' },
});
