// services/api.ts
// API functions for Auxite Mobile

import { API_URL } from '@/constants/api';
const API_BASE = API_URL;
const WALLET_API = `${API_URL}/api`;

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface UserBalance {
  auxm: number;
  bonusAuxm: number;
  totalAuxm: number;
  auxg: number;
  auxs: number;
  auxpt: number;
  auxpd: number;
  eth: number;
  btc: number;
  xrp: number;
  sol: number;
  usdt: number;
  usd: number;
}

export interface TradeResult {
  success: boolean;
  error?: string;
  transaction?: {
    id: string;
    type: 'buy' | 'sell';
    fromToken: string;
    toToken: string;
    fromAmount: number;
    toAmount: number;
    price: number;
    timestamp: string;
    txHash?: string;
  };
}

export interface TradePreview {
  fromToken: string;
  toToken: string;
  fromAmount: number;
  toAmount: number;
  price: number;
  fee: number;
  total: number;
}

export interface LimitOrder {
  id: string;
  address: string;
  type: 'buy' | 'sell';
  metal: string;
  grams: number;
  limitPrice: number;
  paymentMethod: string;
  status: 'pending' | 'filled' | 'cancelled' | 'expired';
  filledGrams: number;
  createdAt: string;
  expiresAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  type: string;
  fromToken?: string;
  toToken?: string;
  fromAmount?: number;
  toAmount?: number;
  amount?: number;
  token?: string;
  status: 'pending' | 'completed' | 'failed';
  txHash?: string;
  createdAt: string;
}

export interface StakePosition {
  id: string;
  metal: string;
  amount: number;
  duration: number;
  startDate: string;
  endDate: string;
  apy: number;
  status: 'active' | 'completed' | 'withdrawn';
  reward?: number;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECURITY API
// ═══════════════════════════════════════════════════════════════════════════

export async function get2FAStatus(address: string): Promise<{ enabled: boolean; method: string | null }> {
  return { enabled: false, method: null };
}

export async function getBiometricStatus(address: string): Promise<{ enabled: boolean }> {
  return { enabled: false };
}

export async function getSessions(address: string): Promise<Array<{
  id: string;
  device: string;
  location: string;
  lastActive: string;
  current: boolean;
}>> {
  return [{
    id: '1',
    device: 'Current Device',
    location: 'Unknown',
    lastActive: new Date().toISOString(),
    current: true,
  }];
}

export async function getDevices(address: string): Promise<Array<{
  id: string;
  name: string;
  type: string;
  lastUsed: string;
  trusted: boolean;
}>> {
  return [{
    id: '1',
    name: 'Current Device',
    type: 'mobile',
    lastUsed: new Date().toISOString(),
    trusted: true,
  }];
}

export async function getSecurityLogs(address: string): Promise<Array<{
  id: string;
  action: string;
  timestamp: string;
  ip: string;
  success: boolean;
}>> {
  return [];
}

export async function enable2FA(address: string, method: 'authenticator' | 'sms'): Promise<{ 
  success: boolean; 
  secret?: string;
  qrCode?: string;
}> {
  return { success: true, secret: 'MOCK', qrCode: '' };
}

export async function disable2FA(address: string, code: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function enableBiometric(address: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function disableBiometric(address: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function revokeSession(sessionId: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function revokeAllSessions(address: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function removeDevice(deviceId: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function trustDevice(deviceId: string): Promise<{ success: boolean }> {
  return { success: true };
}

// ═══════════════════════════════════════════════════════════════════════════
// BALANCE API
// ═══════════════════════════════════════════════════════════════════════════

export async function getBalance(address: string): Promise<UserBalance> {
  try {
    const response = await fetch(`${WALLET_API}/user/balance?address=${address}`);
    const data = await response.json();
    
    if (data.success && data.balances) {
      return {
        auxm: data.balances.auxm || 0,
        bonusAuxm: data.balances.bonusAuxm || 0,
        totalAuxm: data.balances.totalAuxm || (data.balances.auxm || 0) + (data.balances.bonusAuxm || 0),
        auxg: data.balances.auxg || 0,
        auxs: data.balances.auxs || 0,
        auxpt: data.balances.auxpt || 0,
        auxpd: data.balances.auxpd || 0,
        eth: data.balances.eth || 0,
        btc: data.balances.btc || 0,
        xrp: data.balances.xrp || 0,
        sol: data.balances.sol || 0,
        usdt: data.balances.usdt || 0,
        usd: data.balances.usd || 0,
      };
    }
    
    return getEmptyBalance();
  } catch (error) {
    console.error('getBalance error:', error);
    return getEmptyBalance();
  }
}

function getEmptyBalance(): UserBalance {
  return {
    auxm: 0, bonusAuxm: 0, totalAuxm: 0,
    auxg: 0, auxs: 0, auxpt: 0, auxpd: 0,
    eth: 0, btc: 0, xrp: 0, sol: 0,
    usdt: 0, usd: 0,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// TRADE API
// ═══════════════════════════════════════════════════════════════════════════

export async function getTradePreview(params: {
  type: 'buy' | 'sell';
  fromToken: string;
  toToken: string;
  amount: number;
}): Promise<TradePreview | null> {
  try {
    const query = new URLSearchParams({
      type: params.type,
      fromToken: params.fromToken,
      toToken: params.toToken,
      amount: params.amount.toString(),
    });
    
    const response = await fetch(`${WALLET_API}/trade?${query}`);
    const data = await response.json();
    
    if (data.success) {
      return data.preview;
    }
    return null;
  } catch (error) {
    console.error('getTradePreview error:', error);
    return null;
  }
}

export async function executeTrade(params: {
  address: string;
  type: 'buy' | 'sell';
  fromToken: string;
  toToken: string;
  fromAmount: number;
  executeOnChain?: boolean;
  email?: string;
  holderName?: string;
}): Promise<TradeResult> {
  try {
    const response = await fetch(`${WALLET_API}/trade`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    
    const data = await response.json();
    
    if (data.success) {
      return {
        success: true,
        transaction: data.transaction,
      };
    }
    
    return {
      success: false,
      error: data.error || 'Trade failed',
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || 'Network error',
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// LIMIT ORDERS API
// ═══════════════════════════════════════════════════════════════════════════

export async function getLimitOrders(
  address: string, 
  status?: 'pending' | 'filled' | 'cancelled' | 'expired'
): Promise<LimitOrder[]> {
  try {
    const query = new URLSearchParams({ address });
    if (status) query.append('status', status);
    
    const response = await fetch(`${WALLET_API}/orders/limit?${query}`);
    const data = await response.json();
    
    if (data.success) {
      return data.orders || [];
    }
    return [];
  } catch (error) {
    console.error('getLimitOrders error:', error);
    return [];
  }
}

export async function createLimitOrder(params: {
  address: string;
  type: 'buy' | 'sell';
  metal: string;
  grams: number;
  limitPrice: number;
  paymentMethod?: string;
}): Promise<{ success: boolean; order?: LimitOrder; error?: string }> {
  try {
    const response = await fetch(`${WALLET_API}/orders/limit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    
    const data = await response.json();
    return data;
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function cancelLimitOrder(
  orderId: string, 
  address: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch(`${WALLET_API}/orders/limit`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, address }),
    });
    
    const data = await response.json();
    return data;
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// TRANSACTIONS API
// ═══════════════════════════════════════════════════════════════════════════

export async function getTransactions(
  address: string,
  limit: number = 20
): Promise<Transaction[]> {
  try {
    const response = await fetch(
      `${WALLET_API}/transactions?address=${address}&limit=${limit}`
    );
    const data = await response.json();
    
    if (data.success || data.transactions) {
      return data.transactions || [];
    }
    return [];
  } catch (error) {
    console.error('getTransactions error:', error);
    return [];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// STAKING API
// ═══════════════════════════════════════════════════════════════════════════

export async function getStakePositions(address: string): Promise<StakePosition[]> {
  try {
    const response = await fetch(`${WALLET_API}/stakes?address=${address}`);
    const data = await response.json();
    
    if (data.success) {
      return data.stakes || [];
    }
    return [];
  } catch (error) {
    console.error('getStakePositions error:', error);
    return [];
  }
}

export async function createStake(params: {
  address: string;
  metal: string;
  amount: number;
  duration: number;
  apy?: string;
  email?: string;
  holderName?: string;
}): Promise<{ success: boolean; stake?: StakePosition; agreementNo?: string; agreementUrl?: string; error?: string }> {
  try {
    const response = await fetch(`${WALLET_API}/stakes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    const data = await response.json();
    return data;
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}




















// ═══════════════════════════════════════════════════════════════════════════
// ALLOCATIONS API
// ═══════════════════════════════════════════════════════════════════════════

export async function getAllocations(address: string): Promise<any[]> {
  try {
    const response = await fetch(`${WALLET_API}/allocations?address=${address}`);
    const data = await response.json();
    
    if (data.success) {
      return data.allocations || [];
    }
    return [];
  } catch (error) {
    console.error('getAllocations error:', error);
    return [];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// USER API
// ═══════════════════════════════════════════════════════════════════════════

export async function getUserProfile(address: string): Promise<{
  address: string;
  email?: string;
  name?: string;
  avatar?: string;
  kycStatus: 'none' | 'pending' | 'verified' | 'rejected';
  createdAt: string;
}> {
  return {
    address,
    kycStatus: 'none',
    createdAt: new Date().toISOString(),
  };
}

export async function updateUserProfile(address: string, data: {
  email?: string;
  name?: string;
}): Promise<{ success: boolean }> {
  return { success: true };
}

// ═══════════════════════════════════════════════════════════════════════════
// REFERRAL API
// ═══════════════════════════════════════════════════════════════════════════

export async function getReferralInfo(address: string): Promise<{
  code: string;
  totalReferrals: number;
  totalEarnings: string;
  pendingEarnings: string;
}> {
  try {
    const response = await fetch(`${WALLET_API}/referral?address=${address}`);
    const data = await response.json();
    
    if (data.success) {
      return {
        code: data.referralCode || '',
        totalReferrals: data.stats?.totalReferrals || 0,
        totalEarnings: data.stats?.totalEarnings?.toString() || '0',
        pendingEarnings: data.stats?.pendingEarnings?.toString() || '0',
      };
    }
    return { code: '', totalReferrals: 0, totalEarnings: '0', pendingEarnings: '0' };
  } catch (error) {
    return { code: '', totalReferrals: 0, totalEarnings: '0', pendingEarnings: '0' };
  }
}

export async function getReferralHistory(address: string): Promise<Array<{
  id: string;
  referredAddress: string;
  date: string;
  reward: string;
  status: 'pending' | 'completed';
}>> {
  return [];
}

// ═══════════════════════════════════════════════════════════════════════════
// PRICE API
// ═══════════════════════════════════════════════════════════════════════════

export async function getTokenPrices(): Promise<Array<{
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
}>> {
  try {
    const response = await fetch(`${WALLET_API}/metals`);
    const data = await response.json();
    
    if (data.ok && data.data) {
      return data.data.map((m: any) => ({
        symbol: m.symbol,
        price: m.priceOz / 31.1035,
        change24h: data.changes?.[m.symbol] || 0,
        volume24h: 0,
      }));
    }
    return [];
  } catch (error) {
    return [];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// WALLET API (Legacy)
// ═══════════════════════════════════════════════════════════════════════════

export async function getWalletBalance(address: string): Promise<{
  eth: string;
  tokens: Array<{ symbol: string; balance: string; usdValue: string }>;
}> {
  const balance = await getBalance(address);
  return {
    eth: balance.eth.toString(),
    tokens: [
      { symbol: 'AUXG', balance: balance.auxg.toString(), usdValue: '0' },
      { symbol: 'AUXS', balance: balance.auxs.toString(), usdValue: '0' },
      { symbol: 'AUXPT', balance: balance.auxpt.toString(), usdValue: '0' },
      { symbol: 'AUXPD', balance: balance.auxpd.toString(), usdValue: '0' },
    ],
  };
}

export async function getTransactionHistory(address: string, limit: number = 20): Promise<Array<{
  id: string;
  type: 'send' | 'receive' | 'swap' | 'stake';
  amount: string;
  token: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
  hash: string;
}>> {
  const txs = await getTransactions(address, limit);
  return txs.map(tx => ({
    id: tx.id,
    type: (tx.type as any) || 'swap',
    amount: (tx.fromAmount || tx.amount || 0).toString(),
    token: tx.fromToken || tx.token || '',
    timestamp: tx.createdAt,
    status: tx.status,
    hash: tx.txHash || '',
  }));
}

// ═══════════════════════════════════════════════════════════════════════════
// DEFAULT EXPORT
// ═══════════════════════════════════════════════════════════════════════════

export default {
  // Security
  get2FAStatus,
  getBiometricStatus,
  getSessions,
  getDevices,
  getSecurityLogs,
  enable2FA,
  disable2FA,
  enableBiometric,
  disableBiometric,
  revokeSession,
  revokeAllSessions,
  removeDevice,
  trustDevice,
  // Balance
  getBalance,
  // Trade
  getTradePreview,
  executeTrade,
  // Orders
  getLimitOrders,
  createLimitOrder,
  cancelLimitOrder,
  // Transactions
  getTransactions,
  // Staking
  getStakePositions,
  createStake,
  // Allocations
  getAllocations,
  // User
  getUserProfile,
  updateUserProfile,
  // Referral
  getReferralInfo,
  getReferralHistory,
  // Prices
  getTokenPrices,
  // Legacy
  getWalletBalance,
  getTransactionHistory,
};

// ═══════════════════════════════════════════════════════════════════════════
// QUOTE SYSTEM
// ═══════════════════════════════════════════════════════════════════════════
export interface Quote {
  id: string;
  pricePerGram: number;
  spreadPercent: number;
  expiresAt: number;
  timeRemaining: number;
}

export interface QuoteResponse {
  success: boolean;
  quote?: Quote;
  error?: string;
}

// Get quote for trade
export async function getQuote(params: {
  type: 'buy' | 'sell';
  metal: string;
  grams: number;
  address: string;
}): Promise<QuoteResponse> {
  try {
    const response = await fetch(`${WALLET_API}/quote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: params.type,
        metal: params.metal,
        grams: params.grams,
        address: params.address,
      }),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      return { success: false, error: data.error || 'Quote failed' };
    }
    
    return { 
      success: true, 
      quote: data.quote || data 
    };
  } catch (error: any) {
    console.error('Quote error:', error);
    return { success: false, error: error.message };
  }
}

// Execute trade with quote
export async function executeQuoteTrade(params: {
  quoteId: string;
  address: string;
  email?: string;
  holderName?: string;
}): Promise<TradeResult> {
  try {
    const response = await fetch(`${WALLET_API}/trade`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        quoteId: params.quoteId,
        address: params.address,
        email: params.email,
        holderName: params.holderName,
      }),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      return { success: false, error: data.error || 'Trade failed' };
    }
    
    return { 
      success: true, 
      transaction: data.transaction 
    };
  } catch (error: any) {
    console.error('Trade error:', error);
    return { success: false, error: error.message };
  }
}
