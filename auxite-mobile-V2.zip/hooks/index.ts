/**
 * i18n Module Export
 */

export * from './translations';
