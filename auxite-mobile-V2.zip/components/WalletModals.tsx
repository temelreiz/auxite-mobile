// components/WalletModals.tsx
// Withdraw, Receive, Send Modals

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Modal,
  TouchableOpacity,
  ScrollView,
  TextInput,
  useColorScheme,
  Alert,
  ActivityIndicator,
  Share,
  Clipboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useStore } from '@/stores/useStore';
import { API_URL } from '@/constants/api';

// ============================================
// TYPES
// ============================================
type WithdrawCrypto = 'USDT' | 'BTC' | 'ETH' | 'XRP' | 'SOL';

interface CryptoInfo {
  name: string;
  icon: string;
  color: string;
  network: string;
  minWithdraw: number;
  fee: number;
}

// ============================================
// CRYPTO DATA
// ============================================
const WITHDRAW_CRYPTOS: Record<WithdrawCrypto, CryptoInfo> = {
  USDT: { name: 'Tether', icon: 'cash-outline', color: '#26A17B', network: 'ERC-20 / TRC-20', minWithdraw: 10, fee: 1 },
  BTC: { name: 'Bitcoin', icon: 'logo-bitcoin', color: '#F7931A', network: 'Bitcoin', minWithdraw: 0.0005, fee: 0.0001 },
  ETH: { name: 'Ethereum', icon: 'diamond-outline', color: '#627EEA', network: 'ERC-20', minWithdraw: 0.01, fee: 0.001 },
  XRP: { name: 'Ripple', icon: 'swap-horizontal', color: '#94A3B8', network: 'XRP Ledger', minWithdraw: 1, fee: 0.1 },
  SOL: { name: 'Solana', icon: 'sunny-outline', color: '#9945FF', network: 'Solana', minWithdraw: 0.1, fee: 0.01 },
};

// Supported tokens for receive/send
const SUPPORTED_TOKENS = [
  { symbol: 'AUXG', name: 'Gold', color: '#EAB308' },
  { symbol: 'AUXS', name: 'Silver', color: '#94A3B8' },
  { symbol: 'AUXPT', name: 'Platinum', color: '#CBD5E1' },
  { symbol: 'AUXPD', name: 'Palladium', color: '#64748B' },
  { symbol: 'ETH', name: 'Ethereum', color: '#627EEA' },
];

// ============================================
// TRANSLATIONS - Using centralized i18n with fallback (6 Languages)
// ============================================
import { useTranslation } from '@/hooks/useTranslation';

const fallbackTranslations: Record<string, Record<string, string>> = {
  tr: {
    withdraw: 'Para Çek', withdrawSubtitle: 'AUXM\'i kripto olarak çekin', withdrawableBalance: 'Çekilebilir Bakiye',
    bonusLocked: 'Bonus (çekilemez)', auxmAmount: 'Çekilecek AUXM Miktarı', selectCrypto: 'Kripto Seçin',
    walletAddress: 'Cüzdan Adresi', network: 'Ağ', youWillReceive: 'Alacağınız', networkFee: 'Ağ Ücreti',
    netReceive: 'Net Alacak', insufficientBalance: 'Yetersiz AUXM bakiyesi', minimum: 'Minimum çekim',
    verifyAddress: 'Adresi kontrol edin. İşlem geri alınamaz.', continue: 'Devam Et', processing: 'İşleniyor...',
    confirmWithdrawal: 'Çekimi Onayla', withdrawalSuccess: 'Çekim Başlatıldı!',
    txComplete: 'İşlem 10-30 dakika içinde tamamlanacak', close: 'Kapat', destinationTag: 'Destination Tag', max: 'MAX',
    receive: 'Token Al', receiveSubtitle: 'Bu adresi paylaşarak token alabilirsiniz', yourAddress: 'Cüzdan Adresiniz',
    copy: 'Kopyala', copied: 'Kopyalandı!', share: 'Paylaş', supportedTokens: 'Desteklenen Tokenlar',
    warning: 'Sadece desteklenen tokenları bu adrese gönderin.', selectNetwork: 'Ağ Seçin',
    send: 'Gönder', sendSubtitle: 'Token gönderin', selectToken: 'Token Seç', recipientAddress: 'Alıcı Adresi',
    amount: 'Miktar', balance: 'Bakiye', sendToken: 'Gönder', confirmSend: 'Gönderimi Onayla',
    sendSuccess: 'Gönderim Başarılı!', invalidAddress: 'Geçersiz adres',
    deposit: 'Yatır', depositSubtitle: 'Kripto veya fiat yatırın',
  },
  en: {
    withdraw: 'Withdraw', withdrawSubtitle: 'Withdraw AUXM as crypto', withdrawableBalance: 'Withdrawable Balance',
    bonusLocked: 'Bonus (locked)', auxmAmount: 'AUXM Amount to Withdraw', selectCrypto: 'Select Crypto',
    walletAddress: 'Wallet Address', network: 'Network', youWillReceive: 'You will receive', networkFee: 'Network Fee',
    netReceive: 'Net Receive', insufficientBalance: 'Insufficient AUXM balance', minimum: 'Minimum',
    verifyAddress: 'Verify address. This cannot be reversed.', continue: 'Continue', processing: 'Processing...',
    confirmWithdrawal: 'Confirm Withdrawal', withdrawalSuccess: 'Withdrawal Started!',
    txComplete: 'Transaction will complete in 10-30 minutes', close: 'Close', destinationTag: 'Destination Tag', max: 'MAX',
    receive: 'Receive', receiveSubtitle: 'Share this address to receive tokens', yourAddress: 'Your Wallet Address',
    copy: 'Copy', copied: 'Copied!', share: 'Share', supportedTokens: 'Supported Tokens',
    warning: 'Only send supported tokens to this address.', selectNetwork: 'Select Network',
    send: 'Send', sendSubtitle: 'Send tokens', selectToken: 'Select Token', recipientAddress: 'Recipient Address',
    amount: 'Amount', balance: 'Balance', sendToken: 'Send', confirmSend: 'Confirm Send',
    sendSuccess: 'Send Successful!', invalidAddress: 'Invalid address',
    deposit: 'Deposit', depositSubtitle: 'Deposit crypto or fiat',
  },
  de: {
    withdraw: 'Abheben', withdrawSubtitle: 'AUXM als Krypto abheben', withdrawableBalance: 'Abhebbar',
    bonusLocked: 'Bonus (gesperrt)', auxmAmount: 'AUXM-Betrag zum Abheben', selectCrypto: 'Krypto wählen',
    walletAddress: 'Wallet-Adresse', network: 'Netzwerk', youWillReceive: 'Sie erhalten', networkFee: 'Netzwerkgebühr',
    netReceive: 'Netto erhalten', insufficientBalance: 'Unzureichendes AUXM-Guthaben', minimum: 'Minimum',
    verifyAddress: 'Adresse überprüfen. Nicht rückgängig.', continue: 'Weiter', processing: 'Verarbeitung...',
    confirmWithdrawal: 'Abhebung bestätigen', withdrawalSuccess: 'Abhebung gestartet!',
    txComplete: 'Transaktion wird in 10-30 Min. abgeschlossen', close: 'Schließen', destinationTag: 'Destination Tag', max: 'MAX',
    receive: 'Empfangen', receiveSubtitle: 'Adresse teilen um Token zu empfangen', yourAddress: 'Ihre Wallet-Adresse',
    copy: 'Kopieren', copied: 'Kopiert!', share: 'Teilen', supportedTokens: 'Unterstützte Token',
    warning: 'Nur unterstützte Token an diese Adresse senden.', selectNetwork: 'Netzwerk wählen',
    send: 'Senden', sendSubtitle: 'Token senden', selectToken: 'Token wählen', recipientAddress: 'Empfängeradresse',
    amount: 'Betrag', balance: 'Guthaben', sendToken: 'Senden', confirmSend: 'Senden bestätigen',
    sendSuccess: 'Erfolgreich gesendet!', invalidAddress: 'Ungültige Adresse',
    deposit: 'Einzahlen', depositSubtitle: 'Krypto oder Fiat einzahlen',
  },
  fr: {
    withdraw: 'Retirer', withdrawSubtitle: 'Retirer AUXM en crypto', withdrawableBalance: 'Solde retirable',
    bonusLocked: 'Bonus (verrouillé)', auxmAmount: 'Montant AUXM à retirer', selectCrypto: 'Sélectionner crypto',
    walletAddress: 'Adresse du portefeuille', network: 'Réseau', youWillReceive: 'Vous recevrez', networkFee: 'Frais réseau',
    netReceive: 'Net à recevoir', insufficientBalance: 'Solde AUXM insuffisant', minimum: 'Minimum',
    verifyAddress: "Vérifiez l'adresse. Irréversible.", continue: 'Continuer', processing: 'Traitement...',
    confirmWithdrawal: 'Confirmer le retrait', withdrawalSuccess: 'Retrait lancé!',
    txComplete: 'Transaction terminée dans 10-30 min', close: 'Fermer', destinationTag: 'Destination Tag', max: 'MAX',
    receive: 'Recevoir', receiveSubtitle: 'Partagez cette adresse pour recevoir', yourAddress: 'Votre adresse',
    copy: 'Copier', copied: 'Copié!', share: 'Partager', supportedTokens: 'Tokens supportés',
    warning: 'Envoyez uniquement des tokens supportés.', selectNetwork: 'Sélectionner réseau',
    send: 'Envoyer', sendSubtitle: 'Envoyer des tokens', selectToken: 'Sélectionner token', recipientAddress: 'Adresse destinataire',
    amount: 'Montant', balance: 'Solde', sendToken: 'Envoyer', confirmSend: "Confirmer l'envoi",
    sendSuccess: 'Envoi réussi!', invalidAddress: 'Adresse invalide',
    deposit: 'Déposer', depositSubtitle: 'Déposer crypto ou fiat',
  },
  ar: {
    withdraw: 'سحب', withdrawSubtitle: 'سحب AUXM كعملة مشفرة', withdrawableBalance: 'الرصيد القابل للسحب',
    bonusLocked: 'المكافأة (مقفلة)', auxmAmount: 'مبلغ AUXM للسحب', selectCrypto: 'اختر العملة المشفرة',
    walletAddress: 'عنوان المحفظة', network: 'الشبكة', youWillReceive: 'ستستلم', networkFee: 'رسوم الشبكة',
    netReceive: 'صافي الاستلام', insufficientBalance: 'رصيد AUXM غير كافٍ', minimum: 'الحد الأدنى',
    verifyAddress: 'تحقق من العنوان. لا يمكن التراجع.', continue: 'متابعة', processing: 'جاري المعالجة...',
    confirmWithdrawal: 'تأكيد السحب', withdrawalSuccess: 'بدأ السحب!',
    txComplete: 'ستكتمل المعاملة خلال 10-30 دقيقة', close: 'إغلاق', destinationTag: 'علامة الوجهة', max: 'الأقصى',
    receive: 'استلام', receiveSubtitle: 'شارك هذا العنوان لاستلام الرموز', yourAddress: 'عنوان محفظتك',
    copy: 'نسخ', copied: 'تم النسخ!', share: 'مشاركة', supportedTokens: 'الرموز المدعومة',
    warning: 'أرسل فقط الرموز المدعومة إلى هذا العنوان.', selectNetwork: 'اختر الشبكة',
    send: 'إرسال', sendSubtitle: 'إرسال الرموز', selectToken: 'اختر الرمز', recipientAddress: 'عنوان المستلم',
    amount: 'المبلغ', balance: 'الرصيد', sendToken: 'إرسال', confirmSend: 'تأكيد الإرسال',
    sendSuccess: 'تم الإرسال بنجاح!', invalidAddress: 'عنوان غير صالح',
    deposit: 'إيداع', depositSubtitle: 'إيداع كريبتو أو فيات',
  },
  ru: {
    withdraw: 'Вывод', withdrawSubtitle: 'Вывести AUXM как крипто', withdrawableBalance: 'Доступно для вывода',
    bonusLocked: 'Бонус (заблокирован)', auxmAmount: 'Сумма AUXM для вывода', selectCrypto: 'Выберите крипто',
    walletAddress: 'Адрес кошелька', network: 'Сеть', youWillReceive: 'Вы получите', networkFee: 'Комиссия сети',
    netReceive: 'Чистый приход', insufficientBalance: 'Недостаточно AUXM', minimum: 'Минимум',
    verifyAddress: 'Проверьте адрес. Необратимо.', continue: 'Продолжить', processing: 'Обработка...',
    confirmWithdrawal: 'Подтвердить вывод', withdrawalSuccess: 'Вывод начат!',
    txComplete: 'Транзакция завершится через 10-30 мин', close: 'Закрыть', destinationTag: 'Destination Tag', max: 'МАКС',
    receive: 'Получить', receiveSubtitle: 'Поделитесь адресом для получения токенов', yourAddress: 'Ваш адрес кошелька',
    copy: 'Копировать', copied: 'Скопировано!', share: 'Поделиться', supportedTokens: 'Поддерживаемые токены',
    warning: 'Отправляйте только поддерживаемые токены.', selectNetwork: 'Выберите сеть',
    send: 'Отправить', sendSubtitle: 'Отправить токены', selectToken: 'Выберите токен', recipientAddress: 'Адрес получателя',
    amount: 'Сумма', balance: 'Баланс', sendToken: 'Отправить', confirmSend: 'Подтвердить отправку',
    sendSuccess: 'Успешно отправлено!', invalidAddress: 'Неверный адрес',
    deposit: 'Депозит', depositSubtitle: 'Внести крипто или фиат',
  },
};

// Helper function to get translations
function getWalletTranslations(language: string) {
  return fallbackTranslations[language] || fallbackTranslations.en;
}

// ============================================
// 1. WITHDRAW MODAL
// ============================================
interface WithdrawModalProps {
  visible: boolean;
  onClose: () => void;
}

export function WithdrawModal({ visible, onClose }: WithdrawModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = getWalletTranslations(language);

  // States
  const [step, setStep] = useState<'select' | 'confirm' | 'success'>('select');
  const [selectedCrypto, setSelectedCrypto] = useState<WithdrawCrypto>('USDT');
  const [auxmAmount, setAuxmAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [xrpMemo, setXrpMemo] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Simulated balances
  const auxmBalance = 5000;
  const bonusAuxm = 250;

  // Crypto prices (simulated)
  const cryptoPrices: Record<WithdrawCrypto, number> = {
    USDT: 1, BTC: 105000, ETH: 3800, XRP: 2.35, SOL: 220,
  };

  // Reset on open
  useEffect(() => {
    if (visible) {
      setStep('select');
      setSelectedCrypto('USDT');
      setAuxmAmount('');
      setWithdrawAddress('');
      setXrpMemo('');
    }
  }, [visible]);

  const crypto = WITHDRAW_CRYPTOS[selectedCrypto];
  const auxmAmountNum = parseFloat(auxmAmount) || 0;
  const cryptoPrice = cryptoPrices[selectedCrypto];
  
  const receiveAmount = auxmAmountNum / cryptoPrice;
  const netReceiveAmount = Math.max(0, receiveAmount - crypto.fee);

  const canAfford = auxmAmountNum <= auxmBalance && auxmAmountNum > 0;
  const meetsMinimum = receiveAmount >= crypto.minWithdraw;
  const hasValidAddress = withdrawAddress.length > 10;
  const hasXrpMemo = selectedCrypto !== 'XRP' || xrpMemo.length > 0;

  const handleMaxClick = () => setAuxmAmount(auxmBalance.toFixed(2));

  const handleContinue = () => {
    if (canAfford && meetsMinimum && hasValidAddress && hasXrpMemo) {
      setStep('confirm');
    }
  };

  const handleWithdraw = async () => {
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 2000));
    setIsProcessing(false);
    setStep('success');
    setTimeout(() => onClose(), 3000);
  };

  // Success View
  if (step === 'success') {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
        <View style={styles.modalOverlay}>
          <View style={[styles.successContainer, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={[styles.successIcon, { backgroundColor: '#10b98120' }]}>
              <Ionicons name="checkmark-circle" size={64} color="#10b981" />
            </View>
            <Text style={[styles.successTitle, { color: '#10b981' }]}>{t.withdrawalSuccess}</Text>
            <Text style={[styles.successDetail, { color: isDark ? '#94a3b8' : '#64748b' }]}>
              {netReceiveAmount.toFixed(2)} {selectedCrypto}
            </Text>
            <Text style={[styles.successSubtext, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.txComplete}</Text>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff', maxHeight: '90%' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.withdraw}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.withdrawSubtitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {step === 'select' ? (
              <>
                {/* Balance Card */}
                <View style={[styles.balanceCard, { backgroundColor: '#ef444415', borderColor: '#ef444430' }]}>
                  <View style={styles.balanceRow}>
                    <Text style={[styles.balanceLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.withdrawableBalance}</Text>
                    <Text style={[styles.balanceValue, { color: '#ef4444' }]}>{auxmBalance.toLocaleString()} AUXM</Text>
                  </View>
                  {bonusAuxm > 0 && (
                    <View style={styles.balanceRow}>
                      <Text style={[styles.bonusLabel, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.bonusLocked}</Text>
                      <Text style={[styles.bonusValue, { color: '#8b5cf6' }]}>🔒 {bonusAuxm} AUXM</Text>
                    </View>
                  )}
                </View>

                {/* AUXM Amount Input */}
                <View style={styles.section}>
                  <View style={styles.inputHeader}>
                    <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.auxmAmount}</Text>
                    <TouchableOpacity onPress={handleMaxClick}>
                      <Text style={styles.maxButton}>{t.max}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={[styles.inputContainer, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
                    <TextInput
                      style={[styles.input, { color: isDark ? '#fff' : '#0f172a' }]}
                      value={auxmAmount}
                      onChangeText={setAuxmAmount}
                      placeholder="0.00"
                      placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                      keyboardType="decimal-pad"
                    />
                    <Text style={[styles.inputSuffix, { color: isDark ? '#94a3b8' : '#64748b' }]}>AUXM</Text>
                  </View>
                </View>

                {/* Crypto Selection */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectCrypto}</Text>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    {(Object.keys(WITHDRAW_CRYPTOS) as WithdrawCrypto[]).map((key) => {
                      const c = WITHDRAW_CRYPTOS[key];
                      const isSelected = selectedCrypto === key;
                      return (
                        <TouchableOpacity
                          key={key}
                          style={{
                            flex: 1,
                            alignItems: 'center',
                            justifyContent: 'center',
                            paddingVertical: 12,
                            borderRadius: 12,
                            marginHorizontal: 4,
                            backgroundColor: isDark ? '#0f172a' : '#f8fafc',
                            borderWidth: isSelected ? 2 : 1,
                            borderColor: isSelected ? '#ef4444' : (isDark ? '#334155' : '#e2e8f0'),
                          }}
                          onPress={() => setSelectedCrypto(key)}
                        >
                          <Ionicons name={c.icon as any} size={20} color={isSelected ? '#ef4444' : c.color} style={{ marginBottom: 4 }} />
                          <Text style={{ color: isSelected ? '#ef4444' : (isDark ? '#fff' : '#0f172a'), fontSize: 11, fontWeight: isSelected ? '600' : '400' }}>{key}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>

                {/* Address Input */}
                <View style={styles.section}>
                  <Text style={[styles.sectionLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{selectedCrypto} {t.walletAddress}</Text>
                  <TextInput
                    style={[styles.addressInput, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', color: isDark ? '#fff' : '#0f172a' }]}
                    value={withdrawAddress}
                    onChangeText={setWithdrawAddress}
                    placeholder={selectedCrypto === 'BTC' ? 'bc1q...' : selectedCrypto === 'XRP' ? 'r...' : '0x...'}
                    placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                    autoCapitalize="none"
                  />
                  <Text style={[styles.networkText, { color: isDark ? '#64748b' : '#94a3b8' }]}>{t.network}: {crypto.network}</Text>
                </View>

                {/* XRP Memo */}
                {selectedCrypto === 'XRP' && (
                  <View style={styles.section}>
                    <Text style={[styles.sectionLabel, { color: '#f59e0b' }]}>⚠️ {t.destinationTag} *</Text>
                    <TextInput
                      style={[styles.addressInput, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9', color: isDark ? '#fff' : '#0f172a' }]}
                      value={xrpMemo}
                      onChangeText={setXrpMemo}
                      placeholder="123456789"
                      placeholderTextColor={isDark ? '#475569' : '#94a3b8'}
                      keyboardType="number-pad"
                    />
                  </View>
                )}

                {/* Preview */}
                {auxmAmountNum > 0 && (
                  <View style={[styles.previewCard, { backgroundColor: '#ef444410', borderColor: '#ef444430' }]}>
                    <View style={styles.previewRow}>
                      <Text style={[styles.previewLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.youWillReceive}</Text>
                      <Text style={[styles.previewValue, { color: isDark ? '#fff' : '#0f172a' }]}>{receiveAmount.toFixed(2)} {selectedCrypto}</Text>
                    </View>
                    <View style={styles.previewRow}>
                      <Text style={[styles.previewLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.networkFee}</Text>
                      <Text style={[styles.previewValue, { color: isDark ? '#94a3b8' : '#64748b' }]}>-{crypto.fee} {selectedCrypto}</Text>
                    </View>
                    <View style={[styles.divider, { backgroundColor: '#ef444430' }]} />
                    <View style={styles.previewRow}>
                      <Text style={[styles.netLabel, { color: '#ef4444' }]}>{t.netReceive}</Text>
                      <Text style={[styles.netValue, { color: '#ef4444' }]}>{netReceiveAmount.toFixed(2)} {selectedCrypto}</Text>
                    </View>
                  </View>
                )}

                {/* Warnings */}
                {!canAfford && auxmAmountNum > 0 && (
                  <View style={styles.warningCard}>
                    <Ionicons name="warning" size={16} color="#ef4444" />
                    <Text style={styles.warningText}>{t.insufficientBalance}</Text>
                  </View>
                )}
                {!meetsMinimum && auxmAmountNum > 0 && canAfford && (
                  <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
                    <Ionicons name="warning" size={16} color="#f59e0b" />
                    <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.minimum}: {crypto.minWithdraw} {selectedCrypto}</Text>
                  </View>
                )}
              </>
            ) : (
              /* Confirm Step */
              <>
                <View style={[styles.confirmCard, { backgroundColor: isDark ? '#0f172a' : '#f8fafc' }]}>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>AUXM</Text>
                    <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{auxmAmountNum.toFixed(2)}</Text>
                  </View>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.selectCrypto}</Text>
                    <Text style={[styles.confirmValue, { color: isDark ? '#fff' : '#0f172a' }]}>{selectedCrypto}</Text>
                  </View>
                  <View style={styles.confirmRow}>
                    <Text style={[styles.confirmLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.walletAddress}</Text>
                    <Text style={[styles.confirmAddress, { color: isDark ? '#fff' : '#0f172a' }]}>
                      {withdrawAddress.slice(0, 8)}...{withdrawAddress.slice(-6)}
                    </Text>
                  </View>
                  <View style={[styles.divider, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]} />
                  <View style={styles.confirmRow}>
                    <Text style={[styles.netLabel, { color: '#ef4444' }]}>{t.netReceive}</Text>
                    <Text style={[styles.netValue, { color: '#ef4444' }]}>{netReceiveAmount.toFixed(2)} {selectedCrypto}</Text>
                  </View>
                </View>

                <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
                  <Ionicons name="warning" size={16} color="#f59e0b" />
                  <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.verifyAddress}</Text>
                </View>
              </>
            )}

            {/* Action Button */}
            <TouchableOpacity
              style={[styles.actionButton, (!canAfford || !meetsMinimum || !hasValidAddress || !hasXrpMemo || isProcessing) && styles.actionButtonDisabled]}
              onPress={step === 'select' ? handleContinue : handleWithdraw}
              disabled={!canAfford || !meetsMinimum || !hasValidAddress || !hasXrpMemo || isProcessing}
            >
              <LinearGradient
                colors={['#ef4444', '#f97316']}
                style={styles.actionButtonGradient}
              >
                {isProcessing ? (
                  <>
                    <ActivityIndicator size="small" color="#fff" />
                    <Text style={styles.actionButtonText}>{t.processing}</Text>
                  </>
                ) : (
                  <Text style={styles.actionButtonText}>
                    {step === 'select' ? t.continue : t.confirmWithdrawal}
                  </Text>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <View style={{ height: 20 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 2. RECEIVE MODAL
// ============================================
interface ReceiveModalProps {
  visible: boolean;
  onClose: () => void;
  walletAddress?: string;
}

export function ReceiveModal({ visible, onClose, walletAddress }: ReceiveModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = getWalletTranslations(language);

  const [copied, setCopied] = useState(false);
  const [selectedNetwork, setSelectedNetwork] = useState<'ETH' | 'BASE'>('ETH');

  const address = walletAddress || '0xe6df1234567890abcdef1234567890abcdef3ba3';

  const handleCopy = () => {
    Clipboard.setString(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `My Auxite Wallet Address: ${address}`,
      });
    } catch {
      handleCopy();
    }
  };

  const networks = [
    { id: 'ETH' as const, name: 'Ethereum', color: '#627EEA' },
    { id: 'BASE' as const, name: 'Base', color: '#0052FF' },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
          {/* Header */}
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#0f172a' }]}>{t.receive}</Text>
              <Text style={[styles.modalSubtitle, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.receiveSubtitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Network Selection */}
            <View style={styles.networkContainer}>
              {networks.map((network) => (
                <TouchableOpacity
                  key={network.id}
                  style={[
                    styles.networkOption,
                    { backgroundColor: isDark ? '#0f172a' : '#f8fafc', borderColor: selectedNetwork === network.id ? network.color : (isDark ? '#334155' : '#e2e8f0') },
                    selectedNetwork === network.id && { borderWidth: 2 }
                  ]}
                  onPress={() => setSelectedNetwork(network.id)}
                >
                  <View style={[styles.networkDot, { backgroundColor: network.color }]} />
                  <Text style={[styles.networkName, { color: isDark ? '#fff' : '#0f172a' }]}>{network.name}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* QR Code Placeholder */}
            <View style={styles.qrContainer}>
              <View style={styles.qrPlaceholder}>
                <Ionicons name="qr-code" size={140} color="#94a3b8" />
              </View>
            </View>

            {/* Network Badge */}
            <View style={styles.networkBadgeContainer}>
              <View style={[styles.networkBadge, { backgroundColor: networks.find(n => n.id === selectedNetwork)?.color }]}>
                <Text style={styles.networkBadgeText}>
                  {selectedNetwork === 'ETH' ? 'Ethereum Mainnet' : 'Base Network'}
                </Text>
              </View>
            </View>

            {/* Address */}
            <View style={[styles.addressCard, { backgroundColor: isDark ? '#0f172a' : '#f1f5f9' }]}>
              <View style={styles.addressHeader}>
                <Text style={[styles.addressLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.yourAddress}</Text>
                <TouchableOpacity onPress={handleCopy}>
                  <Text style={[styles.copyButton, { color: copied ? '#10b981' : '#10b981' }]}>
                    {copied ? `✓ ${t.copied}` : t.copy}
                  </Text>
                </TouchableOpacity>
              </View>
              <Text style={[styles.addressText, { color: isDark ? '#fff' : '#0f172a' }]} selectable>
                {address}
              </Text>
            </View>

            {/* Supported Tokens */}
            <View style={[styles.tokensCard, { backgroundColor: isDark ? '#0f172a50' : '#f8fafc' }]}>
              <Text style={[styles.tokensLabel, { color: isDark ? '#94a3b8' : '#64748b' }]}>{t.supportedTokens}</Text>
              <View style={styles.tokensList}>
                {SUPPORTED_TOKENS.map((token) => (
                  <View key={token.symbol} style={[styles.tokenBadge, { backgroundColor: isDark ? '#334155' : '#e2e8f0' }]}>
                    <Text style={[styles.tokenBadgeText, { color: isDark ? '#e2e8f0' : '#334155' }]}>{token.symbol}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Warning */}
            <View style={[styles.warningCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
              <Ionicons name="warning" size={16} color="#f59e0b" />
              <Text style={[styles.warningText, { color: '#f59e0b' }]}>{t.warning}</Text>
            </View>

            {/* Action Buttons */}
            <View style={styles.receiveActions}>
              <TouchableOpacity
                style={[styles.receiveActionBtn, { backgroundColor: isDark ? '#0f172a' : '#e2e8f0', flex: 1 }]}
                onPress={handleCopy}
              >
                <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={20} color={copied ? '#10b981' : (isDark ? '#fff' : '#0f172a')} />
                <Text style={[styles.receiveActionText, { color: isDark ? '#fff' : '#0f172a' }]}>
                  {copied ? t.copied.replace('!', '') : t.copy}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.receiveActionBtn, { backgroundColor: '#8b5cf6', flex: 1 }]}
                onPress={handleShare}
              >
                <Ionicons name="share-outline" size={20} color="#fff" />
                <Text style={[styles.receiveActionText, { color: '#fff' }]}>{t.share}</Text>
              </TouchableOpacity>
            </View>

            <View style={{ height: 20 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================
// 3. SEND MODAL
// ============================================
// SendModal - Fixed version with API integration
// Replace the SendModal function in components/WalletModals.tsx with this

interface SendModalProps {
  visible: boolean;
  onClose: () => void;
  walletAddress?: string;
  onSuccess?: () => void;
}

const METAL_TOKENS = ['AUXG', 'AUXS', 'AUXPT', 'AUXPD'];
const TRANSFERABLE_TOKENS = [
  { symbol: 'AUXG', name: 'Gold', icon: 'radio-button-on', color: '#F59E0B' },
  { symbol: 'AUXS', name: 'Silver', icon: 'radio-button-on', color: '#94A3B8' },
  { symbol: 'AUXPT', name: 'Platinum', icon: 'radio-button-on', color: '#CBD5E1' },
  { symbol: 'AUXPD', name: 'Palladium', icon: 'radio-button-on', color: '#64748B' },
  { symbol: 'ETH', name: 'Ethereum', icon: 'logo-ethereum', color: '#627EEA' },
  { symbol: 'BTC', name: 'Bitcoin', icon: 'logo-bitcoin', color: '#F7931A' },
  { symbol: 'USDT', name: 'Tether', icon: 'cash-outline', color: '#26A17B' },
  { symbol: 'XRP', name: 'Ripple', icon: 'swap-horizontal', color: '#23292F' },
  { symbol: 'SOL', name: 'Solana', icon: 'sunny-outline', color: '#9945FF' },
];

export function SendModal({ visible, onClose, walletAddress, onSuccess }: SendModalProps) {
  const colorScheme = useColorScheme();
  const { theme, language, walletAddress: storeWallet } = useStore();
  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = getWalletTranslations(language);

  const METAL_TOKENS = ['AUXG', 'AUXS', 'AUXPT', 'AUXPD'];
  const TRANSFERABLE_TOKENS = [
    { symbol: 'AUXG', name: 'Gold', icon: 'ellipse', color: '#F59E0B', isMetal: true },
    { symbol: 'AUXS', name: 'Silver', icon: 'ellipse', color: '#94A3B8', isMetal: true },
    { symbol: 'AUXPT', name: 'Platinum', icon: 'ellipse', color: '#CBD5E1', isMetal: true },
    { symbol: 'AUXPD', name: 'Palladium', icon: 'ellipse', color: '#64748B', isMetal: true },
    { symbol: 'ETH', name: 'Ethereum', icon: 'diamond-outline', color: '#627EEA', isMetal: false },
    { symbol: 'BTC', name: 'Bitcoin', icon: 'logo-bitcoin', color: '#F7931A', isMetal: false },
    { symbol: 'USDT', name: 'Tether', icon: 'cash-outline', color: '#26A17B', isMetal: false },
    { symbol: 'XRP', name: 'Ripple', icon: 'swap-horizontal', color: '#94A3B8', isMetal: false },
    { symbol: 'SOL', name: 'Solana', icon: 'sunny-outline', color: '#9945FF', isMetal: false },
  ];

  const [selectedToken, setSelectedToken] = useState(TRANSFERABLE_TOKENS[0]);
  const [recipientAddress, setRecipientAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<'input' | 'confirm' | 'success' | 'error'>('input');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [txHash, setTxHash] = useState<string | null>(null);
  
  const [balances, setBalances] = useState<Record<string, number>>({});
  const [onChainBalances, setOnChainBalances] = useState<Record<string, number>>({});
  const [loadingBalances, setLoadingBalances] = useState(false);
  
  const [isCheckingRecipient, setIsCheckingRecipient] = useState(false);
  const [recipientValid, setRecipientValid] = useState<boolean | null>(null);

  const address = walletAddress || storeWallet;
  const API_BASE_URL = API_URL;
  const isMetal = METAL_TOKENS.includes(selectedToken.symbol);

  const fetchBalances = useCallback(async () => {
    if (!address) return;
    setLoadingBalances(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/user/balance?address=${address}`);
      const data = await res.json();
      if (data.success && data.balances) {
        setBalances({
          AUXG: data.balances.auxg || 0,
          AUXS: data.balances.auxs || 0,
          AUXPT: data.balances.auxpt || 0,
          AUXPD: data.balances.auxpd || 0,
          AUXM: (data.balances.auxm || 0) + (data.balances.bonusAuxm || 0),
          ETH: data.balances.eth || 0,
          BTC: data.balances.btc || 0,
          XRP: data.balances.xrp || 0,
          SOL: data.balances.sol || 0,
          USDT: data.balances.usdt || 0,
        });
        if (data.onChainBalances) {
          setOnChainBalances({
            AUXG: data.onChainBalances.auxg || 0,
            AUXS: data.onChainBalances.auxs || 0,
            AUXPT: data.onChainBalances.auxpt || 0,
            AUXPD: data.onChainBalances.auxpd || 0,
            USDT: data.onChainBalances.usdt || 0,
          });
        }
      }
    } catch (e) {
      console.error('Balance fetch error:', e);
    } finally {
      setLoadingBalances(false);
    }
  }, [address]);

  useEffect(() => {
    if (!visible) return;
    const hasValidAddress = recipientAddress.length >= 42 && recipientAddress.startsWith('0x');
    if (!isMetal || !hasValidAddress) {
      setRecipientValid(null);
      setIsCheckingRecipient(false);
      return;
    }
    setIsCheckingRecipient(true);
    const timeout = setTimeout(async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/user/check?address=${recipientAddress}`);
        const data = await res.json();
        setRecipientValid(data.exists === true);
      } catch {
        setRecipientValid(false);
      }
      setIsCheckingRecipient(false);
    }, 500);
    return () => clearTimeout(timeout);
  }, [visible, recipientAddress, isMetal]);

  useEffect(() => {
    if (visible) {
      setStep('input');
      setSelectedToken(TRANSFERABLE_TOKENS[0]);
      setRecipientAddress('');
      setAmount('');
      setErrorMessage('');
      setTxHash(null);
      setRecipientValid(null);
      fetchBalances();
    }
  }, [visible, fetchBalances]);

  const amountNum = parseFloat(amount) || 0;
  const balance = isMetal ? (onChainBalances[selectedToken.symbol] || 0) : (balances[selectedToken.symbol] || 0);
  const canAfford = amountNum > 0 && amountNum <= balance;
  const hasValidAddress = recipientAddress.length >= 42 && recipientAddress.startsWith('0x');
  const canSend = canAfford && hasValidAddress && (!isMetal || recipientValid === true);

  const handleMaxClick = () => setAmount(balance.toString());
  const handleContinue = () => { if (canSend) setStep('confirm'); };

  const handleSend = async () => {
    if (!address) {
      setErrorMessage(language === 'tr' ? 'Cüzdan bağlı değil' : 'Wallet not connected');
      setStep('error');
      return;
    }
    setIsProcessing(true);
    setErrorMessage('');
    try {
      if (isMetal) {
        const allocResponse = await fetch(`${API_BASE_URL}/api/allocations`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fromAddress: address, toAddress: recipientAddress, grams: amountNum }),
        });
        const allocData = await allocResponse.json();
        if (!allocData.success) throw new Error(allocData.error || 'Allocation transfer failed');
      }
      const response = await fetch(`${API_BASE_URL}/api/transfer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fromAddress: address, toAddress: recipientAddress, token: selectedToken.symbol, amount: amountNum }),
      });
      const data = await response.json();
      if (data.success) {
        setTxHash(data.transfer?.txHash || null);
        setStep('success');
        if (onSuccess) onSuccess();
        setTimeout(() => onClose(), 3000);
      } else {
        throw new Error(data.error || 'Transfer failed');
      }
    } catch (error: any) {
      setErrorMessage(error.message || 'Transfer failed');
      setStep('error');
    } finally {
      setIsProcessing(false);
    }
  };

  if (step === 'error') {
    return (
      <Modal visible={visible} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
          <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={{ alignItems: 'center', padding: 24 }}>
              <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: '#ef4444', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <Ionicons name="close" size={32} color="#fff" />
              </View>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#ef4444', marginBottom: 8 }}>
                {language === 'tr' ? 'Transfer Başarısız' : 'Transfer Failed'}
              </Text>
              <Text style={{ color: isDark ? '#94a3b8' : '#64748b', textAlign: 'center', marginBottom: 16 }}>{errorMessage}</Text>
              <TouchableOpacity onPress={() => setStep('input')} style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: isDark ? '#334155' : '#e2e8f0', borderRadius: 12 }}>
                <Text style={{ color: isDark ? '#fff' : '#1e293b' }}>{language === 'tr' ? 'Tekrar Dene' : 'Try Again'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  if (step === 'success') {
    return (
      <Modal visible={visible} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
          <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={{ alignItems: 'center', padding: 24 }}>
              <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: '#10b981', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <Ionicons name="checkmark" size={32} color="#fff" />
              </View>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#10b981', marginBottom: 8 }}>
                {language === 'tr' ? 'Transfer Başarılı!' : 'Transfer Successful!'}
              </Text>
              <Text style={{ color: isDark ? '#94a3b8' : '#64748b', textAlign: 'center' }}>
                {amountNum.toFixed(4)} {selectedToken.symbol}
              </Text>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  if (step === 'confirm') {
    return (
      <Modal visible={visible} animationType="slide" transparent>
        <View style={[styles.modalOverlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
          <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff' }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#1e293b' }]}>
                {language === 'tr' ? 'Transferi Onayla' : 'Confirm Transfer'}
              </Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
              </TouchableOpacity>
            </View>
            <View style={{ padding: 16 }}>
              <View style={{ backgroundColor: isDark ? '#334155' : '#f1f5f9', borderRadius: 12, padding: 16, marginBottom: 16 }}>
                <Text style={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: 4 }}>{language === 'tr' ? 'Miktar' : 'Amount'}</Text>
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: isDark ? '#fff' : '#1e293b' }}>{amountNum.toFixed(4)} {selectedToken.symbol}</Text>
              </View>
              <View style={{ backgroundColor: isDark ? '#334155' : '#f1f5f9', borderRadius: 12, padding: 16, marginBottom: 16 }}>
                <Text style={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: 4 }}>{language === 'tr' ? 'Alıcı' : 'Recipient'}</Text>
                <Text style={{ color: isDark ? '#fff' : '#1e293b', fontFamily: 'monospace', fontSize: 12 }}>{recipientAddress}</Text>
              </View>
              {isMetal && (
                <View style={{ backgroundColor: '#fef3c7', borderRadius: 12, padding: 12, marginBottom: 16 }}>
                  <Text style={{ color: '#92400e', fontSize: 12 }}>
                    {language === 'tr' ? 'Metal transferiyle birlikte allocation ve sertifika da devredilecektir.' : 'Allocation and certificate will also be transferred with the metal.'}
                  </Text>
                </View>
              )}
              <TouchableOpacity onPress={handleSend} disabled={isProcessing} style={{ backgroundColor: '#3b82f6', borderRadius: 12, padding: 16, alignItems: 'center', opacity: isProcessing ? 0.5 : 1 }}>
                {isProcessing ? <ActivityIndicator color="#fff" /> : <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16 }}>{language === 'tr' ? 'Gönder' : 'Send'}</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={[styles.modalOverlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
        <View style={[styles.modalContent, { backgroundColor: isDark ? '#1e293b' : '#fff', maxHeight: '90%' }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#1e293b' }]}>
              {language === 'tr' ? 'Transfer' : 'Transfer'}
            </Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={isDark ? '#94a3b8' : '#64748b'} />
            </TouchableOpacity>
          </View>
          <ScrollView style={{ padding: 16 }}>
            <Text style={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: 12 }}>{language === 'tr' ? 'Token Seç' : 'Select Token'}</Text>
            {/* Metals Row */}
            <View style={{ flexDirection: 'row', marginBottom: 8 }}>
              {[
                { symbol: 'AUXG', icon: require('../assets/images/metals/gold.png') },
                { symbol: 'AUXS', icon: require('../assets/images/metals/silver.png') },
                { symbol: 'AUXPT', icon: require('../assets/images/metals/platinum.png') },
                { symbol: 'AUXPD', icon: require('../assets/images/metals/palladium.png') },
              ].map((metal) => {
                const token = TRANSFERABLE_TOKENS.find(t => t.symbol === metal.symbol);
                if (!token) return null;
                return (
                  <TouchableOpacity
                    key={token.symbol}
                    onPress={() => setSelectedToken(token)}
                    style={{
                      flex: 1, alignItems: 'center', justifyContent: 'center',
                      paddingVertical: 10, borderRadius: 10, marginHorizontal: 3,
                      backgroundColor: selectedToken.symbol === token.symbol ? (isDark ? '#3b82f6' : '#dbeafe') : (isDark ? '#334155' : '#f1f5f9'),
                      borderWidth: selectedToken.symbol === token.symbol ? 2 : 0,
                      borderColor: '#3b82f6',
                    }}
                  >
                    <Image source={metal.icon} style={{ width: 24, height: 24, marginBottom: 4 }} />
                    <Text style={{ color: selectedToken.symbol === token.symbol ? (isDark ? '#fff' : '#1e40af') : (isDark ? '#94a3b8' : '#64748b'), fontWeight: selectedToken.symbol === token.symbol ? '600' : '400', fontSize: 10 }}>{token.symbol}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            {/* Crypto Row */}
            <View style={{ flexDirection: 'row', marginBottom: 16 }}>
              {TRANSFERABLE_TOKENS.slice(4).map((token) => (
                <TouchableOpacity
                  key={token.symbol}
                  onPress={() => setSelectedToken(token)}
                  style={{
                    flex: 1, alignItems: 'center', justifyContent: 'center',
                    paddingVertical: 10, borderRadius: 10, marginHorizontal: 3,
                    backgroundColor: selectedToken.symbol === token.symbol ? (isDark ? '#3b82f6' : '#dbeafe') : (isDark ? '#334155' : '#f1f5f9'),
                    borderWidth: selectedToken.symbol === token.symbol ? 2 : 0,
                    borderColor: '#3b82f6',
                  }}
                >
                  <Ionicons name={token.icon as any} size={18} color={selectedToken.symbol === token.symbol ? '#fff' : token.color} style={{ marginBottom: 4 }} />
                  <Text style={{ color: selectedToken.symbol === token.symbol ? (isDark ? '#fff' : '#1e40af') : (isDark ? '#94a3b8' : '#64748b'), fontWeight: selectedToken.symbol === token.symbol ? '600' : '400', fontSize: 10 }}>{token.symbol}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isMetal && (
              <View style={{ backgroundColor: isDark ? '#422006' : '#fef3c7', borderRadius: 12, padding: 12, marginBottom: 16 }}>
                <Text style={{ color: isDark ? '#fcd34d' : '#92400e', fontSize: 12 }}>
                  {language === 'tr' ? 'Metal transferi sadece kayıtlı Auxite kullanıcılarına yapılabilir.' : 'Metal transfers can only be made to registered Auxite users.'}
                </Text>
              </View>
            )}

            <Text style={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: 8 }}>{language === 'tr' ? 'Alıcı Adresi' : 'Recipient Address'}</Text>
            <TextInput
              value={recipientAddress}
              onChangeText={setRecipientAddress}
              placeholder="0x..."
              placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
              style={{ backgroundColor: isDark ? '#334155' : '#f1f5f9', borderRadius: 12, padding: 16, marginBottom: 8, color: isDark ? '#fff' : '#1e293b', fontFamily: 'monospace', fontSize: 14 }}
            />

            {isMetal && hasValidAddress && (
              <View style={{ marginBottom: 16 }}>
                {isCheckingRecipient ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <ActivityIndicator size="small" color="#94a3b8" />
                    <Text style={{ color: '#94a3b8', marginLeft: 8, fontSize: 12 }}>{language === 'tr' ? 'Kontrol ediliyor...' : 'Checking...'}</Text>
                  </View>
                ) : recipientValid === true ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name="checkmark-circle" size={16} color="#10b981" />
                    <Text style={{ color: '#10b981', marginLeft: 8, fontSize: 12 }}>{language === 'tr' ? 'Auxite kullanıcısı ✓' : 'Auxite user ✓'}</Text>
                  </View>
                ) : recipientValid === false ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name="close-circle" size={16} color="#ef4444" />
                    <Text style={{ color: '#ef4444', marginLeft: 8, fontSize: 12 }}>{language === 'tr' ? 'Alıcı Auxite kullanıcısı değil' : 'Recipient is not an Auxite user'}</Text>
                  </View>
                ) : null}
              </View>
            )}

            <Text style={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: 8 }}>{language === 'tr' ? 'Miktar' : 'Amount'}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor={isDark ? '#64748b' : '#94a3b8'}
                style={{ flex: 1, backgroundColor: isDark ? '#334155' : '#f1f5f9', borderRadius: 12, padding: 16, marginRight: 8, color: isDark ? '#fff' : '#1e293b', fontSize: 18 }}
              />
              <TouchableOpacity onPress={handleMaxClick} style={{ backgroundColor: isDark ? '#334155' : '#f1f5f9', borderRadius: 12, padding: 16 }}>
                <Text style={{ color: '#10b981', fontWeight: '600' }}>MAX</Text>
              </TouchableOpacity>
            </View>
            <Text style={{ color: isDark ? '#64748b' : '#94a3b8', fontSize: 12, marginBottom: 16 }}>
              {language === 'tr' ? 'Bakiye' : 'Balance'}: {balance.toFixed(4)} {selectedToken.symbol}
            </Text>

            {!canAfford && amountNum > 0 && (
              <Text style={{ color: '#ef4444', fontSize: 12, marginBottom: 16 }}>{language === 'tr' ? 'Yetersiz bakiye' : 'Insufficient balance'}</Text>
            )}

            <TouchableOpacity onPress={handleContinue} disabled={!canSend} style={{ backgroundColor: canSend ? '#3b82f6' : (isDark ? '#334155' : '#e2e8f0'), borderRadius: 12, padding: 16, alignItems: 'center', marginBottom: 32 }}>
              <Text style={{ color: canSend ? '#fff' : '#94a3b8', fontWeight: '600', fontSize: 16 }}>{language === 'tr' ? 'Devam' : 'Continue'}</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}


export default { WithdrawModal, ReceiveModal, SendModal };

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(148, 163, 184, 0.2)',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  modalSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  closeButton: {
    padding: 8,
  },
  successContainer: {
    margin: 20,
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  successDetail: {
    fontSize: 16,
    marginBottom: 4,
  },
  successSubtext: {
    fontSize: 13,
  },
  balanceCard: {
    margin: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 14,
  },
  balanceValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  bonusLabel: {
    fontSize: 12,
  },
  bonusValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sectionLabel: {
    fontSize: 14,
    marginBottom: 8,
  },
  inputHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  maxButton: {
    color: '#f97316',
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingHorizontal: 16,
  },
  input: {
    flex: 1,
    fontSize: 18,
    paddingVertical: 14,
  },
  inputSuffix: {
    fontSize: 14,
    fontWeight: '600',
  },
  cryptoCard: {
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    marginRight: 10,
    borderWidth: 1,
    minWidth: 70,
  },
  cryptoIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  cryptoIconText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cryptoSymbol: {
    fontSize: 12,
    fontWeight: '600',
  },
  addressInput: {
    borderRadius: 12,
    padding: 14,
    fontSize: 14,
    fontFamily: 'monospace',
  },
  networkText: {
    fontSize: 12,
    marginTop: 6,
  },
  summaryCard: {
    margin: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  summaryLabel: {
    fontSize: 14,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  summaryDivider: {
    height: 1,
    marginVertical: 8,
  },
  continueButton: {
    margin: 16,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  continueButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  confirmHeader: {
    alignItems: 'center',
    padding: 24,
    borderBottomWidth: 1,
  },
  confirmAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  confirmUsd: {
    fontSize: 14,
  },
  confirmSection: {
    padding: 16,
  },
  confirmRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  confirmLabel: {
    fontSize: 14,
  },
  confirmValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  warningBox: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  warningText: {
    flex: 1,
    marginLeft: 8,
    fontSize: 12,
  },
  buttonRow: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  backButton: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  confirmButton: {
    flex: 2,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  qrContainer: {
    alignItems: 'center',
    padding: 24,
  },
  qrBox: {
    padding: 16,
    borderRadius: 16,
    marginBottom: 16,
  },
  addressContainer: {
    width: '100%',
    marginTop: 8,
  },
  addressLabel: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  addressBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
  },
  addressText: {
    flex: 1,
    fontSize: 12,
    fontFamily: 'monospace',
  },
  shareButton: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    gap: 8,
  },
  shareButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  previewCard: {
    margin: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  previewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  previewLabel: {
    fontSize: 14,
  },
  previewValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  divider: {
    height: 1,
    marginVertical: 8,
  },
  netLabel: {
    fontSize: 16,
    fontWeight: '600',
  },
  netValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  warningCard: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 16,
    marginTop: 0,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#ef444415',
    borderWidth: 1,
    borderColor: '#ef444430',
    gap: 8,
  },
  confirmCard: {
    margin: 16,
    padding: 16,
    borderRadius: 16,
  },
  confirmRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  confirmLabel: {
    fontSize: 14,
  },
  confirmValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  confirmAddress: {
    fontSize: 12,
    fontFamily: 'monospace',
  },
  actionButton: {
    marginHorizontal: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  actionButtonDisabled: {
    opacity: 0.5,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});