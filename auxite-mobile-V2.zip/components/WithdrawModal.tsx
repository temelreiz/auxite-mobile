// components/WithdrawModal.tsx
// Crypto Withdrawal Modal
// 6-Language Support | Dark/Light Mode | 2FA Support

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  useColorScheme,
  ActivityIndicator,
  TextInput,
  ScrollView,
  Alert,
  Linking,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/stores/useStore';
import { API_URL } from '@/constants/api';

interface Props {
  visible: boolean;
  onClose: () => void;
  walletAddress: string;
  auxmBalance: number;
  onSuccess?: () => void;
}

// ============================================
// TRANSLATIONS
// ============================================
const translations = {
  tr: {
    title: 'Kripto Çek',
    selectCoin: 'Kripto Seç',
    amount: 'Miktar (AUXM)',
    withdrawAddress: 'Çekim Adresi',
    addressPlaceholder: 'Cüzdan adresi girin',
    memo: 'Memo/Tag (Opsiyonel)',
    memoPlaceholder: 'XRP için gerekli olabilir',
    available: 'Kullanılabilir',
    networkFee: 'Ağ Ücreti',
    youWillReceive: 'Alacağınız',
    total: 'Toplam',
    withdraw: 'Çek',
    cancel: 'İptal',
    processing: 'İşleniyor...',
    success: 'Başarılı!',
    withdrawSuccess: 'Çekim işlemi başarıyla tamamlandı.',
    viewExplorer: 'Explorer\'da Gör',
    error: 'Hata',
    insufficientBalance: 'Yetersiz bakiye',
    invalidAddress: 'Geçersiz adres',
    minAmount: 'Minimum miktar',
    twoFactorRequired: '2FA Doğrulama',
    twoFactorCode: '2FA Kodu',
    twoFactorPlaceholder: '6 haneli kod',
    verify: 'Doğrula',
    btcComingSoon: 'BTC çekimleri yakında. Lütfen ETH, USDT, XRP veya SOL kullanın.',
    max: 'Max',
    confirmWithdraw: 'Çekimi Onayla',
    confirmMessage: 'adresine çekim yapılacak. Onaylıyor musunuz?',
    confirm: 'Onayla',
  },
  en: {
    title: 'Withdraw Crypto',
    selectCoin: 'Select Crypto',
    amount: 'Amount (AUXM)',
    withdrawAddress: 'Withdraw Address',
    addressPlaceholder: 'Enter wallet address',
    memo: 'Memo/Tag (Optional)',
    memoPlaceholder: 'May be required for XRP',
    available: 'Available',
    networkFee: 'Network Fee',
    youWillReceive: 'You Will Receive',
    total: 'Total',
    withdraw: 'Withdraw',
    cancel: 'Cancel',
    processing: 'Processing...',
    success: 'Success!',
    withdrawSuccess: 'Withdrawal completed successfully.',
    viewExplorer: 'View on Explorer',
    error: 'Error',
    insufficientBalance: 'Insufficient balance',
    invalidAddress: 'Invalid address',
    minAmount: 'Minimum amount',
    twoFactorRequired: '2FA Verification',
    twoFactorCode: '2FA Code',
    twoFactorPlaceholder: '6-digit code',
    verify: 'Verify',
    btcComingSoon: 'BTC withdrawals coming soon. Please use ETH, USDT, XRP or SOL.',
    max: 'Max',
    confirmWithdraw: 'Confirm Withdrawal',
    confirmMessage: 'will be withdrawn to. Do you confirm?',
    confirm: 'Confirm',
  },
  de: {
    title: 'Krypto abheben',
    selectCoin: 'Krypto wählen',
    amount: 'Betrag (AUXM)',
    withdrawAddress: 'Auszahlungsadresse',
    addressPlaceholder: 'Wallet-Adresse eingeben',
    memo: 'Memo/Tag (Optional)',
    memoPlaceholder: 'Kann für XRP erforderlich sein',
    available: 'Verfügbar',
    networkFee: 'Netzwerkgebühr',
    youWillReceive: 'Sie erhalten',
    total: 'Gesamt',
    withdraw: 'Abheben',
    cancel: 'Abbrechen',
    processing: 'Verarbeitung...',
    success: 'Erfolgreich!',
    withdrawSuccess: 'Auszahlung erfolgreich abgeschlossen.',
    viewExplorer: 'Im Explorer ansehen',
    error: 'Fehler',
    insufficientBalance: 'Unzureichendes Guthaben',
    invalidAddress: 'Ungültige Adresse',
    minAmount: 'Mindestbetrag',
    twoFactorRequired: '2FA-Verifizierung',
    twoFactorCode: '2FA-Code',
    twoFactorPlaceholder: '6-stelliger Code',
    verify: 'Verifizieren',
    btcComingSoon: 'BTC-Auszahlungen bald verfügbar.',
    max: 'Max',
    confirmWithdraw: 'Auszahlung bestätigen',
    confirmMessage: 'wird abgehoben an. Bestätigen Sie?',
    confirm: 'Bestätigen',
  },
  fr: {
    title: 'Retirer Crypto',
    selectCoin: 'Sélectionner Crypto',
    amount: 'Montant (AUXM)',
    withdrawAddress: 'Adresse de retrait',
    addressPlaceholder: 'Entrez l\'adresse du portefeuille',
    memo: 'Memo/Tag (Optionnel)',
    memoPlaceholder: 'Peut être requis pour XRP',
    available: 'Disponible',
    networkFee: 'Frais de réseau',
    youWillReceive: 'Vous recevrez',
    total: 'Total',
    withdraw: 'Retirer',
    cancel: 'Annuler',
    processing: 'Traitement...',
    success: 'Succès!',
    withdrawSuccess: 'Retrait effectué avec succès.',
    viewExplorer: 'Voir sur Explorer',
    error: 'Erreur',
    insufficientBalance: 'Solde insuffisant',
    invalidAddress: 'Adresse invalide',
    minAmount: 'Montant minimum',
    twoFactorRequired: 'Vérification 2FA',
    twoFactorCode: 'Code 2FA',
    twoFactorPlaceholder: 'Code à 6 chiffres',
    verify: 'Vérifier',
    btcComingSoon: 'Retraits BTC bientôt disponibles.',
    max: 'Max',
    confirmWithdraw: 'Confirmer le retrait',
    confirmMessage: 'sera retiré vers. Confirmez-vous?',
    confirm: 'Confirmer',
  },
  ar: {
    title: 'سحب العملات',
    selectCoin: 'اختر العملة',
    amount: 'المبلغ (AUXM)',
    withdrawAddress: 'عنوان السحب',
    addressPlaceholder: 'أدخل عنوان المحفظة',
    memo: 'مذكرة/علامة (اختياري)',
    memoPlaceholder: 'قد يكون مطلوباً لـ XRP',
    available: 'متاح',
    networkFee: 'رسوم الشبكة',
    youWillReceive: 'ستتلقى',
    total: 'المجموع',
    withdraw: 'سحب',
    cancel: 'إلغاء',
    processing: 'جارٍ المعالجة...',
    success: 'نجاح!',
    withdrawSuccess: 'تم السحب بنجاح.',
    viewExplorer: 'عرض في المستكشف',
    error: 'خطأ',
    insufficientBalance: 'رصيد غير كافٍ',
    invalidAddress: 'عنوان غير صالح',
    minAmount: 'الحد الأدنى للمبلغ',
    twoFactorRequired: 'التحقق الثنائي',
    twoFactorCode: 'رمز 2FA',
    twoFactorPlaceholder: 'رمز من 6 أرقام',
    verify: 'تحقق',
    btcComingSoon: 'سحب BTC قريباً.',
    max: 'الحد الأقصى',
    confirmWithdraw: 'تأكيد السحب',
    confirmMessage: 'سيتم السحب إلى. هل تؤكد؟',
    confirm: 'تأكيد',
  },
  ru: {
    title: 'Вывод криптовалюты',
    selectCoin: 'Выберите криптовалюту',
    amount: 'Сумма (AUXM)',
    withdrawAddress: 'Адрес вывода',
    addressPlaceholder: 'Введите адрес кошелька',
    memo: 'Memo/Tag (Необязательно)',
    memoPlaceholder: 'Может потребоваться для XRP',
    available: 'Доступно',
    networkFee: 'Комиссия сети',
    youWillReceive: 'Вы получите',
    total: 'Итого',
    withdraw: 'Вывести',
    cancel: 'Отмена',
    processing: 'Обработка...',
    success: 'Успешно!',
    withdrawSuccess: 'Вывод успешно завершён.',
    viewExplorer: 'Посмотреть в Explorer',
    error: 'Ошибка',
    insufficientBalance: 'Недостаточно средств',
    invalidAddress: 'Неверный адрес',
    minAmount: 'Минимальная сумма',
    twoFactorRequired: 'Проверка 2FA',
    twoFactorCode: 'Код 2FA',
    twoFactorPlaceholder: '6-значный код',
    verify: 'Подтвердить',
    btcComingSoon: 'Вывод BTC скоро будет доступен.',
    max: 'Макс',
    confirmWithdraw: 'Подтвердить вывод',
    confirmMessage: 'будет выведено на. Подтверждаете?',
    confirm: 'Подтвердить',
  },
};

// ============================================
// SUPPORTED COINS
// ============================================
const COINS = [
  { symbol: 'USDT', name: 'Tether', icon: '💵', color: '#26A17B', networkFee: 5 },
  { symbol: 'ETH', name: 'Ethereum', icon: '⟠', color: '#627EEA', networkFee: 7 },
  { symbol: 'XRP', name: 'Ripple', icon: '✕', color: '#23292F', networkFee: 0.1 },
  { symbol: 'SOL', name: 'Solana', icon: '◎', color: '#9945FF', networkFee: 0.1 },
  { symbol: 'BTC', name: 'Bitcoin', icon: '₿', color: '#F7931A', networkFee: 10, disabled: true },
];

// Fallback prices
const FALLBACK_PRICES: Record<string, number> = {
  USDT: 1,
  BTC: 97500,
  ETH: 3500,
  XRP: 2.2,
  SOL: 200,
};

// ============================================
// MAIN COMPONENT
// ============================================
export default function WithdrawModal({ visible, onClose, walletAddress, auxmBalance, onSuccess }: Props) {
  const colorScheme = useColorScheme();
  const { theme, language } = useStore();

  const systemIsDark = colorScheme === 'dark';
  const isDark = theme === 'system' ? systemIsDark : theme === 'dark';
  const t = translations[language as keyof typeof translations] || translations.en;
  const isRTL = language === 'ar';

  const [selectedCoin, setSelectedCoin] = useState(COINS[0]);
  const [amount, setAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [memo, setMemo] = useState('');
  const [loading, setLoading] = useState(false);
  const [prices, setPrices] = useState<Record<string, number>>(FALLBACK_PRICES);
  const [show2FA, setShow2FA] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [result, setResult] = useState<{ success: boolean; txHash?: string; explorerUrl?: string; error?: string } | null>(null);

  const colors = {
    background: isDark ? '#0F172A' : '#F8FAFC',
    surface: isDark ? '#1E293B' : '#FFFFFF',
    surfaceAlt: isDark ? '#334155' : '#F1F5F9',
    text: isDark ? '#FFFFFF' : '#0F172A',
    textSecondary: isDark ? '#94A3B8' : '#64748B',
    primary: '#10B981',
    danger: '#EF4444',
    warning: '#F59E0B',
    border: isDark ? '#334155' : '#E2E8F0',
  };

  useEffect(() => {
    if (visible) {
      fetchPrices();
    }
  }, [visible]);

  const fetchPrices = async () => {
    try {
      const res = await fetch(`${API_URL}/api/crypto`);
      const data = await res.json();
      setPrices({
        USDT: data.tether?.usd || 1,
        BTC: data.bitcoin?.usd || FALLBACK_PRICES.BTC,
        ETH: data.ethereum?.usd || FALLBACK_PRICES.ETH,
        XRP: data.ripple?.usd || FALLBACK_PRICES.XRP,
        SOL: data.solana?.usd || FALLBACK_PRICES.SOL,
      });
    } catch (err) {
      console.error('Fetch prices error:', err);
    }
  };

  const auxmAmount = parseFloat(amount) || 0;
  const networkFee = selectedCoin.networkFee;
  const totalRequired = auxmAmount + networkFee;
  const cryptoPrice = prices[selectedCoin.symbol] || 1;
  const cryptoAmount = auxmAmount / cryptoPrice;
  const isValidAmount = auxmAmount > 0 && totalRequired <= auxmBalance;
  const isValidAddress = withdrawAddress.length >= 20;

  const handleMax = () => {
    const maxAmount = Math.max(0, auxmBalance - networkFee);
    setAmount(maxAmount.toFixed(2));
  };

  const handleWithdraw = async () => {
    if (!isValidAmount || !isValidAddress) return;

    if (selectedCoin.disabled) {
      Alert.alert(t.error, t.btcComingSoon);
      return;
    }

    setShowConfirm(true);
  };

  const confirmWithdraw = async () => {
    setShowConfirm(false);
    setLoading(true);

    try {
      const res = await fetch(`${API_URL}/api/withdraw`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          address: walletAddress,
          coin: selectedCoin.symbol,
          auxmAmount,
          withdrawAddress,
          memo: memo || undefined,
          twoFactorCode: twoFactorCode || undefined,
        }),
      });

      const data = await res.json();

      if (data.requires2FA) {
        setShow2FA(true);
        setLoading(false);
        return;
      }

      if (!res.ok) {
        throw new Error(data.error || 'Withdrawal failed');
      }

      setResult({
        success: true,
        txHash: data.withdrawal?.txHash,
        explorerUrl: data.withdrawal?.explorerUrl,
      });

      onSuccess?.();
    } catch (err: any) {
      setResult({
        success: false,
        error: err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handle2FASubmit = () => {
    if (twoFactorCode.length === 6) {
      setShow2FA(false);
      confirmWithdraw();
    }
  };

  const resetAndClose = () => {
    setAmount('');
    setWithdrawAddress('');
    setMemo('');
    setTwoFactorCode('');
    setResult(null);
    setShow2FA(false);
    setShowConfirm(false);
    onClose();
  };

  // Success/Error Result View
  if (result) {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={resetAndClose}>
        <View style={styles.overlay}>
          <View style={[styles.modal, { backgroundColor: colors.surface }]}>
            <View style={styles.resultContainer}>
              <View style={[styles.resultIcon, { backgroundColor: result.success ? colors.primary + '20' : colors.danger + '20' }]}>
                <Ionicons
                  name={result.success ? 'checkmark-circle' : 'close-circle'}
                  size={48}
                  color={result.success ? colors.primary : colors.danger}
                />
              </View>
              <Text style={[styles.resultTitle, { color: colors.text }]}>
                {result.success ? t.success : t.error}
              </Text>
              <Text style={[styles.resultMessage, { color: colors.textSecondary }]}>
                {result.success ? t.withdrawSuccess : result.error}
              </Text>

              {result.success && result.txHash && (
                <TouchableOpacity
                  style={[styles.explorerButton, { borderColor: colors.primary }]}
                  onPress={() => result.explorerUrl && Linking.openURL(result.explorerUrl)}
                >
                  <Ionicons name="open-outline" size={18} color={colors.primary} />
                  <Text style={[styles.explorerButtonText, { color: colors.primary }]}>{t.viewExplorer}</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={styles.doneButton} onPress={resetAndClose}>
                <Text style={styles.doneButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  // 2FA Modal
  if (show2FA) {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setShow2FA(false)}>
        <View style={styles.overlay}>
          <View style={[styles.modal, { backgroundColor: colors.surface }]}>
            <View style={styles.twoFAContainer}>
              <View style={[styles.twoFAIcon, { backgroundColor: colors.warning + '20' }]}>
                <Ionicons name="shield-checkmark" size={40} color={colors.warning} />
              </View>
              <Text style={[styles.twoFATitle, { color: colors.text }]}>{t.twoFactorRequired}</Text>
              <TextInput
                style={[styles.twoFAInput, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.border }]}
                placeholder={t.twoFactorPlaceholder}
                placeholderTextColor={colors.textSecondary}
                value={twoFactorCode}
                onChangeText={setTwoFactorCode}
                keyboardType="number-pad"
                maxLength={6}
                autoFocus
              />
              <View style={styles.twoFAButtons}>
                <TouchableOpacity
                  style={[styles.twoFACancelButton, { backgroundColor: colors.surfaceAlt }]}
                  onPress={() => setShow2FA(false)}
                >
                  <Text style={[styles.twoFACancelText, { color: colors.text }]}>{t.cancel}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.twoFAVerifyButton, twoFactorCode.length !== 6 && styles.buttonDisabled]}
                  onPress={handle2FASubmit}
                  disabled={twoFactorCode.length !== 6}
                >
                  <Text style={styles.twoFAVerifyText}>{t.verify}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  // Confirm Modal
  if (showConfirm) {
    return (
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setShowConfirm(false)}>
        <View style={styles.overlay}>
          <View style={[styles.modal, { backgroundColor: colors.surface }]}>
            <View style={styles.confirmContainer}>
              <View style={[styles.confirmIcon, { backgroundColor: colors.warning + '20' }]}>
                <Ionicons name="warning" size={40} color={colors.warning} />
              </View>
              <Text style={[styles.confirmTitle, { color: colors.text }]}>{t.confirmWithdraw}</Text>
              <Text style={[styles.confirmAmount, { color: colors.primary }]}>
                {cryptoAmount.toFixed(6)} {selectedCoin.symbol}
              </Text>
              <Text style={[styles.confirmMessage, { color: colors.textSecondary }]}>
                {t.confirmMessage}
              </Text>
              <Text style={[styles.confirmAddress, { color: colors.text }]} numberOfLines={2}>
                {withdrawAddress}
              </Text>
              <View style={styles.confirmButtons}>
                <TouchableOpacity
                  style={[styles.confirmCancelButton, { backgroundColor: colors.surfaceAlt }]}
                  onPress={() => setShowConfirm(false)}
                >
                  <Text style={[styles.confirmCancelText, { color: colors.text }]}>{t.cancel}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.confirmSubmitButton} onPress={confirmWithdraw}>
                  <Text style={styles.confirmSubmitText}>{t.confirm}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={[styles.modal, styles.mainModal, { backgroundColor: colors.surface }]}>
          {/* Header */}
          <View style={[styles.header, { borderBottomColor: colors.border }]}>
            <Text style={[styles.title, { color: colors.text }]}>{t.title}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {/* Coin Selection */}
            <Text style={[styles.label, { color: colors.textSecondary }]}>{t.selectCoin}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.coinScroll}>
              {COINS.map((coin) => (
                <TouchableOpacity
                  key={coin.symbol}
                  style={[
                    styles.coinChip,
                    {
                      backgroundColor: selectedCoin.symbol === coin.symbol ? coin.color + '20' : colors.surfaceAlt,
                      borderColor: selectedCoin.symbol === coin.symbol ? coin.color : 'transparent',
                      opacity: coin.disabled ? 0.5 : 1,
                    },
                  ]}
                  onPress={() => !coin.disabled && setSelectedCoin(coin)}
                  disabled={coin.disabled}
                >
                  <Text style={styles.coinIcon}>{coin.icon}</Text>
                  <Text style={[styles.coinSymbol, { color: colors.text }]}>{coin.symbol}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Amount Input */}
            <View style={styles.inputGroup}>
              <View style={styles.labelRow}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>{t.amount}</Text>
                <TouchableOpacity onPress={handleMax}>
                  <Text style={[styles.maxButton, { color: colors.primary }]}>{t.max}</Text>
                </TouchableOpacity>
              </View>
              <View style={[styles.inputWrapper, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
                <TextInput
                  style={[styles.input, { color: colors.text }]}
                  placeholder="0.00"
                  placeholderTextColor={colors.textSecondary}
                  value={amount}
                  onChangeText={setAmount}
                  keyboardType="decimal-pad"
                />
                <Text style={[styles.inputSuffix, { color: colors.textSecondary }]}>AUXM</Text>
              </View>
              <Text style={[styles.availableText, { color: colors.textSecondary }]}>
                {t.available}: {auxmBalance.toFixed(2)} AUXM
              </Text>
            </View>

            {/* Address Input */}
            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>{t.withdrawAddress}</Text>
              <TextInput
                style={[styles.addressInput, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.border }]}
                placeholder={t.addressPlaceholder}
                placeholderTextColor={colors.textSecondary}
                value={withdrawAddress}
                onChangeText={setWithdrawAddress}
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            {/* Memo (for XRP) */}
            {selectedCoin.symbol === 'XRP' && (
              <View style={styles.inputGroup}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>{t.memo}</Text>
                <TextInput
                  style={[styles.addressInput, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.border }]}
                  placeholder={t.memoPlaceholder}
                  placeholderTextColor={colors.textSecondary}
                  value={memo}
                  onChangeText={setMemo}
                  keyboardType="number-pad"
                />
              </View>
            )}

            {/* Summary */}
            {auxmAmount > 0 && (
              <View style={[styles.summaryCard, { backgroundColor: colors.surfaceAlt }]}>
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{t.networkFee}</Text>
                  <Text style={[styles.summaryValue, { color: colors.warning }]}>{networkFee} AUXM</Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{t.total}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{totalRequired.toFixed(2)} AUXM</Text>
                </View>
                <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{t.youWillReceive}</Text>
                  <Text style={[styles.summaryValueLarge, { color: colors.primary }]}>
                    {cryptoAmount.toFixed(6)} {selectedCoin.symbol}
                  </Text>
                </View>
              </View>
            )}
          </ScrollView>

          {/* Footer */}
          <View style={[styles.footer, { borderTopColor: colors.border }]}>
            <TouchableOpacity
              style={[styles.withdrawButton, (!isValidAmount || !isValidAddress) && styles.buttonDisabled]}
              onPress={handleWithdraw}
              disabled={!isValidAmount || !isValidAddress || loading}
            >
              {loading ? (
                <ActivityIndicator size="small" color="#FFF" />
              ) : (
                <>
                  <Ionicons name="arrow-up-circle" size={20} color="#FFF" />
                  <Text style={styles.withdrawButtonText}>{t.withdraw}</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ============================================
// STYLES
// ============================================
const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modal: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
  },
  mainModal: {
    minHeight: '70%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
  },
  closeButton: {
    position: 'absolute',
    right: 16,
    padding: 4,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 8,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  maxButton: {
    fontSize: 13,
    fontWeight: '600',
  },
  coinScroll: {
    marginBottom: 20,
  },
  coinChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    marginRight: 10,
    borderWidth: 2,
    gap: 6,
  },
  coinIcon: {
    fontSize: 18,
  },
  coinSymbol: {
    fontSize: 14,
    fontWeight: '600',
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
  },
  input: {
    flex: 1,
    fontSize: 18,
    fontWeight: '600',
    paddingVertical: 14,
  },
  inputSuffix: {
    fontSize: 14,
    fontWeight: '500',
  },
  availableText: {
    fontSize: 12,
    marginTop: 6,
  },
  addressInput: {
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 14,
    fontSize: 14,
  },
  summaryCard: {
    borderRadius: 14,
    padding: 16,
    marginTop: 8,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  summaryLabel: {
    fontSize: 13,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  summaryValueLarge: {
    fontSize: 18,
    fontWeight: '700',
  },
  summaryDivider: {
    height: 1,
    marginVertical: 10,
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
  },
  withdrawButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#10B981',
    paddingVertical: 16,
    borderRadius: 14,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  withdrawButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
  // Result styles
  resultContainer: {
    alignItems: 'center',
    padding: 24,
  },
  resultIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
  },
  resultMessage: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
  },
  explorerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    marginBottom: 16,
  },
  explorerButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  doneButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 40,
    paddingVertical: 14,
    borderRadius: 12,
  },
  doneButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  // 2FA styles
  twoFAContainer: {
    alignItems: 'center',
    padding: 24,
  },
  twoFAIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  twoFATitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 20,
  },
  twoFAInput: {
    width: '100%',
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    letterSpacing: 8,
    marginBottom: 20,
  },
  twoFAButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  twoFACancelButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  twoFACancelText: {
    fontSize: 15,
    fontWeight: '600',
  },
  twoFAVerifyButton: {
    flex: 1,
    backgroundColor: '#10B981',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  twoFAVerifyText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '600',
  },
  // Confirm styles
  confirmContainer: {
    alignItems: 'center',
    padding: 24,
  },
  confirmIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  confirmTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  confirmAmount: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 8,
  },
  confirmMessage: {
    fontSize: 14,
    marginBottom: 8,
  },
  confirmAddress: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 20,
  },
  confirmButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  confirmCancelButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmCancelText: {
    fontSize: 15,
    fontWeight: '600',
  },
  confirmSubmitButton: {
    flex: 1,
    backgroundColor: '#10B981',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmSubmitText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '600',
  },
});
